import ode
import pyext
import math
import random

# Collision callback
def near_callback(args, geom1, geom2):
    """Callback function for the collide() method.

    This function checks if the given geoms do collide and
    creates contact joints if they do.
    """

    # Check if the objects do collide
    contacts = ode.collide(geom1, geom2)

    # Create contact joints
    world,contactgroup,cp = args
    for c in contacts:
        c.setBounce(cp["Bounce"])
        c.setMu(cp["Mu"])
        j = ode.ContactJoint(world, contactgroup, c)
        j.attach(geom1.getBody(), geom2.getBody())

def vec_normalize(vec):
    """normalize a 3-dim vector"""
    length = math.sqrt(sum([i*i for i in vec]))
    assert length > 0
    v = [i/length for i in vec]
    return v

def vec_substract(v1,v2):
    """ substract two 3-dim vectors """
    return [v2[i]-v1[i] for i in range(3)]

class World(pyext._class):
    
    _inlets = 2
    _outlets = 2
    
    def __init__(self):
        # Create a world object
        self.world = ode.World()
        self.world.setGravity( (0,-9.81,0) )
        self.world.setERP(0.2) # or 0.8
        self.world.setCFM(1E-5)

        # Create a space object
        # self.space = ode.Space()
        self.space = ode.HashSpace()
        #self.space = ode.SimpleSpace()

        # Create a plane geom which prevent the objects from falling forever
        self.floor = self.create_plane(0, 1, 0, 0)

        # lists with ODE bodies and joints
        self.bodies = {}
        self.joints = []
        self.geoms  = []
        self.bodycount = 0
        self.jointcount = 0
        self.geomcount = 0
            
        # aerodynamic drag
        self.drag = -0.01

        # A joint group for the contact joints that are generated whenever
        # two bodies collide
        self.contactgroup = ode.JointGroup() 
        self.contactparm = {"Mu": 5000, "Bounce": 0.2} 

        # step intervall:
        self.dt = 0.01
        # steps per bang
        self.steps = 2
        # enable collisions:
        self.collision = 1
    
    def _del(self):
        # May fix the memory leak mentioned in:
        # http://sourceforge.net/mailarchive/forum.php?thread_id=7863635&forum_id=38876
        # print "clearing ode._geom_c2py_lut"
        ode._geom_c2py_lut.clear()
    
    def _anything_2(self, func, *args):
        """second inlet sets world and simulation parameters"""
        # TODO this needs proper error checking, or maybe not.
        func = str(func)
        
        # simulation parameters:
        if func == "sim.dt":
            self.dt = args[0]
        elif func ==  "sim.steps":
            self.steps = args[0]
        elif func ==  "sim.collision":
            self.collision = args[0]
        elif func == "sim.drag":
            self.drag = args[0]

        # contact point parameters:
        elif func == "contact.Mu":
            self.contactparm["Mu"] = args[0]
        elif func == "contact.Bounce":
            self.contactparm["Bounce"] = args[0]

        # global world params:
        elif func == "world.setGravity":
            self.world.setGravity( args )
        elif func == "world.setERP":
            self.world.setERP(args[0]) 
        elif func == "world.setCFM":
            self.world.setCFM(args[0])
        
        # get/set/add methods for a single body:
        elif func == "body.get":
            id, meth = args[0:2]
            if self.bodies.has_key(id):
                b = self.bodies[id]
                result = [meth, id]
                result.extend( getattr(b, "get%s" % meth)() )
                self._outlet(2, result)
        elif func == "body.set":
            id, meth, parms = args[0], args[1], args[2:]
            meth = "set%s" % meth
            if self.bodies.has_key(id):
                b = self.bodies[id]
                if hasattr(b,meth):
                    getattr(b,meth)(parms)
        elif func == "body.add":
            id, meth, parms = args[0], args[1], args[2:]
            meth = "add%s" % meth
            if self.bodies.has_key(id):
                b = self.bodies[id]
                if hasattr(b,meth):
                    getattr(b,meth)(parms)
        
        # get/set/add methods for all current bodies:
        elif func == "bodies.set":
            meth, parms = args[0],args[1:]
            meth = "set%s" % meth
            for b in self.bodies.values():
                if hasattr(b,meth):
                    getattr(b,meth)(parms)
        elif func == "bodies.get":
            meth = "get%s" % args[0]
            for id, b in self.bodies.items():
                if hasattr(b,meth):
                    result = [args[0], id]
                    result.extend(getattr(b,meth)())
                    self._outlet(2, result)
        elif func == "bodies.add":
            meth, parms = args[0],args[1:]
            meth = "add%s" % meth
            for b in self.bodies.values():
                if hasattr(b,meth):
                    getattr(b,meth)(parms)
        else:
            print "unknown method: ", func, args

    def bang_1(self):
        self.simulate()
        
        for id,b in self.bodies.items():
            out = ["body", b.shape, id]
            out.extend(self.draw_body(b))
            self._outlet(1,out)
        
        i = 0
        for g in self.geoms:
            out = ["geom", g.shape, i]
            out.extend(self.draw_body(g))
            self._outlet(1,out)
            i = i + 1
        
        i = 0
        for j in self.joints:
            out = ["joint", j.type, i]
            out.extend(self.draw_joint(j))
            self._outlet(1,out)
            i = i + 1
    
    def draw_body(self, body):
        """Draw an ODE body. Returns a list composed of: 
        * Position (3):  x,y,z
        * Orientation (4): angle, rx, ry, rz
        * Shape-specific data: e.g. size for a box as a list of 3 lengths.
        """
        # Position:
        result = list(body.getPosition())
        
        # Orientation:
        Q = body.getQuaternion()
        # cos_a = Q[0]
        angle = math.degrees(math.acos(Q[0]) * 2)
        # We don't need to scale the Quaterion's rotation axis vector for Gem's
        # [rotate] object.
        result.append(angle)
        result.extend( list(Q[1:4]) )
        
        # Shape-specific data:
        if (body.shape == "box"):
            # However we need to scale the boxsize to half, so that Gem's [scale]
            # object can handle it cleanly.
            result.extend([i * 0.5 for i in body.boxsize])
        elif (body.shape == "sphere"):
            result.append(body.radius)
        elif (body.shape == "ccylinder"):
            result.extend((body.radius, body.length))
        return result
    
    def draw_joint(self, joint):
        """Draw an ODE joint. Returns a list composed of: 
        * Position of body1 (3):  x1,y1,z1
        * Position of body2 (3):  x2,y2,z2
        * Position of anchor (3):  ax,ay,az
        """
        result = []
        for i in (0,1):
            b = joint.getBody(i)
            if b:
                result.extend(b.getPosition())
            else:
                result.extend((0,0,0))
        if hasattr(joint, "getAnchor"):
            result.extend(joint.getAnchor())
        return result
            
    def body_1(self, shape, id, x, y, z, angle, rx, ry, rz, *args):
        """body_1: Make a body with explicit parameters. 
Expects: 
 shape: box, sphere, etc.
 id: a name for the body, used as a key in self.bodies. Has to be unique.
 Position of center: x, y, z
 Orientation:        angle (deg), rx, ry, rz
 args: further properties of the body, that will get passed 
       to a method '"self.create_%s" % shape'.
       Use this to set special properties like density, size of a box, 
       radius of a sphere etc.
 """
        if self.bodies.has_key(id):
            print "Sorry, there already is a body with key: %s. Deletion is not yet supported" % id
            return
        body = None
        if hasattr(self, "create_%s" % shape):
            body = getattr(self, "create_%s" % shape)(*args)
            body.setPosition((x, y, z))
            cos_a = math.cos(math.radians(angle * 0.5))
            sin_a = math.sin(math.radians(angle * 0.5))
            q = [cos_a]
            rot = vec_normalize([rx,ry,rz])
            rot = [i * sin_a for i in rot]
            q.extend(rot)
            body.setQuaternion(q)
            self.bodies[id] = body
            self.bodycount = len(self.bodies.keys())
            self._outlet(2, "bodycount", self.bodycount)
        else: 
            print "Don't know how to do create_%s " % shape

    def joint_1(self, jointtype, body1, body2, *args):
        """ make a joint. 
        Supported joint-types: 
        * balljoint. Args: body1, body2, ax, ay, az"""
        b1 = b2 = None
        if self.bodies.has_key(body1):
            b1 = self.bodies[body1]
        else:
            print """Ode: could not find body (%s) in self.bodies. """ % body1
        if self.bodies.has_key(body2):
            b2 = self.bodies[body2]
        else:
            print """Ode: could not find body (%s) in self.bodies. """ % body2

        joint = getattr(self, "create_joint_%s" % jointtype)(b1, b2, *args)
        if joint:
            self.joints.append(joint)
        self._outlet(2, "jointcount", len(self.joints))

    def geom_1(self, shape, x, y, z, angle, rx, ry, rz, *args):
        """geom_1: Make a geom with explicit parameters.
Expects: 
 shape: box, sphere, etc.
 x, y, z, angle, rx, ry, rz, sx, sy, sz, density
 Position of center: x, y, z
 Orientation:        angle (deg), rx, ry, rz
 args: further properties of the , that will get passed 
       to a method '"self.create_geom_%s" % shape'.
       Use this to set special properties like size of a box, 
       radius of a sphere etc.
"""
        geom = getattr(self, "create_geom_%s" % shape)(*args)
        geom.setPosition((x, y, z))
        cos_a = math.cos(math.radians(angle * 0.5))
        sin_a = math.sin(math.radians(angle * 0.5))
        q = [cos_a]
        rot = vec_normalize([rx,ry,rz])
        rot = [i * sin_a for i in rot]
        q.extend(rot)
        geom.setQuaternion(q) 
        self.geoms.append(geom)
        self.geomcount = len(self.geoms)
        self._outlet(2, "geomcount", self.geomcount)
        
    def force_1(self, *args):
        """force: add a force to a Body by id
usage: force x y z id1 [id2 id3 ...]"""
        if len(args) >= 4:
            #print "force ", args[:3]
            #print "affected bodies: ", args[3:]
            for id in args[3:]:
                if self.bodies.has_key(id):
                    self.bodies[id].addForce(args[:3])
        else:
            print "force: wrong argument count. usage: force x y z id1 [id2 id3 ...]"
    
    def pos_1(self, *args):
        """pos: manually set position of one or more Bodies by id
usage: pos x y z id1 [id2 id3 ...]"""
        if len(args) >= 4:
            for id in args[3:]:
                if self.bodies.has_key(id):
                    self.bodies[id].setPosition(args[:3])
        else:
            print "pos: wrong argument count. usage: pos x y z id1 [id2 id3 ...]"

    def simulate(self):
        for i in range(self.steps):
            if self.collision:
                self.space.collide((self.world, self.contactgroup, self.contactparm), near_callback)
            
            # compute aerodynamic drag
            self.aerodrag()
            
            # Simulation step
            self.world.quickStep(self.dt)
            #self.world.step(dt)
            
            if self.collision:
                # Remove all contact joints
                self.contactgroup.empty()

    def aerodrag(self):
        """Naive damping for a kind of aerodynamic drag"""
        # skip this for no drag:
        if abs(self.drag) > 0.0001:
            for b in self.bodies.values():
                vel = b.getLinearVel()
                a = [self.drag * i for i in vel]
                b.addForce(a)

    #---- pyode methods -------#
    
    def create_box(self, density, lx, ly, lz, *args):
        """Create a box body and its corresponding geom."""
        # Create body
        body = ode.Body(self.world)
        M = ode.Mass()
        M.setBox(density, lx, ly, lz)
        body.setMass(M)

        # Set parameters for drawing the body
        body.shape = "box"
        body.boxsize = (lx, ly, lz)

        # Create a box geom for collision detection
        geom = ode.GeomBox(self.space, lengths=body.boxsize)
        geom.setBody(body)

        return body
    
    def create_sphere(self, density, radius, *args):
        """Create a sphere body and its corresponding geom."""
        # Create body
        body = ode.Body(self.world)
        M = ode.Mass()
        M.setSphere(density, radius)
        body.setMass(M)

        # Set parameters for drawing the body
        body.shape = "sphere"
        body.radius = radius

        # Create a sphere geom for collision detection
        geom = ode.GeomSphere(self.space, radius=body.radius)
        geom.setBody(body)
        
        return body
    
    def create_ccylinder(self, density, r, h, *args):
        """Create a capped cylinder and its corresponding geom."""
        
#        if direction not in (1,2,3):
#            print """Ode: Warning: CCylinder direction must be 1 (x),2 (y) or 3 (z).
#            Using default of 1.
#            """
#            direction = 1
        
        # align mass along body's z-axis:
        direction = 3
        
        # Create body
        body = ode.Body(self.world)
        M = ode.Mass()
        M.setCappedCylinder(density, direction, r, h)
        geom = ode.GeomCCylinder(self.space, r, h)
#        else:
#            M.setCylinder(density, direction, r, h)
#            body.shape = "capped_cylinder"
#            # Doesn't exist?
#            geom = ode.GeomCylinder(self.space, r, h)
        
        if body:
            body.setMass(M)
            # Set parameters for drawing the body
            body.radius = r
            body.length = h
            body.direction = direction
            body.shape = "ccylinder"

            # Create a sphere geom for collision detection
            geom.setBody(body)
            
            return body   
    
    def create_geom_box(self, lx, ly, lz, *args):
        """Create a box geom (imovable box)."""
        # Set parameters for drawing the body
        # Create a box geom for collision detection
        geom = ode.GeomBox(self.space, lengths=(lx, ly, lz))
        geom.shape = "box"
        geom.boxsize = (lx, ly, lz)
        return geom
    
    def create_geom_sphere(self, radius, *args):
        """Create a box geom (imovable box)."""
        # Set parameters for drawing the body
        # Create a box geom for collision detection
        geom = ode.GeomSphere(self.space, radius=radius)
        geom.shape = "sphere"
        geom.radius = radius
        return geom

    def create_plane(self, nx, ny, nz, dist, *args):
        plane = ode.GeomPlane(self.space, (nx, ny, nz), dist)

    def create_joint_ball(self, body1, body2, *args):
        j = ode.BallJoint(self.world)
        j.attach(body1, body2)
        if not args:
            if body1:
                anchor = body1.getPosition()
                j.setAnchor(anchor)
        else:
            j.setAnchor((args))
        j.type = "ball"
        return j
    
    def create_joint_hinge(self, body1, body2, *args):
        j = ode.HingeJoint(self.world)
        j.attach(body1, body2)
        if not args:
            if body1:
                anchor = body1.getPosition()
                j.setAnchor(anchor)
        else:
            j.setAnchor((args))
        j.type = "hinge"
        return j
    
    def create_joint_slider(self, body1, body2, *args):
        # TODO this doesn't work correctly yet
        j = ode.SliderJoint(self.world)
        b1 = body1.getPosition()
        b2 = body2.getPosition()
        axis = vec_substract(b2,b1)
        j.setAxis(axis)
        j.attach(body1, body2)
        j.type = "slider"
        return j
        
