import time
import OSC

client = OSC.OSCClient()
msg = OSC.OSCMessage()
msg.setAddress("/lovedindon")

server = OSC.OSCServer


for i in range(10):

    try:
        msg.append(i)
        msg.append(i*2)
        msg.append("tatayoyo")
        client.sendto(msg, ('127.0.0.1', 8000))
        msg.clearData()

    except:
        pass



