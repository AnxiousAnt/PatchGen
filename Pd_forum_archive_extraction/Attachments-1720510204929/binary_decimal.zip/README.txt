This is a simple set of functions to convert from binary to decimal and back again. GPL applies.

~Kyle Klipowicz   