#include <stdio.h>
#include <math.h>

/* bintodec.c:  converts a binary representation of
 an integer to a decimal one */

int main()
{
    int i;
    long bin, dec;
    i = bin = dec = 0;	

    printf("Enter a binary number: ");
    scanf("%d", &bin);

    while ( bin > 0)  {
	dec += (bin % 2)  * pow(2, i);
	i++;
	bin /= 10;
    }
    printf("Decimal equivalent: %d\n", dec);

    return 0;
}	

 
