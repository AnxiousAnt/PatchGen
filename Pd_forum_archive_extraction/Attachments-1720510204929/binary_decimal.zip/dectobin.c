#include <stdio.h>
#include <math.h>

/* dectobin.c:  converts a decimal representation of
 an integer to a binary one */

int main()
{
    int i;
    long bin, dec;
    i = bin = dec = 0;	

    printf("Enter a decimal number: ");
    scanf("%d", &dec);

    while ( dec > 0)  {
	bin += (dec % 2)  * pow(10, i);
	i++;
	dec /= 2;
    }
    printf("Binary equivalent: %d\n", bin);

    return 0;
}	

 
