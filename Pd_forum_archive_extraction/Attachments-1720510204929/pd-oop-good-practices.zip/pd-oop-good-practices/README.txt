=================================
= Pure Data OOP good practices  =
=================================

Date : 30/11/2011
Author : J�r�me Abel
Contact : abel.jerome@free.fr
License : GNU/GPLv3
Files : http://jeromeabel.net/files/code/pd
Pure Data : 0.42.5.extended
OS : Xubuntu 10.04
Dependancy : [cyclone/MouseState]


DESCRIPTION
=================================
This example shows some personal methods of programming with Pure Data when you are influenced by OOP (object oriented programming) design.


USE IT
=================================
Pure Data must be installed : http://puredata.info/community/projects/software/pd-extended.
Then, clic on "main.pd" patch and follow instructions.
