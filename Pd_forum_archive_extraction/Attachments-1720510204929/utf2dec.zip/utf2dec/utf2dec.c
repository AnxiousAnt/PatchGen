#include <stdio.h>
#include <assert.h>

// UTF-8 to decimal number conversion
// (c) Christoph Schied, 2009

/*
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

/*
void
print_dec(int x)
{
	int i;
	for(i = 31; i >= 0; i--)
		printf("%d", (x >> i) & 1);
	printf("\n");
}
*/

int
main(int argc, char **argv)
{
	int x, c, j, bits;

	while((c = getchar()) != EOF) {
		if((c >> 6) == 3) { /* start byte of multibyte character */
			/* count leading bits */
			for(bits = 0; bits < 8 && ((1 << (7 - bits)) & c); bits++);

			/* value without leading bits */
			x = c & ((1 << (7 - bits)) - 1);

			/* read remaining bytes */
			for(j = 0; j < bits - 1; j++) {
				c = getchar();
				assert((c >> 6) == 2); /* needs to be follow byte */
				x <<= 6;
				x |= c & ((1 << 6) - 1);
			}
			printf("%d\n", x);
		}
		else if(!(c & 1 << 7)) { /* ascii character */
			printf("%d ", c);
		}
		else {
			assert(0);
		}
	}

	return 0;
}

