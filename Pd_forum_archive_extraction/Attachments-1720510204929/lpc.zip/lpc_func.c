
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "mat.h"
#include "lpc.h"
/*
*------------------------------------------------------------------------------
*	funct:	lpcout
*	desct:	output data from generic input
*	given:
*		gout = generic output
*		gacout = generic output for .ac file
*		A = autocorrelation matrix (if exists)
*		B = coefficients matrix (any type .lpc, .par, .cep)
*		i = from offset
*		n = number of coefficients
*------------------------------------------------------------------------------
*/ 
float lpcout(MATRIX B,  MATRIX A, int i,int n)
//GIO *gout;

//GIO *gacout;

{
	int	j;
	char	tmp[128];
	
	for (j=i; j<n; j++)
		{
		sprintf(tmp, "%f ", B[j][0]);
//		printf("%f \n", B[j][0]);
//		gputs( temp, gout );
/*		if (gacout != NULL)
			{
			sprintf(temp, "%f ", A[j][0]);
			gputs( temp, gacout );
			}
*/		}
//	gputs( "\n", gout );
//	if (gacout != NULL)
//		gputs( "\n", gacout );
	
	return (tmp[0]);
}

/*
*------------------------------------------------------------------------------
*	funct:	lpc
*	desct:	get data from generic input and LPC it
*	given:
*		gin = generic input
*		gout = generic output
*		gacout = generic output for .ac file
*		order = order of LPC
*		ws = window size
*		os = window overlap size
*		method = (see lpc.h) 
*------------------------------------------------------------------------------
*/ 
float lpc( float *s, int order )
{
	MATRIX	A, B, F;
	
//	short	t;
//	int	i;
	

	A = mat_creat(order, order, UNDEFINED);
	F = mat_creat(order, 1, UNDEFINED);
//	s = (double *)malloc(sizeof(double) * WINDOW_SIZE);
//	i = 0;

//	s[i] = norm_s2d(gin);
	

	B = lpc2(A, F, s, WINDOW_SIZE);

		
	return(lpcout(  B,  A, 0, order ));
	mat_free(A);
	mat_free(F);
//	free(s);
	
	
}

/*
*------------------------------------------------------------------------------
*	funct:	normeqn_ac	
*	desct:	create a normal equation with autocorrelation matrix 
*	given:	a1 = allocated matrix (M x M) for autocorrelation matrix
*		a2 = allocated matrix (M x 1)
*		s = signal array
*		nn= number of signal
*	retrn:	nothing
*------------------------------------------------------------------------------
*/
void normeqn_ac(MATRIX A1,MATRIX A2,float *s,int nn )
{
	int	i, j, k, n, m;

	m = MatCol(A1);

	/*
	* create autocorrelation matrix
	*/
	for (i=0; i<m; i++)
		{
		A1[0][i] = 0.0;
		for (n=0; n<nn-i; n++)
			{
			A1[0][i] += s[n] * s[n+i];
			}
		}
	for (i=1; i<m; i++)
	for (j=0; j<m; j++)
		{
		A1[i][j] = A1[0][abs(i-j)];
		}

	for (k=1; k<m; k++)
		{
		A2[k-1][0] = A1[0][k];
		}

	A2[m-1][0] = 0.0;
	for (n=0; n<nn-m; n++)
		{
		A2[m-1][0] += s[n] * s[n+m];
		}
}

/*
*------------------------------------------------------------------------------
*	funct:	lpc2 (autocorrelation approach)
*	desct:	lpc on one windows of data
*	given:	A = allocated correlation matrix (M x M) M=order of LPC 
*		B = allocated column vector (M x 1) 
*		P = allocated column vector (M x 1) for PARCOR coefs
*		E = allocated column vector (M+1 x 1) for residue power
*		s = signal array
*		nn = number of signals in s  
*	retrn:	a column matrix of LPC coefficients	
*------------------------------------------------------------------------------
*/ 
MATRIX lpc2(MATRIX A,MATRIX B,float *s,int nn)
{
	MATRIX X;
	int i;

	normeqn_ac( A, B, s, nn );

	X = mat_lsolve_durbin( A, B );

	for (i=0; i<MatRow(X); i++)
		X[i][0] *= -1.0;

	return (X);
} 

/*
*-----------------------------------------------------------------------------
*	funct:	mat_lsolve_durbin
*	desct:	Solve simultaneous linear eqns using
*		Levinson-Durbin algorithm
*
*		This function solve the linear eqns Ax = B:
*
*		|  v0   v1   v2  .. vn-1 | |  a1   |    |  v1   |
*		|  v1   v0   v1  .. vn-2 | |  a2   |    |  v2   |
*		|  v2   v1   v0  .. vn-3 | |  a3   |  = |  ..   |
*		|  ...                   | |  ..   |    |  ..   |
*		|  vn-1 vn-2 ..  .. v0   | |  an   |    |  vn   |
*
*	domain:	where A is a symmetric Toeplitz matrix and B
*		in the above format (related to A)
*
*	given:	A, B
*	retrn:	x (of Ax = B)
*
*-----------------------------------------------------------------------------
*/
MATRIX mat_lsolve_durbin(MATRIX A,MATRIX B )
{
	MATRIX	R, X;
	int	i,n;
    
	n = MatRow(A);
	R = mat_creat(n+1, 1, UNDEFINED);
	for (i=0; i<n; i++)
		{
		R[i][0] = A[i][0];
		}
	R[n][0] = B[n-1][0];

	X = mat_durbin( R );
	mat_free( R );
	return (X);
}

/*
*-----------------------------------------------------------------------------
*	funct:	mat_durbin
*	desct:	Levinson-Durbin algorithm
*
*		This function solve the linear eqns Ax = B:
*
*		|  v0   v1   v2  .. vn-1 | |  a1   |    |  v1   |
*		|  v1   v0   v1  .. vn-2 | |  a2   |    |  v2   |
*		|  v2   v1   v0  .. vn-3 | |  a3   |  = |  ..   |
*		|  ...                   | |  ..   |    |  ..   |
*		|  vn-1 vn-2 ..  .. v0   | |  an   |    |  vn   |
*
*		where A is a symmetric Toeplitz matrix and B
*		in the above format (related to A)
*
*	given:	R = autocorrelated matrix (v0, v1, ... vn) (dim (n+1) x 1)
*	retrn:	x (of Ax = B)
*-----------------------------------------------------------------------------
*/
MATRIX mat_durbin(MATRIX R )
{
	int	i, i1, j, ji ,p;
	MATRIX	W, E, K, A, X;
	
	p = MatRow(R) - 1;
	W = mat_creat( p+2, 1, UNDEFINED );
	E = mat_creat( p+2, 1, UNDEFINED );
	K = mat_creat( p+2, 1, UNDEFINED );
	A = mat_creat( p+2, p+2, UNDEFINED );

	W[0][0] = R[1][0];
	E[0][0] = R[0][0];

	for (i=1; i<=p; i++)
		{
		K[i][0] = W[i-1][0] / E[i-1][0];
		E[i][0] = E[i-1][0] * (1.0 - K[i][0] * K[i][0]);

		A[i][i] = -K[i][0];

		i1 = i-1;
		if (i1 >= 1)
			{
			for (j=1; j<=i1; j++)
				{
				ji = i - j;
				A[j][i] = A[j][i1] - K[i][0] * A[ji][i1];
				}
			}

		if (i != p)
			{
			W[i][0] = R[i+1][0];
			for (j=1; j<=i; j++)
				W[i][0] += A[j][i] * R[i-j+1][0];
			}
		}

	X = mat_creat( p, 1, UNDEFINED );
	for (i=0; i<p; i++)
		{
		X[i][0] = -A[i+1][p];
		}

	mat_free( A );
	mat_free( W );
	mat_free( K );
	mat_free( E );
	return (X);
}



