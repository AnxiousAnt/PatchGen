
/* code for lpc pd class 
   made by:     Raviv Haim   25558495
                Guy   Ezra   25185752   */






#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <malloc.h>

#include "m_pd.h"
#include "mat.h"
#include "lpc.h"








int ord;
t_floatarg signal[18];
int i = 0;
float tmp_parameter[128];

typedef struct _lpc
{
  t_object t_ob;
  
} t_lpc;
/******************************************************************/

/*
*------------------------------------------------------------------------------
*	funct:	lpcout
*	desct:	output data from generic input
*	given:
*		gout = generic output
*		gacout = generic output for .ac file
*		A = autocorrelation matrix (if exists)
*		B = coefficients matrix (any type .lpc, .par, .cep)
*		i = from offset
*		n = number of coefficients
*------------------------------------------------------------------------------
*/ 
int lpcout(MATRIX B,  MATRIX A, int i,int n)

{
	int	j;

	for (j=0; j<128; j++)
		tmp_parameter[j] = 0;
	
	for (j=i; j<n; j++)
		{

		tmp_parameter[j] = (float)B[j][0];

		}

	return(1);
}

/*
*------------------------------------------------------------------------------
*	funct:	lpc
*	desct:	get data from generic input and LPC it
*	given:
*		gin = generic input
*		gout = generic output
*		gacout = generic output for .ac file
*		order = order of LPC
*		ws = window size
*		os = window overlap size
*		method = (see lpc.h) 
*------------------------------------------------------------------------------
*/ 
void lpc( float *s, int order )
{
	MATRIX	A, B, F;

	A = mat_creat(order, order, UNDEFINED);
	F = mat_creat(order, 1, UNDEFINED);
	B = lpc2(A, F, s, WINDOW_SIZE);

    lpcout(  B,  A, 0, order );
	mat_free(A);
	mat_free(F);

	
	
}

/*
*------------------------------------------------------------------------------
*	funct:	normeqn_ac	
*	desct:	create a normal equation with autocorrelation matrix 
*	given:	a1 = allocated matrix (M x M) for autocorrelation matrix
*		a2 = allocated matrix (M x 1)
*		s = signal array
*		nn= number of signal
*	retrn:	nothing
*------------------------------------------------------------------------------
*/
void normeqn_ac(MATRIX A1,MATRIX A2,float *s,int nn )
{
	int	i, j, k, n, m;

	m = MatCol(A1);

	/*
	* create autocorrelation matrix
	*/
	for (i=0; i<m; i++)
		{
		A1[0][i] = 0.0;
		for (n=0; n<nn-i; n++)
			{
			A1[0][i] += s[n] * s[n+i];
			}
		}
	for (i=1; i<m; i++)
	for (j=0; j<m; j++)
		{
		A1[i][j] = A1[0][abs(i-j)];
		}

	for (k=1; k<m; k++)
		{
		A2[k-1][0] = A1[0][k];
		}

	A2[m-1][0] = 0.0;
	for (n=0; n<nn-m; n++)
		{
		A2[m-1][0] += s[n] * s[n+m];
		}
}

/*
*------------------------------------------------------------------------------
*	funct:	lpc2 (autocorrelation approach)
*	desct:	lpc on one windows of data
*	given:	A = allocated correlation matrix (M x M) M=order of LPC 
*		B = allocated column vector (M x 1) 
*		P = allocated column vector (M x 1) for PARCOR coefs
*		E = allocated column vector (M+1 x 1) for residue power
*		s = signal array
*		nn = number of signals in s  
*	retrn:	a column matrix of LPC coefficients	
*------------------------------------------------------------------------------
*/ 
MATRIX lpc2(MATRIX A,MATRIX B,float *s,int nn)
{
	MATRIX X;
	int i;

	normeqn_ac( A, B, s, nn );

	X = mat_lsolve_durbin( A, B );

	for (i=0; i<MatRow(X); i++)
		X[i][0] *= -1.0;

	return (X);
} 

/*
*-----------------------------------------------------------------------------
*	funct:	mat_lsolve_durbin
*	desct:	Solve simultaneous linear eqns using
*		Levinson-Durbin algorithm
*
*		This function solve the linear eqns Ax = B:
*
*		|  v0   v1   v2  .. vn-1 | |  a1   |    |  v1   |
*		|  v1   v0   v1  .. vn-2 | |  a2   |    |  v2   |
*		|  v2   v1   v0  .. vn-3 | |  a3   |  = |  ..   |
*		|  ...                   | |  ..   |    |  ..   |
*		|  vn-1 vn-2 ..  .. v0   | |  an   |    |  vn   |
*
*	domain:	where A is a symmetric Toeplitz matrix and B
*		in the above format (related to A)
*
*	given:	A, B
*	retrn:	x (of Ax = B)
*
*-----------------------------------------------------------------------------
*/
MATRIX mat_lsolve_durbin(MATRIX A,MATRIX B )
{
	MATRIX	R, X;
	int	i,n;
    
	n = MatRow(A);
	R = mat_creat(n+1, 1, UNDEFINED);
	for (i=0; i<n; i++)
		{
		R[i][0] = A[i][0];
		}
	R[n][0] = B[n-1][0];

	X = mat_durbin( R );
	mat_free( R );
	return (X);
}

/*
*-----------------------------------------------------------------------------
*	funct:	mat_durbin
*	desct:	Levinson-Durbin algorithm
*
*		This function solve the linear eqns Ax = B:
*
*		|  v0   v1   v2  .. vn-1 | |  a1   |    |  v1   |
*		|  v1   v0   v1  .. vn-2 | |  a2   |    |  v2   |
*		|  v2   v1   v0  .. vn-3 | |  a3   |  = |  ..   |
*		|  ...                   | |  ..   |    |  ..   |
*		|  vn-1 vn-2 ..  .. v0   | |  an   |    |  vn   |
*
*		where A is a symmetric Toeplitz matrix and B
*		in the above format (related to A)
*
*	given:	R = autocorrelated matrix (v0, v1, ... vn) (dim (n+1) x 1)
*	retrn:	x (of Ax = B)
*-----------------------------------------------------------------------------
*/
MATRIX mat_durbin(MATRIX R )
{
	int	i, i1, j, ji ,p;
	MATRIX	W, E, K, A, X;
	
	p = MatRow(R) - 1;
	W = mat_creat( p+2, 1, UNDEFINED );
	E = mat_creat( p+2, 1, UNDEFINED );
	K = mat_creat( p+2, 1, UNDEFINED );
	A = mat_creat( p+2, p+2, UNDEFINED );

	W[0][0] = R[1][0];
	E[0][0] = R[0][0];

	for (i=1; i<=p; i++)
		{
		K[i][0] = W[i-1][0] / E[i-1][0];
		E[i][0] = E[i-1][0] * (1.0 - K[i][0] * K[i][0]);

		A[i][i] = -K[i][0];

		i1 = i-1;
		if (i1 >= 1)
			{
			for (j=1; j<=i1; j++)
				{
				ji = i - j;
				A[j][i] = A[j][i1] - K[i][0] * A[ji][i1];
				}
			}

		if (i != p)
			{
			W[i][0] = R[i+1][0];
			for (j=1; j<=i; j++)
				W[i][0] += A[j][i] * R[i-j+1][0];
			}
		}

	X = mat_creat( p, 1, UNDEFINED );
	for (i=0; i<p; i++)
		{
		X[i][0] = -A[i+1][p];
		}

	mat_free( A );
	mat_free( W );
	mat_free( K );
	mat_free( E );
	return (X);
}

/**************************************************************/
void *lpc_signal(t_lpc *x ,t_floatarg f)
{
     
	signal[i] = f ;

	i++ ;
	if( i == 18)
	{

		lpc( signal, ord  );
		for(i=0;i<ord;i++)
			outlet_float(x->t_ob.te_outlet,tmp_parameter[i]);

	}
	return(void *)x;
}

void lpc_order(t_lpc *x, t_floatarg g)
{
    ord = (int)g ;

}



t_class *lpc_class;


void *lpc_new(t_float f)
{
    t_lpc *x = (t_lpc *)pd_new(lpc_class);
    inlet_new(&x->t_ob, &x->t_ob.ob_pd, gensym("float"), gensym("order"));
	outlet_new(&x->t_ob, gensym("float"));
    post("lpc_new");
	
	
    return (void *)x;
}

void lpc_setup(void)
{
    post("lpc_setup");
    lpc_class = class_new(gensym("lpc"), (t_newmethod)lpc_new, 0,
    	sizeof(t_lpc), 0, 0);
    class_addmethod(lpc_class, (t_method)lpc_signal, gensym("signal"), A_FLOAT, A_NULL);
	class_addmethod(lpc_class, (t_method)lpc_order, gensym("order"), A_FLOAT, 0);
	class_addfloat(lpc_class, lpc_signal);

}

/*************************************************************/



/*
*-----------------------------------------------------------------------------
*	funct:	mat_creat
*	desct:	create a matrix
*	given:  row, col = dimension, type = which kind of matrix
*	retrn:	allocated matrix (use mat_free() to free memory)
*-----------------------------------------------------------------------------
*/
MATRIX	mat_creat( int row,int col,int type )
{
	MATRIX	A;

	if ((A =_mat_creat( row, col )) != NULL)
		{
		return (mat_fill(A, type));
		}
	else
		return (NULL);
}


MATRIX	_mat_creat(int row,int col )
{
	MATBODY	*mat;
	int 	i;

	if ((mat = (MATBODY *)malloc( sizeof(MATHEAD) + sizeof(double *) * row)) == NULL)
		return (mat_error( MAT_MALLOC ));

	for (i=0; i<row; i++)
	{
	if ((*((double **)(&mat->matrix) + i) = (double *)malloc(sizeof(double) * col)) == NULL)
		return (mat_error( MAT_MALLOC ));
	}

	mat->head.row = row;
	mat->head.col = col;

	return (&(mat->matrix));
}

/*
*-----------------------------------------------------------------------------
*	funct:	mat_fill
*	desct:	form a special matrix
*	given:  A = matrix, type = which kind of matrix
*	retrn:	A
*-----------------------------------------------------------------------------
*/
MATRIX mat_fill(MATRIX A,int type )
{
	int	i, j;

	switch (type)
		{
		case UNDEFINED:
			break;
		case ZERO_MATRIX:
		case UNIT_MATRIX:
			for (i=0; i<MatRow(A); i++)
			for (j=0; j<MatCol(A); j++)
				{
				if (type == UNIT_MATRIX)
					{
					if (i==j)
						{
						A[i][j] = 1.0;
						continue;
						}
					}
				A[i][j] = 0.0;
				}
			break;
		}
	return (A);
}

MATRIX mat_error(int errno )
{
	switch( errno )
		{
		case MAT_MALLOC:
			fprintf(stderr, "mat: malloc error\n" );
			break;
		case MAT_FNOTOPEN:
			fprintf(stderr, "mat: fileopen error\n" );
			break;
		case MAT_FNOTGETMAT:
			fprintf(stderr, "fgetmat: matrix read error\n");
			break;
		}

	return (NULL);
}

int mat_free( MATRIX A )
{
	int i;

	if (A == NULL)
		return (0);
	for (i=0; i<MatRow(A); i++)
		{
		free( A[i] );
		}
	free( Mathead(A) );
	return (1);
}



