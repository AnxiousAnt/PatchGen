#define WINDOW_SIZE  128
//int	lpc_wover = 0;
//int	lpc_order = 8;

//int	usestdout = 0;
/*
*----------------------------------------------------------------------- 
* data normalization to (-1,+1)
*-----------------------------------------------------------------------
*/
#define norm_s2d(x)	((unsigned short)(x) == 0x8000? -1 : \
			((double)((short)(x))) / 32767.0)


void normeqn_ac(MATRIX A1,MATRIX A2,float *s,int nn );
MATRIX lpc2(MATRIX A,MATRIX B,float *s,int nn);
void lpc( float *s, int order  );
MATRIX mat_durbin(MATRIX);
MATRIX mat_lsolve_durbin(MATRIX, MATRIX);
int lpcout(MATRIX B,  MATRIX A, int i,int n);



