#include "m_pd.h"


/*********** Comb Filter Implementation ********/
static t_class *comb_tilde_class;
typedef struct _comb_tilde 
{
  t_object  x_obj;
  t_sample f_looptime;
  t_sample f_revtime;
  t_sample f;
  float *del;
  int rpointer;
  int wpointer;
  
} t_comb_tilde;

t_int *comb_tilde_perform(t_int *w)
{
  int i;
  float output ;
  t_comb_tilde *x =  (t_comb_tilde *)(w[1]);
  t_sample  *in1   =       (t_sample *)(w[2]);
  t_sample  *out   =       (t_sample *)(w[3]);
  int size		   =	          (int)(w[4]);
  int delsize=(int)x->f_looptime*44.1;
  for(i=0;i<size;i++)
  {
  x->rpointer++;	 
  while(x->rpointer<0)
	  x->rpointer+=delsize;
  while(x->rpointer>=delsize)
	  x->rpointer-=delsize;

  x->wpointer = x->rpointer-1;
  while(x->wpointer<0)
	  x->wpointer+=delsize;
  while(x->wpointer>=delsize)
	  x->wpointer-=delsize;

  output = x->del[x->rpointer];
  x->del[x->wpointer]=output*(pow(0.001, x->f_looptime/x->f_revtime/441.0))+in1[i]; 
  out[i]= output;				    
      	
  }
	return (w+5);
}


void comb_tilde_dsp(t_comb_tilde *x, t_signal **sp)
{
  dsp_add(comb_tilde_perform, 4, x, sp[0]->s_vec, sp[1]->s_vec, sp[0]->s_n);
}


void comb_tilde_free(t_comb_tilde *x)
{
	freebytes(x->del, 88200);
}

void *comb_tilde_new(t_floatarg f)
{
  
  t_comb_tilde *x = (t_comb_tilde *)pd_new(comb_tilde_class);
  x->f_looptime = f = 1;
  floatinlet_new (&x->x_obj, &x->f_looptime);
  floatinlet_new (&x->x_obj, &x->f_revtime);
  outlet_new(&x->x_obj, &s_signal);
  x->del = (float *)getbytes(sizeof(float)*88200);
  x->rpointer=0;
  x->wpointer=0;
  x->f_revtime=0.1;	  

  return (void *)x;
}


/*********** Delay Implementation *********************/
static t_class *delay_tilde_class;
typedef struct _delay_tilde 
{
  t_object  x_obj;
  t_sample f_delay;
  t_sample f;
  float *del;
  int rpointer;
  int wpointer;

} t_delay_tilde;

t_int *delay_tilde_perform(t_int *w)
{
  int i;
  t_delay_tilde *x =  (t_delay_tilde *)(w[1]);
  t_sample  *in1   =       (t_sample *)(w[2]);
  t_sample  *out   =       (t_sample *)(w[3]);
  int size		   =	          (int)(w[4]);
  for(i=0;i<size;i++,x->rpointer++, x->wpointer++)
  {
	
	  x->del[(x->wpointer-1)%((int)x->f_delay*44)]=in1[i];  
	  out[i]=x->del[(x->rpointer)%((int)x->f_delay*44)];   
  }
	return (w+5);
}

void delay_tilde_dsp(t_delay_tilde *x, t_signal **sp)
{
  dsp_add(delay_tilde_perform, 4, x, sp[0]->s_vec, sp[1]->s_vec, sp[0]->s_n);
}


void delay_tilde_free(t_delay_tilde *x)
{
	freebytes(x->del, 88200);
}

void *delay_tilde_new(t_floatarg f)
{
  
  t_delay_tilde *x = (t_delay_tilde *)pd_new(delay_tilde_class);
  x->f_delay = f;
  floatinlet_new (&x->x_obj, &x->f_delay);
  outlet_new(&x->x_obj, &s_signal);
  x->del = (float *)getbytes(sizeof(float)*88200);
  return (void *)x;
}

/*********** Allpass Filter Implementation ********/
static t_class *allpass_tilde_class;
typedef struct _allpass_tilde 
{
  t_object  x_obj;
  t_sample f_looptime;
  t_sample f_revtime;
  t_sample f;
  float *del;
  int rpointer;
  int wpointer;
  
} t_allpass_tilde;

t_int *allpass_tilde_perform(t_int *w)
{
  int i;
  float output ;
  t_allpass_tilde *x =  (t_allpass_tilde *)(w[1]);
  t_sample  *in1   =       (t_sample *)(w[2]);
  t_sample  *out   =       (t_sample *)(w[3]);
  int size		   =	          (int)(w[4]);
  int delsize=(int)x->f_looptime*44.1;
  for(i=0;i<size;i++)
  {
  x->rpointer++;	 
  while(x->rpointer<0)
	  x->rpointer+=delsize;
  while(x->rpointer>=delsize)
	  x->rpointer-=delsize;

  x->wpointer = x->rpointer-1;
  while(x->wpointer<0)
	  x->wpointer+=delsize;
  while(x->wpointer>=delsize)
	  x->wpointer-=delsize;


  output = x->del[x->rpointer]+in1[i]*-(pow(0.001, x->f_looptime/x->f_revtime/2205));
  x->del[x->wpointer]=output*(pow(0.001, x->f_looptime/x->f_revtime/2205))+in1[i]; 
  out[i]= output;				    
      	
  }
	return (w+5);
}


void allpass_tilde_dsp(t_allpass_tilde *x, t_signal **sp)
{
  dsp_add(allpass_tilde_perform, 4, x, sp[0]->s_vec, sp[1]->s_vec, sp[0]->s_n);
}


void allpass_tilde_free(t_allpass_tilde *x)
{
	freebytes(x->del, 88200);
}

void *allpass_tilde_new(t_floatarg f)
{
  
  t_allpass_tilde *x = (t_allpass_tilde *)pd_new(allpass_tilde_class);
  x->f_looptime = f = 1;
  floatinlet_new (&x->x_obj, &x->f_looptime);
  floatinlet_new (&x->x_obj, &x->f_revtime);
  outlet_new(&x->x_obj, &s_signal);
  x->del = (float *)getbytes(sizeof(float)*88200);
  x->rpointer=0;
  x->wpointer=0;
  x->f_revtime=0.1;	  

  return (void *)x;
}

/*********** Schroeder Reverb Implementation ********/
static t_class *schroeder_tilde_class;
#define gain  (pow(0.001, delsize1/x->f_revtime/1000))
typedef struct _schroeder_tilde 
{
  t_object  x_obj;
  t_sample f_looptime;
  t_sample f_revtime;
  t_sample f;
  float *del1;
  float *del2;
  float *del3;
  float *del4;
  float *del5;
  float *del6;

  int rpointer1;
  int wpointer1;
  int rpointer2;
  int wpointer2;
  int rpointer3;
  int wpointer3;
  int rpointer4;
  int wpointer4;
  int rpointer5;
  int wpointer5;
  int rpointer6;
  int wpointer6;  
  
} t_schroeder_tilde;

t_int *schroeder_tilde_perform(t_int *w)
{
  int i;
  float output1=0, output2=0, output3=0, output4=0, output5=0, output6=0;
  t_schroeder_tilde *x =  (t_schroeder_tilde *)(w[1]);
  t_sample  *in1   =       (t_sample *)(w[2]);
  t_sample  *out   =       (t_sample *)(w[3]);
  int size		   =	          (int)(w[4]);
	int delsize1= 1309.77;//29.7*msec;
	int delsize2= 1636.11;//37.1*msec;
	int delsize3= 1944.81;//41.1*msec;
	int delsize4= 1909.69;//43.7*msec;
	int delsize5= 220.5;  //5*msec;
	int delsize6= 74.97;  //1.7*msec;
	float combine;

float gain1 = (pow(0.001, delsize1/x->f_revtime/44100));
float gain2 = (pow(0.001, delsize2/x->f_revtime/44100));
float gain3 = (pow(0.001, delsize3/x->f_revtime/44100));
float gain4 = (pow(0.001, delsize4/x->f_revtime/44100));


  for(i=0;i<size;i++)
  {
  x->rpointer1++; 
  while(x->rpointer1<0)
	  x->rpointer1+=delsize1;
  while(x->rpointer1>=delsize1)
	  x->rpointer1-=delsize1;

  x->wpointer1 = x->rpointer1-1;
  while(x->wpointer1<0)
	  x->wpointer1+=delsize1;
  while(x->wpointer1>=delsize1)
	  x->wpointer1-=delsize1;
/***************************************/
  x->rpointer2++; 
  while(x->rpointer2<0)	  x->rpointer2+=delsize2;
  while(x->rpointer2>=delsize2)	  x->rpointer2-=delsize2;

  x->wpointer2 = x->rpointer2-1;
  while(x->wpointer2<0)	  x->wpointer2+=delsize2;
  while(x->wpointer2>=delsize2)	  x->wpointer2-=delsize2;
/***************************************/
  x->rpointer3++; 
  while(x->rpointer3<0)	  x->rpointer3+=delsize3;
  while(x->rpointer3>=delsize3)	  x->rpointer3-=delsize3;

  x->wpointer3 = x->rpointer3-1;
  while(x->wpointer3<0)	  x->wpointer3+=delsize3;
  while(x->wpointer3>=delsize3)	  x->wpointer3-=delsize3;
/***************************************/
  x->rpointer4++; 
  while(x->rpointer4<0)	  x->rpointer4+=delsize4;
  while(x->rpointer4>=delsize4)	  x->rpointer4-=delsize4;

  x->wpointer4 = x->rpointer4-1;
  while(x->wpointer4<0)	  x->wpointer4+=delsize4;
  while(x->wpointer4>=delsize4)	  x->wpointer4-=delsize4;
/***************************************/
  x->rpointer5++; 
  while(x->rpointer5<0)	  x->rpointer5+=delsize5;
  while(x->rpointer5>=delsize5)	  x->rpointer5-=delsize5;

  x->wpointer5 = x->rpointer5-1;
  while(x->wpointer5<0)	  x->wpointer5+=delsize5;
  while(x->wpointer5>=delsize5)	  x->wpointer5-=delsize5;
/***************************************/
  x->rpointer6++; 
  while(x->rpointer6<0)	  x->rpointer6+=delsize6;
  while(x->rpointer6>=delsize6)	  x->rpointer6-=delsize6;

  x->wpointer6 = x->rpointer6-1;
  while(x->wpointer6<0)	  x->wpointer6+=delsize6;
  while(x->wpointer6>=delsize6)	  x->wpointer6-=delsize6;

  /**************Comb1*******************/
  output1 = x->del1[x->rpointer1];
  x->del1[x->wpointer1]=(output1*gain1)+in1[i];
  
  /**************Comb2*******************/
  output2 = x->del2[x->rpointer2];
  x->del2[x->wpointer2]=(output2*gain2)+in1[i];
  
  /**************Comb3*******************/
  output3 = x->del3[x->rpointer3];
  x->del3[x->wpointer3]=(output3*gain3)+in1[i]; 

  /**************Comb4*******************/
  output4 = x->del4[x->rpointer4];
  x->del4[x->wpointer4]=(output4*gain4)+in1[i];
    
  combine=output1+output2+output3+output4;
  
  /**************Allpass1****************/
  output5 = x->del5[x->rpointer5]+combine*-(pow(0.001, delsize5/96.83/1000));
  x->del5[x->wpointer5]=output5*(pow(0.001, delsize5/96.83/1000))+combine; 
  
  /**************Allpass2****************/
  output6 = x->del6[x->rpointer6]+output5*-(pow(0.001, delsize6/32.93/1000));
  x->del6[x->wpointer6]=output6*(pow(0.001, delsize6/32.92/1000))+output5; 

  /**************Outsignal***************/
  out[i]= output1;				    
    	
  }
	return (w+5);
}


void schroeder_tilde_dsp(t_schroeder_tilde *x, t_signal **sp)
{
  dsp_add(schroeder_tilde_perform, 4, x, sp[0]->s_vec, sp[1]->s_vec, sp[0]->s_n);
}


void schroeder_tilde_free(t_schroeder_tilde *x)
{
	freebytes(x->del1, 88200);
		freebytes(x->del2, 88200);
			freebytes(x->del3, 88200);
				freebytes(x->del4, 88200);
					freebytes(x->del5, 88200);
						freebytes(x->del6, 88200);
}

void *schroeder_tilde_new(t_floatarg f)
{
  
  t_schroeder_tilde *x = (t_schroeder_tilde *)pd_new(schroeder_tilde_class);
  x->f_looptime = f = 1;
//  floatinlet_new (&x->x_obj, &x->f_looptime);
  floatinlet_new (&x->x_obj, &x->f_revtime);
  outlet_new(&x->x_obj, &s_signal);
  x->del1 = (float *)getbytes(sizeof(float)*88200);
  x->del2 = (float *)getbytes(sizeof(float)*88200);
  x->del3 = (float *)getbytes(sizeof(float)*88200);
  x->del4 = (float *)getbytes(sizeof(float)*88200);
  x->del5 = (float *)getbytes(sizeof(float)*88200);
  x->del6 = (float *)getbytes(sizeof(float)*88200);

  x->rpointer1=0;
  x->wpointer1=0;
  x->rpointer2=0;
  x->wpointer2=0;
  x->rpointer3=0;
  x->wpointer3=0;
  x->rpointer4=0;
  x->wpointer4=0;
  x->rpointer5=0;
  x->wpointer5=0;
  x->rpointer6=0;
  x->wpointer6=0;
  x->f_revtime=0.1;	  

  return (void *)x;
}



/************ ReverbDSP Setup **********/
/************ Comb Filter **************/
void ReverbDSP_setup(void)
{

post("\nReverbDSP Library                           ");
post("Written and Compiled by Rory Walsh Jan 2002\n ");

  comb_tilde_class = class_new(gensym("comb~"),
  (t_newmethod)comb_tilde_new,
   (t_method)comb_tilde_free, sizeof(t_comb_tilde), 
        CLASS_DEFAULT,  A_DEFFLOAT, 0);
  class_addmethod(comb_tilde_class,
        (t_method)comb_tilde_dsp, gensym("dsp"), 0);
  CLASS_MAINSIGNALIN(comb_tilde_class, t_comb_tilde, f);

 /************** Delay *****************/
  delay_tilde_class = class_new(gensym("delay~"),
  (t_newmethod)delay_tilde_new,
   (t_method)delay_tilde_free, sizeof(t_delay_tilde), 
        CLASS_DEFAULT,  A_DEFFLOAT, 0);
  class_addmethod(delay_tilde_class,
        (t_method)delay_tilde_dsp, gensym("dsp"), 0);
  CLASS_MAINSIGNALIN(delay_tilde_class, t_delay_tilde, f);
/****************** Allpass *************/

  allpass_tilde_class = class_new(gensym("allpass~"),
  (t_newmethod)allpass_tilde_new,
   (t_method)allpass_tilde_free, sizeof(t_allpass_tilde), 
        CLASS_DEFAULT,  A_DEFFLOAT, 0);
  class_addmethod(allpass_tilde_class,
        (t_method)allpass_tilde_dsp, gensym("dsp"), 0);
  CLASS_MAINSIGNALIN(allpass_tilde_class, t_allpass_tilde, f);
/***************** Schroeder **************/
 
  schroeder_tilde_class = class_new(gensym("schroeder~"),
  (t_newmethod)schroeder_tilde_new,
   (t_method)schroeder_tilde_free, sizeof(t_schroeder_tilde), 
        CLASS_DEFAULT,  A_DEFFLOAT, 0);
  class_addmethod(schroeder_tilde_class,
        (t_method)schroeder_tilde_dsp, gensym("dsp"), 0);
  CLASS_MAINSIGNALIN(schroeder_tilde_class, t_schroeder_tilde, f);


}
