#ifndef _EXT_NUMC_H_
#define _EXT_NUMC_H_

// definition moved to ext_maxtypes.h

#endif /* _EXT_NUMC_H_ */
