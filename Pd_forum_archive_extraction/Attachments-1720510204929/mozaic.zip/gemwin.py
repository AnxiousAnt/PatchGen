import pyext
import sys

class control(pyext._class):
    _inlets = 1
    _outlets = 0
    
    def __init__(self):
        self._detach(1)
        self.init_1()
        
    def init_1(self):
        self._send('gemwin', 'create', ())
        self._send('gemwin', 1)

    def redraw(self):
        self._send('gemwin', 'border', (1,))
        return
    
        self._send('gemwin', 0)
        self._send('gemwin', 'destroy', ())
        self.init_1()

    def s1024x768_1(self):
        self._send('gemwin', 'dimen', (1024, 768))
        self._send('gemwin', 'offset', (10, 10))
        self.redraw()
        
    def s800x600_1(self):
        self._send('gemwin', 'dimen', (800, 600))
        self._send('gemwin', 'offset', (10, 10))
        self.redraw()
        
    def s400x300_1(self):
        self._send('gemwin', 'dimen', (400, 300))
        self._send('gemwin', 'offset', (10, 10))
        self.redraw()
        
    def s300x200_1(self):
        self._send('gemwin', 'dimen', (300, 200))
        self._send('gemwin', 'offset', (10, 10))
        self.redraw()
