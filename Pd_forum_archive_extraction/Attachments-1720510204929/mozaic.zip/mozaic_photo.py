import pyext
import glob
import os
import math
from commands import getstatusoutput
import random

# two classes in this file:
# Photo
#   - it needs imagemagick to get the size of images
#
# Mozaic

class Photo:
    def __init__(self, pyext, path, no):
        self.pyext = pyext
        self.no = no
        self.path = path

        if self.get_wh():
            self.compute_wh(.5,.5)
            self.shape(self.nw, self.nh)

        self.load()
        
    def load(self):
        self.pyext._send(str(self.no)+'-image','open', (self.path,))
        self.on()

    def off(self):
        self.pyext._send(str(self.no)+'-gemhead', 0)
        
    def on(self):
        self.pyext._send(str(self.no)+'-gemhead', 1)

    def start(self):
        self.on()
        
    def shape(self, rw, rh):
        self.pyext._send(str(self.no)+'-rw', rw)
        self.pyext._send(str(self.no)+'-rh', rh)

    def pos(self, tx, ty):
        self.pyext._send(str(self.no)+'-tx', tx)
        self.pyext._send(str(self.no)+'-ty', ty)

    def get_wh(self):
        try:
            stat, output = getstatusoutput( 'identify "'+self.path+'"')
            out = output.split(' ')
            out = out[2]
            w,h = out.split('x')
            self.w = int(w)
            self.h = int(h)
        except: return False
        return True
    
    def compute_wh(self,W,H):
        w = self.w; h = self.h
        D = W/H; dw = W/w; dh = H/h; d = w/h
        if D>d: dt = dw*d/D; nw = w*dh; nh = h*dh
        else: dt = dh*D/d; nw = w*dw; nh = h*dw
        # rescale in right dimensions
        if nw > W: nh = W/nw*nh; nw = W
        if nh > H: nw = H/nh*nw; nh = H
        self.nw = nw
        self.nh = nh
        

    def set(self, no):
        self.cu = no
        
    def cuwh(self):
        return self.wh[self.cu]
    


class mozaic(pyext._class):
    _inlets = 1
    _outlets = 0

    def __init__(self):
        self._detach(1)

    def init_1(self):
        self.no = 0
        self.sens = 1
        self.fphotos = glob.glob('/data/urban_man/photos/pietons/pieton_rouge*.jpg')
        print self.fphotos
        self.nb = len(self.fphotos)
        self.make()
        
    def make(self):
        self.photos = []
        for no in range(self.nb):
            print no
            self._send('dyn', 'del', ('p%d'%no,))
            self._send('dyn', 'newobj', ('.', 'p%d'%no, 'photo', no))
            self.photos.append(Photo(self, self.fphotos[no], no))
            self.photos[no].on()
            
    def dispatch_1(self):
        for no in range(self.nb):
            x = -random.random()*8.+4.
            y = -random.random()*6.+3.
            self.photos[no].pos(x,y)
            
    def all_off_1(self):
        for no in range(self.nb):
            self.photos[no].off()

    def all_on_1(self):
        for no in range(self.nb):
            self.photos[no].on()
        
    def bang_1(self):
        self.no += self.sens
        if self.no==self.nb:
            self.sens = -1
        if self.no==-1:
            self.dispatch_1()
            self.sens = +1

        # turn on/off image display
        if self.sens==-1:
            self._send(str(self.no)+'-gemhead', 0)
        else:
            self._send(str(self.no)+'-gemhead', 1)

