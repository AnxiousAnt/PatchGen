Paf is copyright (C) 1999 Miller Puckette.
Permission is granted to use this software for any purpose, commercial
or noncommercial, as long as this notice is included with all copies.

NEITHER THE AUTHORS NOR THEIR EMPLOYERS MAKE ANY WARRANTY, EXPRESS OR IMPLIED,
IN CONNECTION WITH THIS SOFTWARE!

----------------------------------------------------------------------------

This is the README file for the "paf" percussion detector.  This software
is available from http://www.crca.ucsd.edu/~msp as part of the "toys"
library.  - msp@ucsd.edu
