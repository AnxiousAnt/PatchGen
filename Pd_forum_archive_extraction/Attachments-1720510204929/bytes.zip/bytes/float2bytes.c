#include "m_pd.h"

typedef struct float2bytes
{
  	t_object x_ob;
	t_outlet *f_out;
	t_float endianness;
} 	t_float2bytes;

typedef unsigned char uchar;

void float2bytes_float(t_float2bytes *x, t_floatarg f)
{
	t_atom output[4];     
	uchar f_int = *((uchar*)&f);
	if (x->endianness == 0) { // little endian
		SETFLOAT(&output[0],*((uchar*)&f+0));
		SETFLOAT(&output[1],*((uchar*)&f+1));
		SETFLOAT(&output[2],*((uchar*)&f+2));
		SETFLOAT(&output[3],*((uchar*)&f+3));
	} 
	else {
		SETFLOAT(&output[0],*((uchar*)&f+3));
		SETFLOAT(&output[1],*((uchar*)&f+2));
		SETFLOAT(&output[2],*((uchar*)&f+1));
		SETFLOAT(&output[3],*((uchar*)&f+0));	
	}	
	outlet_list(x->f_out,0,4,output);
}

t_class *float2bytes_class;

void *float2bytes_new(t_floatarg endian)
{
    t_float2bytes *x = (t_float2bytes *)pd_new(float2bytes_class);
	x->f_out = outlet_new(&x->x_ob,0);
	x->endianness = endian;
    return (void *)x;
	
}


void float2bytes_setup(void)
{
    float2bytes_class = class_new(gensym("float2bytes"), (t_newmethod)float2bytes_new, 0,
    	sizeof(t_float2bytes),CLASS_DEFAULT,A_DEFFLOAT, 0);
	class_addfloat(float2bytes_class,float2bytes_float);
}

