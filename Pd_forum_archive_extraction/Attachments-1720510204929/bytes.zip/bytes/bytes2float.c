#include "m_pd.h"

typedef struct bytes2float
{
	t_object x_ob;
	t_outlet *f_out;
	t_float endianness;
} 	t_bytes2float;

typedef unsigned char uchar;

void bytes2float_list(t_bytes2float *x, t_symbol *s, int argc, t_atom *argv)
{

	int size_output;
	int i;
	t_float tmp;

    if (((argc % 4) != 0) && (argc > 0)){
		error("bytes2float: usage [list f f f f(");
	}
	else {
		size_output = argc / 4;
		t_atom output[size_output];   
		if (x->endianness == 0) { // little endian
			for (i=0;i<size_output;i++) {
				tmp = 0;
				*((uchar*)(&tmp) + 3) = atom_getfloatarg(3+4*i,argc,argv);	
				*((uchar*)(&tmp) + 2) = atom_getfloatarg(2+4*i,argc,argv);
				*((uchar*)(&tmp) + 1) = atom_getfloatarg(1+4*i,argc,argv);
				*((uchar*)(&tmp) + 0) = atom_getfloatarg(0+4*i,argc,argv);
				SETFLOAT(&output[i],tmp);
			}
		}
		else {
			for (i=0;i<size_output;i++) {
				tmp = 0;
				*((uchar*)(&tmp) + 3) = atom_getfloatarg(0+4*i,argc,argv);	
				*((uchar*)(&tmp) + 2) = atom_getfloatarg(1+4*i,argc,argv);
				*((uchar*)(&tmp) + 1) = atom_getfloatarg(2+4*i,argc,argv);
				*((uchar*)(&tmp) + 0) = atom_getfloatarg(3+4*i,argc,argv);
				SETFLOAT(&output[i],tmp);
			}
		}
		outlet_list(x->f_out,0,size_output,output);
	}
}

t_class *bytes2float_class;

void *bytes2float_new(t_floatarg endian)
{
    t_bytes2float *x = (t_bytes2float *)pd_new(bytes2float_class);
	x->f_out = outlet_new(&x->x_ob, 0);
	x->endianness = endian;
    return (void *)x;
}

void bytes2float_setup(void)
{
    bytes2float_class = class_new(gensym("bytes2float"), (t_newmethod)bytes2float_new, 0,
    	sizeof(t_bytes2float),CLASS_DEFAULT,A_DEFFLOAT, 0);
	class_addlist(bytes2float_class,bytes2float_list);
}

