from decimal import Decimal
from operator import *

def any2dec(*a):
    if type(a) == list or type(a) == tuple:
        return Decimal("".join(map(str,a)))
    else:
        return Decimal(str(a))   
    
def dec2list(d):
    return list(str(d))
