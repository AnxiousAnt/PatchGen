// Include files
#include <FTIR_Tools.h>


/* ************************************************************ */
/* Tracks blobs and outputs image in outlet_0                   */
/* and a list of blob numbers and positions in outlet_1         */
/* iem matrix style                                             */
/* ************************************************************ */

//Pd class and structure
static t_class *ftir_tracker_class;

typedef struct _ftir_tracker {
  t_object  x_obj;
  t_int i_videofile;
  t_int i_threshold, i_center, i_box;
  t_symbol *x_threshold;
  t_symbol *x_center;
  t_symbol *x_box;
  t_outlet *outlet0, *outlet1;
  } t_ftir_tracker;
  
/* ********************************************* */
/* opencv stuff                                  */
/* ********************************************* */
					 
// delcare an image
	IplImage *frame = 0;
	IplImage *bw_frame = 0;
		
/* ********************************************* */
/* back to Pd stuff                              */
/* ********************************************* */

//Pd methods  
void ftir_tracker_file(t_ftir_tracker *x)
{
	x->i_videofile = frame;
}

void ftir_tracker_threshold(t_ftir_tracker *x, t_floatarg f)
{
  x->i_threshold = f;
}

void ftir_tracker_center(t_ftir_tracker *x, t_symbol *c)
{
  x->x_center = c;
}

void ftir_tracker_box(t_ftir_tracker *x, t_symbol *b)
{
  x->x_box = b;
}

void *ftir_tracker_new(t_symbol *s, int argc, t_atom *argv);

/* ********************************************* */
/* opencv stuff                                  */
/* ********************************************* */


//turn movie to frame and process a version to black and white.
//blobslib only likes an 8 bit 1 channel image.
	bw_frame = cvCreateImage(cvSize(frame->width,frame->height), IPL_DEPTH_8U, 1);
	cvCvtColor(frame, bw_frame, CV_BGR2GRAY);
	{

	}
	
	// FIND AND MARK THE BLOBS
	// delcare a set of blob results
	CBlobResult blobs;
	// get the blobs from the image, with no mask, using a threshold of "f"
	blobs = CBlobResult( bw_frame, NULL, f, false );
	blobs.Filter( blobs, B_INCLUDE, CBlobGetArea(), B_LESS, 5000 );// area <150
	blobs.Filter( blobs, B_INCLUDE, CBlobGetArea(), B_GREATER, 0 );// area <150
	//blobs.Filter( blobs, B_EXCLUDE, CBlobGetArea(), B_INSIDE, 2, 1 );
	// mark the blobs on the image
	int i;
	// delare a single blob
	CBlob Blob;
	// some vars
	int iMaxx, iMinx, iMaxy, iMiny, iMeanx, iMeany;
	// for each blob
	for  (i=0; i<blobs.GetNumBlobs(); i++)
	{
		// get the blob info
		Blob = blobs.GetBlob(i);
		// get max, and min co-ordinates
		iMaxx=Blob.MaxX();
		iMinx=Blob.MinX();
		iMaxy=Blob.MaxY();
		iMiny=Blob.MinY();
		// find the average of the blob (i.e. estimate its centre)
		iMeanx=(iMinx+iMaxx)/2;
		iMeany=(iMiny+iMaxy)/2;
		// print blob info
		//printf("%d (%d,%d)", i, iMeanx, iMeany);
		
		// get blob centres might give better center point?
		//CBlobGetXCenter getXc;
		//CBlobGetYCenter getYc;
		//double blobCentre[2];
		//blobCentre[0] = getXc(Blob);
		//blobCentre[1] = getYc(Blob);
		//post("\n\t\tCentre: (%.0f,%.0f)", blobCentre[0], blobCentre[1]);
/* ********************************************* */
/* back to Pd stuff                              */
/* ********************************************* */


//Pd outlets
	t_ftir_tracker *x = (t_ftir_tracker *)pd_new(ftir_tracker_class);
	outlet0 = outlet_new(&x->x_obj, &s_anything);
	outlet1 = outlet_new(&x->x_obj, &s_list);
	outlet_anything(outlet1, gensym("matrix"), i, iMeanx, iMeany);//outlet list
		
if (argv == c)
{
	// mark centre
		cvLine( frame, cvPoint(iMeanx, iMeany), cvPoint(iMeanx, iMeany), CV_RGB(150, 150 , 150), 4, 8, 0 );
		}
if (argv == b)
{
	// mark box around blob
		cvRectangle( frame, cvPoint(iMinx , iMiny ), cvPoint ( iMaxx, iMaxy ), CV_RGB(250, 0, 0), 1, 8, 0 );
		}
	
	outlet_anything(x->outlet0, &x->frame);//outlet frames
	//return (void *)x; //this is not working?
}

void ftir_tracker_setup(void)
{
	ftir_tracker_class = class_new(gensym("FTIR_Tracker"),
	(t_newmethod)ftir_tracker_new,
	0, sizeof(t_ftir_tracker),
	CLASS_DEFAULT, A_GIMME, 0);

class_addmethod(counter_class,
        (t_method)ftir_tracker_threshold, gensym("threshold"), A_DEFFLOAT, 0);	
class_addmethod(ftir_tracker_class,
	(t_method)ftir_tracker_center, gensym("mark_center"), A_NULL);
class_addmethod(ftir_tracker_class,
	(t_method)ftir_tracker_box, gensym("mark_boundingbox"), A_NULL);

class_sethelpsymbol(ftir_tracker_class, gensym("help-FTIR_Tools"));
}