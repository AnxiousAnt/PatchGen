// Include files
#include <FTIR_Tools.h>
#include <cvcam.h>
/* ************************************************************ */
/* Reads from camera and outputs frames...                      */
/* ************************************************************ */

//Pd class and structure
static t_class *ftir_cam_class;

typedef struct _ftir_cam {
  t_object  x_obj;
  t_int i_videofile;
  t_outlet *x_outlet;
  t_symbol *x_start, x_stop;
  } t_ftir_cam;

/* ********************************************* */
/* opencv stuff                                  */
/* ********************************************* */
					 
// delcare an image
	CvCapture* cam_capture = 0;
	IplImage *frame = 0;
	int main(int argc, char* argv[])
	
/* ********************************************* */
/* back to Pd stuff                              */
/* ********************************************* */
  

//Pd methods
void ftir_cam_start(t_ftir_cam *x, t_symbol *x_start)
{
	x->x_start = cvcamGetCamerasCount();
	
	//some more opencv stuff dealing with camera selection
	post("Cameras detected: %d \n",cameras);
	int * out;
	int nselected = cvcamSelectCamera(&out);
	int cameraSelected = -1;

	if(nselected>0)	cameraSelected = out[0];

	

	if (cameraSelected > -1)
	{
	post("The selected camera is camera number %d \n", cameraSelected);
	post("Starting Camera %d \n",cameraSelected );
}

void ftir_cam_stop(t_ftir_cam *x, t_symbol *x_stop)
{
	x->x_stop =	cvcamStop();
				cvcamExit();  //AND EXIT
				post("Camera stopped. \n");
	}
	
void *ftir_cam_new(t_symbol *s, int argc, t_atom *argv);

 
/* ********************************************* */
/* opencv stuff                                  */
/* ********************************************* */

// starting camera #1

	int w = 640; //RENDER-WIDTH
	int h = 480; //RENDER-HEIGHT
	int t=0;
	cvcamSetProperty(cameraSelected,CVCAM_RNDWIDTH , &w);
	cvcamSetProperty(cameraSelected,CVCAM_RNDHEIGHT , &h);
	cvcamSetProperty(cameraSelected,CVCAM_PROP_ENABLE, &t);
	cvcamSetProperty(cameraSelected,CVCAM_PROP_RENDER, &t);
	//cvcamSetProperty(0,CVCAM_PROP_WINDOW, NULL);
	cvcamInit();
	cvcamStart();
	post("It's working !!! \n");
	
//opencv capture image
{
	cam_capture=cvCaptureFromCAM(cameraSelected);
	
	//opencv turn movie to frame
	frame = cvQueryFrame(cam_capture);
	}
	
/* ********************************************* */
/* back to Pd stuff                              */
/* ********************************************* */

//Pd outlets
}

	t_ftir_cam *x = (t_ftir_cam *)pd_new(ftir_cam_class);
	x->x_outlet = outlet_new(&x->x_obj, &s_anything);
	outlet_anything(x->x_outlet, &x->frame);//outlet frames
	return (void *)x; //this is not working?
}

//Pd extensions of class
void ftir_cam_setup(void) {
	ftir_cam_class = class_new(gensym("FTIR_Cam"),
	(t_newmethod)ftir_cam_new,
	0, sizeof(t_ftir_cam),
	CLASS_DEFAULT, A_GIMME, 0);
	
class_addmethod(ftir_cam_class,
	(t_method)ftir_cam_start, gensym("start"), A_NULL);
class_addmethod(ftir_cam_class,
	(t_method)ftir_cam_stop, gensym("stop"), A_NULL);

class_sethelpsymbol(ftir_cam_class, gensym("help-FTIR_Tools"));
}