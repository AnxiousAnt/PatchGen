/* **************************************************************** */
/* FTIR_Tools   V. 0.01                                             */
/* ---------------------------------------------------------------- */
/* FTIR_Tools is a Pure Data External that uses the opencv library  */
/* http://sourceforge.net/projects/opencvlibrary/                   */
/* it also uses the cvBlobsLib                                      */
/* http://opencvlibrary.sourceforge.net/cvBlobsLib                  */
/* **************************************************************** */

// Include files
#include <stdlib.h>
#include <math.h>
// Pd
#include "m_pd.h"
// OpenCV
#include <cv.h>
#include <cxcore.h>
#include <highgui.h>
// Blobs
#include <Blob.h>
#include <BlobResult.h>

#ifndef INCLUDE_FTIR_TOOLS_H_
#define INCLUDE_FTIR_TOOLS_H_

#define VERSION "0.01"

#define FTIR_USEVAR(x) x=x

#endif

//static t_class *FTIR_Tools_class;

//typedef struct _FTIR_Tools {
//  t_object  x_obj;
//  init x_n;
//  t_atom *x_list;
//} t_FTIR_Tools;

//{

//#ifndef FTIR_TOOLS
//static void ftir_register(char*object){
//	if(object!=0){
//	post("[%s] part of FTIR_Tools-%s (compiled: "__DATE__")", object, VERSION);
//	post("written by Alain Ramos, 2007 with no warranties implied.");
//	}
//}
//#else
//static void ftir_register(char*object){object=0;}

#endif // INCLUDE_FTIR_TOOLS_H_