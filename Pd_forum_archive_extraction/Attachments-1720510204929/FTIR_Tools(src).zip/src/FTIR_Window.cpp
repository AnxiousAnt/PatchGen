// Include files
#include <FTIR_Tools.h>


/* ************************************************************ */
/* Creates Window to output quicktime files...                  */
/* ************************************************************ */


static t_class *ftir_window_class;

typedef struct _ftir_window {
  t_object  x_obj;
  t_int i_videofile;
  t_int i_open, i_close;
  t_symbol *x_open;
  t_symbol *x_close;
  t_outlet *x_outlet;
  } t_ftir_window;
  
  /* ********************************************* */
/* opencv stuff                                  */
/* ********************************************* */
					 
// delcare an image
	IplImage *frame = 0;
	
/* ********************************************* */
/* back to Pd stuff                              */
/* ********************************************* */
  
  void ftir_window_file(t_ftir_window *x)
{
	x->i_videofile = frame;
}

void ftir_window_open(t_ftir_window *x, t_symbol *o)
{
  x->x_open = o;
}

void ftir_window_close(t_ftir_window *x, t_symbol *c)
{
  x->x_close = c;
}

void *ftir_window_new(t_symbol *s, int argc, t_atom *argv);

/* ********************************************* */
/* opencv stuff                                  */
/* ********************************************* */
	
// display the image

char ch = 0;


{

if (argc == o)
{
	cvNamedWindow("FTIR_Window",CV_WINDOW_AUTOSIZE);
	cvShowImage("FTIR_Window",frame);
	
	// keep image 'til keypress
	ch=cvWaitKey(20);
}

if (argc == c)
 
	cvWaitkey(0);
	cvReleaseImage(&frame)
	return 0;
	
}

/* ********************************************* */
/* back to Pd stuff                              */
/* ********************************************* */

void ftir_window_setup(void)
{
	ftir_window_class = class_new(gensym("FTIR_Window"),
	(t_newmethod)ftir_window_new,
	0, sizeof(t_ftir_window),
	CLASS_DEFAULT, A_GIMME, 0);
	
class_addmethod(ftir_window_class,
	(t_method)ftir_window_open, gensym("open"), A_NULL);
class_addmethod(ftir_window_class,
	(t_method)ftir_window_close, gensym("close"), A_NULL);

class_sethelpsymbol(ftir_window_class, gensym("help-FTIR_Tools"));
}