// Include files
#include <FTIR_Tools.h>

/* ************************************************************ */
/* Reads and outputs frames...                                  */
/* ************************************************************ */

//Pd class and structure
static t_class *ftir_vplayer_class;

typedef struct _ftir_vplayer {
  t_object  x_obj;
  t_int i_videofile;
  t_int i_name;
  t_outlet *x_outlet;
  t_symbol *x_name;
  } t_ftir_vplayer;

/* ********************************************* */
/* opencv stuff                                  */
/* ********************************************* */
					 
// delcare an image
	CvCapture* movie_capture = 0;
	IplImage *frame = 0;
	
/* ********************************************* */
/* back to Pd stuff                              */
/* ********************************************* */
  

//Pd methods
void ftir_vplayer_path(t_ftir_vplayer *x, t_symbol *name)
{
	x->x_name = name->frame;
	
	post("%s: opening %s", x->x_name->s_name, name->s_name);
}

void *ftir_vplayer_new(t_symbol *s, int argc, t_atom *argv);

 
/* ********************************************* */
/* opencv stuff                                  */
/* ********************************************* */

	
//opencv capture image
int main(int argc, char *argv)
	{
	char ch = 0;
	movie_capture=cvCaptureFromFile(argv);
	while(ch != 'e')
	{
	
	if(!movie_capture) {
	post("Cannot open avi file %s\n", argv);
	exit(0);
	}
	
	if(!cvGrabFrame(movie_capture)) {
	post("Cannot grab a frame\n");
	exit(0);
	}
	
	{
	//opencv turn movie to frame
	frame = cvQueryFrame(movie_capture);
	}
	
/* ********************************************* */
/* back to Pd stuff                              */
/* ********************************************* */

//Pd outlets
}

	t_ftir_vplayer *x = (t_ftir_vplayer *)pd_new(ftir_vplayer_class);
	x->x_outlet = outlet_new(&x->x_obj, &s_anything);
	outlet_anything(x->x_outlet, &x->frame);//outlet frames
	//return (void *)x; //this is not working?
}

//Pd extensions of class
void ftir_vplayer_setup(void) {
	ftir_vplayer_class = class_new(gensym("FTIR_VPlayer"),
	(t_newmethod)ftir_vplayer_new,
	0, sizeof(t_ftir_vplayer),
	CLASS_DEFAULT, A_GIMME, 0);
	
class_addmethod(ftir_vplayer_class,
	(t_method)ftir_vplayer_path, gensym("open"), A_SYMBOL, A_NULL);

class_sethelpsymbol(ftir_vplayer_class, gensym("help-FTIR_Tools"));
}