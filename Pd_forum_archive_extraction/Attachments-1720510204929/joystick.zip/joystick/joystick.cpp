/*JOYSTICK object for PD
  by Joseph A. Sarlo
  POV updates by David J. Merrill <dmerrill@media.mit.edu>
*/

#include <WINDOWS.H>
#include <MMSYSTEM.H>

#include "m_pd.h"

#define DEF_SCALE         1
#define DEF_DELTIME       5
#define MAX_AXIS_OUTS     10
#define MAX_BUTTON_OUTS   32
#define MAX_JOY_DEVS      16

// DJM
#define POV_DIR_UP 0
#define POV_DIR_DOWN 1
#define POV_DIR_LEFT 2
#define POV_DIR_RIGHT 3
#define POV_DIR_CENTER 4

typedef struct _joystick
{
    t_object t_ob;
    JOYINFOEX x_joyInfoEx;
    int x_joyDevNum;
    float x_scale;
    float x_translation;
    t_outlet *x_axis_out[MAX_AXIS_OUTS];

  // DJM
    t_outlet *x_POV_out[2];   
    t_outlet *x_button_num_out;
    t_outlet *x_button_val_out;
    t_clock *x_clock;
    double x_deltime;
    int x_joy_buttons;
    int x_joy_axes;
    int x_has_POV;
    int x_button_val[MAX_BUTTON_OUTS];
    int x_axis_val[MAX_AXIS_OUTS];

  // DJM
    DWORD x_POV_val[1];
    int x_former_POV_val;

    DWORD *x_axes_ptr[MAX_AXIS_OUTS];

  // DJM
    DWORD *x_POV_ptr[1];
}t_joystick;

t_class *joystick_class;

void *joystick_new(t_float deltime,
				   t_float scale,
				   t_float translation,
				   t_float devParm);
void joystick_setup(void);
void joystick_read(t_joystick *x);
void joystick_change_deltime(t_joystick *x, t_float deltime);
void joystick_free(t_joystick *x);

void *joystick_new(t_float deltime,
				   t_float scale,
				   t_float translation,
				   t_float devParm)
{
    int i, devNum, flag, num_axes, num_buttons;
    JOYCAPS jscaps;
    MMRESULT errCode;
 
    t_joystick *x = (t_joystick *)pd_new(joystick_class);
    x->x_joyInfoEx.dwSize = sizeof(x->x_joyInfoEx);
    x->x_joyInfoEx.dwFlags = JOY_RETURNALL;
    x->x_clock = clock_new (x, (t_method)joystick_read);
    flag = 0;
	if (devParm > 0)
	{
		int devParmID = (int)devParm;
		if ((devParmID < 1) || (devParmID > 16))
		{
			post("joystick ID must be between 1 and 16");
		}
		else
		{
			devNum = JOYSTICKID1 + devParmID - 1;
			errCode = joyGetPosEx(devNum, &x->x_joyInfoEx);
			if (errCode == MMSYSERR_NOERROR)
				flag = 1;
		}
	}
	else
	{
		devNum = JOYSTICKID1 - 1;
		while ((devNum < JOYSTICKID1 + 16) && (flag == 0))
		{
			devNum++;
			errCode = joyGetPosEx(devNum, &x->x_joyInfoEx);
			if (errCode == MMSYSERR_NOERROR)
				flag = 1;
		}
	}
    if (flag)
    {
        x->x_joyDevNum = devNum;
        post("using joystick %d", x->x_joyDevNum - JOYSTICKID1 + 1);
        joyGetDevCaps(x->x_joyDevNum, &jscaps, sizeof(jscaps));
        if (deltime == 0)
            x->x_deltime = DEF_DELTIME;
        else
            x->x_deltime = (int)deltime;
        if (scale == 0)
            x->x_scale = DEF_SCALE;
        else
            x->x_scale = scale;
        x->x_translation = translation;
        num_axes = jscaps.wNumAxes;

	// DJM
	x->x_has_POV = jscaps.wCaps & JOYCAPS_HASPOV;

        num_buttons = jscaps.wNumButtons;
        if (num_axes > MAX_AXIS_OUTS)
            x->x_joy_axes = MAX_AXIS_OUTS;
        else
            x->x_joy_axes = num_axes;
        if (num_buttons > MAX_BUTTON_OUTS)
            x->x_joy_buttons = MAX_BUTTON_OUTS;
        else
            x->x_joy_buttons = num_buttons;
        for (i = 0; i < x->x_joy_axes; i++)
        {
            x->x_axis_out[i] = outlet_new(&x->t_ob, &s_float);
            x->x_axis_val[i] = 0;
        }

	// DJM (set up POV outlets)
	if (x->x_has_POV)
	{
	  // X
	  x->x_POV_out[0] = outlet_new(&x->t_ob, &s_float);

	  // Y
	  x->x_POV_out[1] = outlet_new(&x->t_ob, &s_float);

	  x->x_POV_val[0] = 0;
	  x->x_former_POV_val = -1;
	}
	
        for (i = 0; i < x->x_joy_buttons; i++)
            x->x_button_val[i] = 0;
        x->x_button_num_out = outlet_new(&x->t_ob, &s_float);
        x->x_button_val_out = outlet_new(&x->t_ob, &s_float);
        clock_delay (x->x_clock, x->x_deltime);
        post ("configuring joystick:");
        post ("  found %d axes", x->x_joy_axes);
        post ("  found %d buttons", x->x_joy_buttons);
        x->x_axes_ptr[0] = &(x->x_joyInfoEx.dwXpos);
        x->x_axes_ptr[1] = &(x->x_joyInfoEx.dwYpos);
        x->x_axes_ptr[2] = &(x->x_joyInfoEx.dwZpos);
        x->x_axes_ptr[3] = &(x->x_joyInfoEx.dwRpos);
        x->x_axes_ptr[4] = &(x->x_joyInfoEx.dwUpos);
        x->x_axes_ptr[5] = &(x->x_joyInfoEx.dwVpos);

	// DJM
	x->x_POV_ptr[0] = &(x->x_joyInfoEx.dwPOV);
    }
    else
    {
        post ("no usable joysticks found");
        post ("last joystick device reported error %d:", errCode);
        if (errCode == JOYERR_PARMS)
            post ("    invalid joystick device ID");
        if (errCode == MMSYSERR_NODRIVER)
            post ("    no joystick driver found");
        if (errCode == JOYERR_UNPLUGGED)
            post ("    no joysticks found");
        if (errCode == MMSYSERR_INVALPARAM)
            post ("    invalid joystick parameter");
        if (errCode == MMSYSERR_BADDEVICEID)
            post ("    invalid joystick device");
 
    }
    return (void *)x;
}
void joystick_setup(void)
{
    post ("joystick object loaded (J. Sarlo), modified by dmerrill");
    joystick_class = class_new(gensym("joystick"),
							   (t_newmethod)joystick_new,
                               (t_method)joystick_free,
							   sizeof(t_joystick),
							   0,
							   A_DEFFLOAT,
							   A_DEFFLOAT,
                               A_DEFFLOAT,
							   A_DEFFLOAT,
							   0);
    class_addfloat(joystick_class, joystick_change_deltime);
}

void joystick_read(t_joystick *x)
{
    int i;

    joyGetPosEx(x->x_joyDevNum, &x->x_joyInfoEx);
    for (i = 0; i < x->x_joy_axes; i++)
        if ((int)(*(x->x_axes_ptr[i])) != x->x_axis_val[i])
        {
            outlet_float (x->x_axis_out[i],
                          ((float)(*(x->x_axes_ptr[i])) + x->x_translation) / x->x_scale);
            x->x_axis_val[i] = (int)(*(x->x_axes_ptr[i]));
        }

    // DJM
    // check if POV state is different from last time
    if (x->x_has_POV && *(x->x_POV_ptr[0]) != x->x_POV_val[0]) 
      {

	// post("different state");
	// store this for next time
	x->x_POV_val[0] = *(x->x_POV_ptr[0]);

	// send a zero from whatever it was last time
	switch (x->x_former_POV_val)	
	  {
	  case POV_DIR_UP:
	  case POV_DIR_DOWN:
	    outlet_float (x->x_POV_out[0], (float)0);
	    break;
	    
	  case POV_DIR_LEFT:		
	  case POV_DIR_RIGHT:
	    outlet_float (x->x_POV_out[1], (float)0);
	    break;
	    
	    // do nothing if it was centered last time		
	  }
	
	// set the 'former' POV variable, and transmit the new POV data
	if (*(x->x_POV_ptr[0]) == JOY_POVFORWARD) {
	  //post ("forward");

	  x->x_former_POV_val = POV_DIR_UP;
	  outlet_float (x->x_POV_out[0], (float)1);
	  
	} else if (*(x->x_POV_ptr[0]) == JOY_POVBACKWARD) {
	  //post ("backward: %i, JOY_BACKWARD = %d", *(x->x_POV_ptr[0]), JOY_POVBACKWARD);

	  x->x_former_POV_val = POV_DIR_DOWN;
	  outlet_float (x->x_POV_out[0], (float)-1);
	  
	} else if (*(x->x_POV_ptr[0]) == JOY_POVLEFT) {
	  //post ("left");

	  x->x_former_POV_val = POV_DIR_LEFT;
	  outlet_float (x->x_POV_out[1], (float)1);
	  
	} else if (*(x->x_POV_ptr[0]) == JOY_POVRIGHT) {
	  //post ("right");

	  x->x_former_POV_val = POV_DIR_RIGHT;
	  outlet_float (x->x_POV_out[1], (float)-1);

	} else if (*(x->x_POV_ptr[0]) == JOY_POVCENTERED) {
	  x->x_former_POV_val = POV_DIR_CENTER;
	}
      }
    
    for (i = 0; i < x->x_joy_buttons; i ++)
    {
	  if (x->x_joyInfoEx.dwButtons & (1 << i))
        {
            if (x->x_button_val[i] == 0)
            {
                outlet_float (x->x_button_num_out, (float)(i + 1));
                outlet_float (x->x_button_val_out, 1);
                x->x_button_val[i] = 1;
            }
        }
        else
            if (x->x_button_val[i] == 1)
            {
                outlet_float (x->x_button_num_out, (float)(i + 1));
                outlet_float (x->x_button_val_out, 0);
                x->x_button_val[i] = 0;
            }
    }
    clock_delay (x->x_clock, x->x_deltime);
}

void joystick_change_deltime(t_joystick *x, t_float deltime)
{
    if (deltime < 0)
        deltime = 0;
    x->x_deltime = deltime;
}

void joystick_free(t_joystick *x)
{
    clock_free (x->x_clock);
}
