	
try:
    import pyext
    from time import sleep
except:
    print "ERROR: This script must be loaded by the PD/Max pyext external"

try :
    import scripts
except :
    print '--> scripts.py missing !!'



class BBCWeather( pyext._class ) :
    _inlets = 2
    _outlets = 7
    """ 
    {'Temperature': '17', 'Wind Direction': 'E', 'Relative Humidity': '87', 'Pressure': '1013', 'Rising': None, 'Visibility': 'Moderate', 'Wind Speed': '6'}
    """

    def __init__(self) : self._detach( True )
        
    def _anything_1( self, city ) :
        """ tries to get BBC weather info for the given location
        """
        try :
            d = scripts.BBCWeather( city )
            self.output( d ) 
        except :
            print 'could not get BBC weather'
            return

    def bang_2( self ) :
        """ tries to find out where computer is located and then it tries to get BBC weather info for that location
        """
        try :
            d = scripts.autoBBCWeather()
            self.output( d ) 
        except :
            print 'could not get BBC weather'
            return

    def output( self, d ) :
        if type( d ) != type( {} ) : # if it is not a list. probably there are nicer ways to check for this
            if 'No locations were found for' in d :
                print d
                self._outlet( 1, d ) # nothing found
        else :
            keys =  'Temperature', 'Wind Direction', 'Relative Humidity', 'Pressure', 'Rising', 'Visibility', 'Wind Speed'
            for i, k in enumerate( keys ) :
                self._outlet( i+1, d[k] ) # each key to each outlet
    
        
class yahooWeather( pyext._class ) :
    _inlets = 1
    _outlets = 5
    """  {
        'condition' : cond,
        'temp' : temp,
        'wind' : { 'chill' : chill, 'temp' : temp, 'speed' : speed },
        'atmosphere' : { 'humidity' : humidity, 'visibility' : visibility, 'pressure' : pressure, 'rising' : rising },
        'astronomy': { 'sunrise' : sunrise, 'sunset' : sunset }
        }
    """

    def __init__(self) : self._detach(True)
        
    def _anything_1( self, st ) :
        try :
            d = scripts.yahooWeather( st )
        except :
            print 'could not get yahoo weather'
            self._outlet( 1, 0 )
            return

        if d == [] :
            self._outlet( 1, 'no data!' ) # nothing found
        else :
            keys =  'condition', 'temperature', 'wind', 'atmosphere', 'astronomy'
            for i, k in enumerate( keys ) :
                try :
                    v = d[k].values()
                except :
                    v = d[k]
                self._outlet( i+1, v ) # each key to each outlet
                


class getIP( pyext._class ) :
    _inlets = 2
    _outlets = 2

    def __init__(self) : self._detach(True)
        
    def bang_1( self ) :
        try :
            ip = scripts.externalIP()
            self._outlet( 1, ip )
        except :
            print 'could not get external IP'
            self._outlet( 1, 0 )
            return

    def bang_2( self ) :
        try :
            ip = scripts.localIP()
            self._outlet( 2, ip )
        except :
            print 'could not get local IP'
            self._outlet( 2, 0 )
            return




class geoInfo( pyext._class ) :
    _inlets = 1
    _outlets = 6

    def __init__(self) : self._detach(True)
        
    def bang_1( self ) :
        try :
            d = scripts.geoInfo()
        except :
            print 'could not get local IP'
            self._outlet( 1, 0 )
            return
        
        self._outlet( 1, d['code'] )
        self._outlet( 2, d['country'] )
        self._outlet( 3, d['city'] )
        self._outlet( 4, d['region'] )
        self._outlet( 5, d['latitude'] )
        self._outlet( 6, d['longitude'] )




class googleImgs( pyext._class ) :
    _inlets = 2
    _outlets = 1
    maxnum = 10

    def __init__(self) : self._detach(True)

    def int_2( self, i ) : self.maxnum = i
        
    def _anything_1( self, st ) :
        try :
            st = str( st ) #  try to convert
            files = scripts.googleImgs( st, self.maxnum )
        except :
            print "cannot search for", st
            self._outlet( 1, 0 )
            return

        if files == [] :
            self._outlet( 1, 'no matches!' ) # nothing found
        else :
            self._outlet( 1, files )

            
            



if __name__ == '__main__' :
    print "ERROR: This script must be loaded by the PD/Max pyext external"


