these gifs are serached for by the following abstractions:

ol_knob
ol_ggate
ol_gswitch


those abstractions will not work when this folder is not present