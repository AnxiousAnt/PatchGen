/**
 * [sendkey] Generates mouse and keyboard events on Linux
 * @author Patrice Colet <pat@mamalala.org>
 * @license GNU Public License    )c( 2007
 */
 
#include <windows.h>
#include <time.h>
#include "m_pd.h"


static t_class *sendkey_class;

typedef struct sendkey {
	t_object	x_obj; 
	t_outlet	*x_out; 
	t_inlet 	*x_inlet2;
	t_symbol	*x_window;
	t_symbol	*x_name;
	int			x_vk;
	int			x_state;
}	t_sendkey;


void sendkey_window(t_sendkey* x, t_symbol* s)
{
	x->x_window = s;
}

void sendkey_name(t_sendkey* x, t_symbol* s)
{
	x->x_name = s;
}

void sendkey_event(t_sendkey *x, t_floatarg vk, t_floatarg st){
	x->x_vk = vk;
	x->x_state = st;
	if(x->x_name)
	{
		char *findme= x->x_name->s_name;
		HWND handle = FindWindow(0,findme);
		SetFocus(handle);
	}
	keybd_event(vk, 0, st, 0); 
}

BOOL CALLBACK EnumWindowsProc(HWND hWnd, t_sendkey *x)
{
	char*realname=0;
	int vis = IsWindowVisible(hWnd); 
	if (vis == 1)
	{
		int taille = GetWindowTextLength(hWnd);
		if (taille)
		{
			char texte[taille+1];
			int siz = GetWindowText(hWnd,texte,taille+1);
			realname = texte;
			post("%s",realname);
			if(x->x_window)
			{
				char *comp = x->x_window->s_name;
				if (strlen(texte)>strlen(comp))
				{
					if (strncmp(texte,comp,strlen(comp))==0)
					{
						x->x_name = gensym(realname);
					}
				}
			}
		}
	}
	return TRUE;
}

void sendkey_enum(t_sendkey *x)
{
	EnumWindows((WNDENUMPROC)EnumWindowsProc,(LPARAM)x);
}

void sendkey_downkey(t_sendkey *x, t_float *s, int argc, t_atom *argv) {
	if (argc >= 1) {
		if (argv[0].a_type == A_FLOAT) {
			t_float str = atom_getfloat(argv);	  
			sendkey_event(x,str,0);
		}
		else {
			post("Error : Bad argument type. Must be a float or a symbol. ");
		}
	} else {
		post("Error : Missing argument");
	}
}

void sendkey_upkey(t_sendkey *x, t_float *s, int argc, t_atom *argv) {
	if (argc >= 1) {
		if (argv[0].a_type == A_FLOAT) {
			t_float str = atom_getfloat(argv);	  
			sendkey_event(x,str,2);
		}
		else {
			post("Error : Bad argument type. Must be a float or a symbol. ");
		}
	} else {
	post("Error : Missing argument");
	}
}
void sendkey_key(t_sendkey *x, t_float *s, int argc, t_atom *argv) {
	if (argc >= 1) {
		if (argv[0].a_type == A_FLOAT) {
			t_float str = atom_getfloat(argv);
			sendkey_event(x,str,0);
			sendkey_event(x,str,2);
		}
		else
		{
			post("Error : Bad argument type. Must be a float");
		}
	}
	else
	{
		post("Error : Missing argument");
	}
}
void sendkey_char(t_sendkey *x, t_symbol *s, int argc, t_atom *argv) {
	if (argc >= 1)
	{
		if (argv[0].a_type == A_SYMBOL) {
			t_symbol *sym = atom_getsymbolarg(0, argc, argv);
			int i=0;
			char *theChars = sym->s_name;
			int len = strlen(theChars);
			for ( i = 0; i < len;i++)
			{
				sendkey_event(x,VkKeyScan(theChars[i]),0); 
				sendkey_event(x,VkKeyScan(theChars[i]),2); 
			}
		}
		else
		{
			post("Error : Bad argument type. Must be a float or a symbol. ");
		}
	}
	else
	{
		post("Error : Missing argument");
	}
}

/* constructor */
void *sendkey_new(t_symbol* s, int argc, t_atom *argv) {
	t_sendkey *x = (t_sendkey *) pd_new(sendkey_class);
	x->x_inlet2=inlet_new(&x->x_obj, &x->x_obj.ob_pd, gensym("symbol"), gensym(""));
  return (void *)x;
}

/* setup */
void sendkey_setup(void) {
	sendkey_class = class_new(gensym("sendkey"),
	(t_newmethod)sendkey_new,
	0, sizeof(t_sendkey), 0, A_GIMME, 0);
	class_addmethod(sendkey_class, (t_method)sendkey_downkey, gensym("downkey"), A_GIMME, 0);
	class_addmethod(sendkey_class, (t_method)sendkey_upkey, gensym("upkey"), A_GIMME, 0);
	class_addmethod(sendkey_class, (t_method)sendkey_key, gensym("key"), A_GIMME, 0);
	class_addmethod(sendkey_class, (t_method)sendkey_char, gensym("char"), A_GIMME, 0);
	class_addmethod(sendkey_class, (t_method)sendkey_window, gensym(""), A_SYMBOL, 0);
	class_addmethod(sendkey_class, (t_method)sendkey_enum, gensym("enum"), A_GIMME, 0);

  post("==============================================");
  post("                Pure winAPI");
  post("Copyleft 2007 Patrice Colet");
  post("[sendkey] simulates Windows keyboard events.");
  post("==============================================");
}
