Canvas 0.3a

Canvas is a simple Open Sound Control message sequencer. 

All messages are sent to localhost on the port of your choice. 

How it works: 

The tree on the left of the screen offers a way to temporarily store different OSC messages (the tree is not saved to the file...sorry).  My workaround for this was the ability to fill the tree from the canvas, so if there is a message on the canvas that you would like to add to the tree click the message with the middle mouse button. 

To draw messages onto the canvas select the desired message from the tree and left click on the canvas. 

To delete messages from the canvas right click on the target message. 

Canvas supports 5 different datatypes: 
f - float 
i - integer 
s - string 
x - the x index of the OSC message (after placement)
y - the y index of the OSC message (in # of 64th notes from the beginning)

OSC messages need to be typed as follows: 

[address] [typetags] [values]

for example, to send the value 'pi' to OSC address /foo type 

/foo ,f 3.14

notice the ',' before the f: this is part of the Open Sound Control protocol. longer messages could look like this: 

/bar ,iifs 34 38534 435.23 effifl

just keep the type tags and values in the same order and it will work. 

The x and y type tags can be placed anywhere in the type tags block

/foo ,ix 34 and /bar ,xi 34 are both valid.  Just remember which part of the message is the X index or Y index.

I've been playing with the program and it turns out you can send any kind of message, there is no error when non-OSC messages are sent, but you don't get the power of the typetags.

If you have any bugs to report or need help feel free to email me at bstine@telus.net

There are MANY more features to be implemented....let alone proper editing facilities...so I don't want any feature requests just yet.

Brendan Asselstine, December 4 2005