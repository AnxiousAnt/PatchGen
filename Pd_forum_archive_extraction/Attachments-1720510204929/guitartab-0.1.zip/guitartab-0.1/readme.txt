This is a guitar tab editor/player for Pure Data.


Open the help patch.
 It is pretty self-explanatory.
 
As it output midi notes, you can open a sound font using fluid~,
 or send it to 
midi out,
 or strip the note off messages,
 etc. Modify the help patch to do so.
 

Alexandre Quessy

http://alexandre.quessy.net

