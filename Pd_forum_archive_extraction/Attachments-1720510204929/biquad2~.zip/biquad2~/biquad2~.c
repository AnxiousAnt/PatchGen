#include "m_pd.h"

/* ---------------- biquad2~ - raw biquad filter in direct form 1 ----------------- */

typedef struct biquadctl2
{
    t_sample c_x1;
    t_sample c_x2;
    t_sample c_y1;
    t_sample c_y2;
    t_sample c_fb1;
    t_sample c_fb2;
    t_sample c_ff1;
    t_sample c_ff2;
    t_sample c_ff3;
} t_biquadctl2;

typedef struct biquad2
{
    t_object x_obj;
    t_float x_f;
    t_biquadctl2 x_cspace;
} t_biquad2;

t_class *biquad2_class;

static void biquad2_list(t_biquad2 *x, t_symbol *s, int argc, t_atom *argv);

static void *biquad2_new(t_symbol *s, int argc, t_atom *argv)
{
    t_biquad2 *x = (t_biquad2 *)pd_new(biquad2_class);
    outlet_new(&x->x_obj, &s_signal);
    x->x_cspace.c_x1 = x->x_cspace.c_x2 = 0;
    biquad2_list(x, s, argc, argv);
    x->x_f = 0;
    return (x);
}

static t_int *biquad2_perform(t_int *w)
{
    t_sample *in = (t_sample *)(w[1]);
    t_sample *out = (t_sample *)(w[2]);
    t_biquadctl2 *c = (t_biquadctl2 *)(w[3]);
    int n = (int)w[4];
    int i;
    t_sample y1 = c->c_y1;
    t_sample y2 = c->c_y2;
    t_sample x1 = c->c_x1;
    t_sample x2 = c->c_x2;
    t_sample fb1 = c->c_fb1;
    t_sample fb2 = c->c_fb2;
    t_sample ff1 = c->c_ff1;
    t_sample ff2 = c->c_ff2;
    t_sample ff3 = c->c_ff3;
    for (i = 0; i < n; i++)
    {
        t_sample x0 = *in++;
        t_sample output = ff1 * x0 + ff2 * x1 + ff3 * x2
                + fb1 * y1 + fb2 * y2;
        if (PD_BIGORSMALL(output))
            output = 0;
        x2 = x1;
        x1 = x0;
        y2 = y1;
        y1 = output;
        *out++ = output;
    }
    c->c_y1 = y1;
    c->c_y2 = y2;
    c->c_x1 = x1;
    c->c_x2 = x2;
    return (w+5);
}

static void biquad2_list(t_biquad2 *x, t_symbol *s, int argc, t_atom *argv)
{
    t_float fb1 = atom_getfloatarg(0, argc, argv);
    t_float fb2 = atom_getfloatarg(1, argc, argv);
    t_float ff1 = atom_getfloatarg(2, argc, argv);
    t_float ff2 = atom_getfloatarg(3, argc, argv);
    t_float ff3 = atom_getfloatarg(4, argc, argv);
    t_float discriminant = fb1 * fb1 + 4 * fb2;
    t_biquadctl2 *c = &x->x_cspace;
    if (discriminant < 0) /* imaginary roots -- resonant filter */
    {
            /* they're conjugates so we just check that the product
            is less than one */
        if (fb2 >= -1.0f) goto stable;
    }
    else    /* real roots */
    {
            /* check that the parabola 1 - fb1 x - fb2 x^2 has a
                vertex between -1 and 1, and that it's nonnegative
                at both ends, which implies both roots are in [1-,1]. */
        if (fb1 <= 2.0f && fb1 >= -2.0f &&
            1.0f - fb1 -fb2 >= 0 && 1.0f + fb1 - fb2 >= 0)
                goto stable;
    }
        /* if unstable, just bash to zero */
    fb1 = fb2 = ff1 = ff2 = ff3 = 0;
stable:
    c->c_fb1 = fb1;
    c->c_fb2 = fb2;
    c->c_ff1 = ff1;
    c->c_ff2 = ff2;
    c->c_ff3 = ff3;
}

static void biquad2_set(t_biquad2 *x, t_symbol *s, int argc, t_atom *argv)
{
    t_biquadctl2 *c = &x->x_cspace;
    c->c_y1 = atom_getfloatarg(0, argc, argv);
    c->c_y2 = atom_getfloatarg(1, argc, argv);
    c->c_x1 = atom_getfloatarg(2, argc, argv);
    c->c_x2 = atom_getfloatarg(3, argc, argv);
}

static void biquad2_dsp(t_biquad2 *x, t_signal **sp)
{
    dsp_add(biquad2_perform, 4,
        sp[0]->s_vec, sp[1]->s_vec,
            &x->x_cspace, (t_int)sp[0]->s_n);
}

void biquad2_tilde_setup(void)
{
    biquad2_class = class_new(gensym("biquad2~"), (t_newmethod)biquad2_new,
        0, sizeof(t_biquad2), 0, A_GIMME, 0);
    CLASS_MAINSIGNALIN(biquad2_class, t_biquad2, x_f);
    class_addmethod(biquad2_class, (t_method)biquad2_dsp,
        gensym("dsp"), A_CANT, 0);
    class_addlist(biquad2_class, biquad2_list);
    class_addmethod(biquad2_class, (t_method)biquad2_set, gensym("set"),
        A_GIMME, 0);
    class_addmethod(biquad2_class, (t_method)biquad2_set, gensym("clear"),
        A_GIMME, 0);
}