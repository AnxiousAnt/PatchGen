
<?php
/*************************************************************************** 
 * File: php2pd.class.php 
 * Auth: Alexandre Quessy [alex@sourcelibre.com] 
 * Maintainer: Alexandre Quessy [alex@sourcelibre.com] 
 * Version: 0.1
 * Date: December 2004
 * 
 * Description: simple PHP class to send atoms to Pure Datam just like with pdsend. 
 * 
 * Copyleft (C) 2004 by Alexandre Quessy [alex@sourcelibre.com] 
 * 
 * This program is free software; you can redistribute it and/or modify 
 * it under the terms of the GNU General Public License as published by 
 * the Free Software Foundation; either version 2, or (at your option) 
 * any later version. 
 * 
 * This program is distributed in the hope that it will be useful, 
 * but WITHOUT ANY WARRANTY; without even the implied warranty of 
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
 * GNU General Public License, which should be included with this 
 * program, for more details. 
 */
 
define('PD_DEFAULT_WAIT_MSEC', 1000);
define('PD_DEFAULT_PORT', 3002);
define('PD_DEFAULT_HOST', '127.0.0.1');


class php2pd {
	var $host; 
	var $port; 
	var $errno; 
	var $errstr; 
	var $timeout;  
	var $answer;
	var $connection; 
	var $wait_msec;
	
	function php2pd($port = PD_DEFAULT_PORT, $host = PD_DEFAULT_HOST, $timeout = 30) {
		$this->host = $host; 
		$this->port = $port; 
		$this->timeout = $timeout; 
		$this->connection = fsockopen($this->host, $this->port, &$this->errno, &$this->errstr, $this->timeout);
		$this->pdconnect(); 
		return TRUE;  
	}
	
	function pdconnect() {
		if (!$this->connection) {
			$this->answer = "Error #<strong>{$this->errno}</strong> : {$this->errstr}.<br />\n";
		}
		return $this->connection;
	}
	
	function pdsend($message, $add_semicolon = TRUE) {
		if ($this->connection && isset($message)) {
			if ($add_semicolon) {
				$message = $message . ";";
			} 
			if (fwrite($this->connection, $message)) {
				return TRUE;
			} 
		}
		return FALSE; 
	}
	
	function time_limit($sec) {
		set_time_limit($sec);
		return TRUE; 
	}
	function set_host($host) {
		$this->host = $host; 
		return TRUE; 
	}
	
	function set_port($port) {
		$this->port = $port; 
		return TRUE; 
	}
	
	function set_timeout($timeout) {
		$this->timeout = $timeout; 
		return TRUE; 
	}
	
	function wait($msec = NULL) {
		if (!is_null($msec)) {
			$this->wait_msec = $msec;
		} elseif (!isset($this->wait_msec)) {
			$this->wait_msec = PD_DEFAULT_WAIT_MSEC;
		}
		usleep($this->wait_msec * 1000);
		return TRUE; 
	}
}
 /**
 * REMOVE THE PART BELOW FOR PRODUCTION WEB SITE
 */
?>
<body bgcolor="pink">
<h1>Synopsis</h1>
<p>See source for the example. </p>
<?php

if (isset($_GET['message'])) {
	$pd =& new php2pd("3002", "127.0.0.1");
	if (!$pd->connection) {
		echo $pd->answer;
	}
	$pd->time_limit(60);
	$pd->pdsend(trim($_GET['message']));
	$pd->wait(3000);
	$pd->pdsend("cat 123");
	$pd->wait();
	$pd->pdsend("dog 999");
	$pd->wait();
	$pd->pdsend("oyster 4");
	$pd->wait();
	$pd->pdsend("fox 6");
	$pd->wait();
	$pd->pdsend("trout 1");
	$pd->wait();
	$pd->pdsend("beluga 1010");
	
}
?>
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="get">
	<input type="text" name="message" value="<?php if ($_GET['message']) echo htmlentities($_GET['message']); ?>" onChange="this.form.submit();" />
</form>
</body>