This plugin builds a object-by-category menu on the popup menu so you can create objects by browsing via category.

This project was started at Eyebeam as part of an X-lab Residency and grew out of the NYC Patching Circle.

Hans-Christoph Steiner
Joshua Clayton
Sofy Yuditskaya
