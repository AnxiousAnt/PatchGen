#include "m_pd.h"

static t_class *contador1_class;
static t_class *contador2_class;

typedef struct _contador1{
  t_object  x_obj;
  t_int i_contador1;
} t_contador1;

typedef struct _contador2{
  t_object  x_obj;
  t_int i_contador2;
} t_contador2;

/**************************************************************/

void contador1_bang(t_contador1 *x)
{
  t_float f=x->i_contador1;
  x->i_contador1++;
  outlet_float(x->x_obj.ob_outlet,f);
}

void *contador1_new(t_floatarg f)
{
 
  t_contador1 *x = (t_contador1 *)pd_new(contador1_class);
  x->i_contador1=f;
  outlet_new(&x->x_obj, &s_float);
  post("CONTADOR1");

  return (void *)x;
}

void contador1_setup(void) {
  contador1_class = class_new(gensym("contador1"),
			    (t_newmethod)contador1_new,
			    0, sizeof(t_contador1),
			     CLASS_DEFAULT,A_DEFFLOAT,0);
  class_addbang(contador1_class, contador1_bang);
}
/**************************************************************/

void contador2_bang(t_contador2 *x)
{
  t_float f=x->i_contador2;
  x->i_contador2++;
  outlet_float(x->x_obj.ob_outlet,f);
}

void *contador2_new(t_floatarg f)
{
  t_contador2 *x = (t_contador2 *)pd_new(contador2_class);
  x->i_contador2=f;
  outlet_new(&x->x_obj, &s_float);
  post("CONTADOR2");

  return (void *)x;
}

void contador2_setup(void) {
  contador2_class = class_new(gensym("contador2"),
			    (t_newmethod)contador2_new,
			    0, sizeof(t_contador2),
			     CLASS_DEFAULT,A_DEFFLOAT,0);
  class_addbang(contador2_class, contador2_bang);
}

