
This is the beginnings of a library of objects for easy manipulations of files
