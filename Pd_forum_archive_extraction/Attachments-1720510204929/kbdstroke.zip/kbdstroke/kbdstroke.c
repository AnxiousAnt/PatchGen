/**
 * [keystroke] Generates mouse and keyboard events on Linux
 * @author Patrice Colet <pat@mamalala.org>
 * @license GNU Public License    )c( 2007
 */
 
#include <windows.h>
#include "m_pd.h"

/** The class */
t_class *kbdstroke_class;
 
typedef struct kbdstroke {
  t_object x_obj; /* The instance. Contains inlets and outlets */
} t_kbdstroke;


void kbdstroke_downkey(t_kbdstroke *x, t_float *s, int argc, t_atom *argv) {
  if (argc >= 1) {
    if (argv[0].a_type == A_FLOAT) {
      t_float str = atom_getfloat(argv);	  
//only use the first argument  <---fix this	  
      keybd_event(str, 0, 0, 0); 
    }
  	else {
      post("Error : Bad argument type. Must be a float or a symbol. ");
    }
  } else {
    post("Error : Missing argument");
  }
}

void kbdstroke_upkey(t_kbdstroke *x, t_float *s, int argc, t_atom *argv) {
  if (argc >= 1) {
    if (argv[0].a_type == A_FLOAT) {
      t_float str = atom_getfloat(argv);	  
//only use the first argument  <---fix this	  
      keybd_event(str, 0, 2, 0); 
    }
  	else {
      post("Error : Bad argument type. Must be a float or a symbol. ");
    }
  } else {
    post("Error : Missing argument");
  }
}
void kbdstroke_key(t_kbdstroke *x, t_float *s, int argc, t_atom *argv) {
  if (argc >= 1) {
    if (argv[0].a_type == A_FLOAT) {
      t_float str = atom_getfloat(argv);	  
//only use the first argument  <---fix this	  
      keybd_event(str, 0, 0, 0); 
      keybd_event(str, 0, 2, 0);

    }
  	else {
      post("Error : Bad argument type. Must be a float or a symbol. ");
    }
  } else {
    post("Error : Missing argument");
  }
}

/* constructor */
void *kbdstroke_new(t_symbol *selector, int argc, t_atom *argv) {
  t_kbdstroke *x = (t_kbdstroke *) pd_new(kbdstroke_class);
  return (void *)x;
}

/* setup */
void kbdstroke_setup(void) {
  kbdstroke_class = class_new(gensym("kbdstroke"),
    (t_newmethod)kbdstroke_new,
	0, sizeof(t_kbdstroke), 0, A_GIMME, 0);
  class_addmethod(kbdstroke_class, (t_method)kbdstroke_downkey, gensym("downkey"), A_GIMME, 0);
  class_addmethod(kbdstroke_class, (t_method)kbdstroke_upkey, gensym("upkey"), A_GIMME, 0);
  class_addmethod(kbdstroke_class, (t_method)kbdstroke_key, gensym("key"), A_GIMME, 0);
  
  post("==============================================");
  post("                Pure winAPI");
  post("Copyleft 2007 Patrice Colet");
  post("GNU Public License");
  post("[kbdstroke] simulates Windows keyboard events.");
  post("==============================================");
  
}
