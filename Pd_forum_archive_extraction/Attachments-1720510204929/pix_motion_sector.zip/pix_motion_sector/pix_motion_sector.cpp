/*

Detects motion in a specified sector the a video raster.

Adapted from pix_movement.

William Brent 2008
*/

////////////////////////////////////////////////////////
//
// GEM - Graphics Environment for Multimedia
//
// zmoelnig@iem.kug.ac.at
//
// Implementation file
//
//    Copyright (c) 1997-1998 Mark Danks.
//    Copyright (c) G�nther Geiger.
//    Copyright (c) 2001-2002 IOhannes m zmoelnig. forum::f�r::uml�ute. IEM
//    For information on usage and redistribution, and for a DISCLAIMER OF ALL
//    WARRANTIES, see the file, "GEM.LICENSE.TERMS" in this distribution.
//
/////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////
//
// pix_motion_sector
//
//
/////////////////////////////////////////////////////////

#include "pix_motion_sector.h"
#include <string.h>
#include <math.h>
#include <time.h>
#ifdef __APPLE__
# include <Carbon/Carbon.h>
#endif

CPPEXTERN_NEW(pix_motion_sector)

/////////////////////////////////////////////////////////
//
// pix_motion_sector
//
/////////////////////////////////////////////////////////
// Constructor
//
/////////////////////////////////////////////////////////
pix_motion_sector :: pix_motion_sector()
{
	inlet_new(this->x_obj, &this->x_obj->ob_pd, gensym("float"), gensym("thresh_f"));
    inlet_new(this->x_obj, &this->x_obj->ob_pd, gensym("list"), gensym("coord"));
	
	buffer.xsize  = buffer.ysize = 64;
	buffer.format = GL_LUMINANCE;
	buffer.csize  = 1;
	buffer.reallocate();
	buffer2.xsize  = buffer2.ysize = 64;
	buffer2.format = GL_LUMINANCE;
	buffer2.csize  = 1;
	buffer2.reallocate();

    outlet1 = outlet_new(this->x_obj, gensym("float"));

	thresh_f = 0.5;

	x_origin = 0;
	y_origin = 0;
	x_depth = 0;
	y_depth = 0;
}

/////////////////////////////////////////////////////////
// Destructor
//
/////////////////////////////////////////////////////////
pix_motion_sector :: ~pix_motion_sector()
{
  // clean my buffer
}

/////////////////////////////////////////////////////////
// processImage
//
/////////////////////////////////////////////////////////
void pix_motion_sector :: processRGBAImage(imageStruct &image)
{
	// assume that the pix_size does not change !
	bool doclear=(image.xsize*image.ysize != buffer.xsize*buffer.ysize);
	int x, y;
	int total_hits = 0;
	
	buffer.xsize = image.xsize;
	buffer.ysize = image.ysize;
	buffer.reallocate();
	if(doclear) buffer.setWhite();

// 320 x 240	
	unsigned char *rp = image.data;			// read pointer
	unsigned char *wp = buffer.data;			// write pointer

	threshold = (unsigned char)(255*thresh_f);
	
	rp += ((y_origin * image.xsize) + x_origin) * 4;  // adds a full row of Xs for every Y, *4 to accomodate RGBA data
	wp += (y_origin * image.xsize) + x_origin;  // adds a full row of Xs for every Y

																						// move forward a full row of Xs, but
																						// exactly x_depth less, because that's
																						// the amount we've already traversed.
	for(y = y_origin; y < y_origin + y_depth; y++, rp += ((image.xsize - x_depth)*4), wp += (image.xsize - x_depth))
	{
		
		for(x = x_origin; x < x_origin + x_depth; x++)
		{	
			unsigned char grey = (rp[chRed]*79+rp[chGreen]*156+rp[chBlue]*21)>>8;  // measures brightness
			
			if( rp[chAlpha] = 255*(abs(grey-*wp)>threshold) )
			{
				//outlet_bang(outlet1);
				total_hits += 1;
			};
			
			*wp++ = (unsigned char)grey;
			rp += 4;

		}
	};

	
	outlet_float(outlet1, (total_hits/((float)x_depth*(float)y_depth)) );
	
	
	
};

void pix_motion_sector :: processYUVImage(imageStruct &image)
{ error("YUV doesn't work"); };

#ifdef __VEC__
void pix_motion_sector :: processYUVAltivec(imageStruct &image)
{ error("YUV Altivec doesn't work"); };
#endif /* __VEC__ */

void pix_motion_sector :: processGrayImage(imageStruct &image)
{ error("Gray Image doesn't work"); };

#ifdef __MMX__
void pix_motion_sector :: processGrayMMX(imageStruct &image)
{ error("MMX doesn't work"); };
#endif

/////////////////////////////////////////////////////////
// thresh_fMess
//
/////////////////////////////////////////////////////////
void pix_motion_sector :: thresh_fMess(int argc, t_atom *argv)
{
	thresh_f = atom_getfloat(&argv[0]);
	
	setPixModified();
}

/////////////////////////////////////////////////////////
// coordMess
//
/////////////////////////////////////////////////////////
void pix_motion_sector :: coordMess(int argc, t_atom *argv)
{
	x_origin = (int)atom_getfloat(&argv[0]);
	y_origin = (int)atom_getfloat(&argv[1]);
	x_depth = (int)atom_getfloat(&argv[2]);
	y_depth = (int)atom_getfloat(&argv[3]);
	
	setPixModified();
}


/////////////////////////////////////////////////////////
// static member function
//
/////////////////////////////////////////////////////////
void pix_motion_sector :: obj_setupCallback(t_class *classPtr)
{
	class_addmethod(classPtr, (t_method)&pix_motion_sector::thresh_fMessCallback,
		gensym("thresh_f"), A_GIMME, A_NULL);

    class_addmethod(classPtr, (t_method)&pix_motion_sector::coordMessCallback,
		gensym("coord"), A_GIMME, A_NULL);
		
    class_sethelpsymbol(classPtr, gensym("help-pix_motion_sector"));
		
}

void pix_motion_sector :: thresh_fMessCallback(void *data, t_symbol *, int argc, t_atom *argv)
{
    GetMyClass(data)->thresh_fMess(argc, argv);
}

void pix_motion_sector :: coordMessCallback(void *data, t_symbol *, int argc, t_atom *argv)
{
    GetMyClass(data)->coordMess(argc, argv);
}
