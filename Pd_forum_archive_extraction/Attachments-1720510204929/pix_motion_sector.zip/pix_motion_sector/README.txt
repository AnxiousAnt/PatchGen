pix_motion_sector
************************

To compile, place the files pix_motion_sector.cpp & pix_motion_sector.h in Gem/src/Pixes, cd back to the Gem directory and run "make".  This will initiate the entire GEM make process again, but it should be fast.

Place help-pix_motion_sector.pd in the Pd/Contents/Resources/doc/5.reference directory.  As of Pd-0.41-4, this seems to work.