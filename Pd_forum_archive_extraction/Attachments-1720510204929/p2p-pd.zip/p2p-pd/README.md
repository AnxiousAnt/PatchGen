Connect Pd instances together via Bittorrent (requires nodejs).

 1. `npm install chr15m/dreamtime`
 2. `pd p2p.pd`
 3. `pdreceive 5454 | ./node_modules/.bin/dreamtime "$1" | stdbuf -oL sed -e 's/$/\;\n/' | pdsend 5455`

