#!/bin/sh

pdreceive 5454 | dreamtime "$1" | stdbuf -oL sed -e 's/$/\;\n/' | pdsend 5455
