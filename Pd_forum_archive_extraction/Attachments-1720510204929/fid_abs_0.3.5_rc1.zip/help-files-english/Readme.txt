For English help translation :
Move all folders and files of this folder into parent folder.
This way you can replace french help files by english-translated ones.