These foldres contain a translation of french doc files.

For examples and tutorial, look in french documentation (doc/FR folder)