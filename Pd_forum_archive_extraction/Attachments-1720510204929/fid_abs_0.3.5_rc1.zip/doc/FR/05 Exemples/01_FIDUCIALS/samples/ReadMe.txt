Put in this folder 8 wav files named
wav.1.wav
wav.2.wav
wav.3.wav
wav.4.wav
wav.5.wav
wav.6.wav
wav.7.wav
wav.8.wav