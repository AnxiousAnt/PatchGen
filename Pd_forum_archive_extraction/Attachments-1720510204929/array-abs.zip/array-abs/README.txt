# array-abs
Array Abstraction Library for Pure Data (version >= 0.45)

This collection of abstractions uses the new [array] objects in Pd version 0.45 and higher to create flexible, familiar, and reliable tools for manipulating arrays, in the vein of the list-abs library. A list of all current abstractions may be found in the file 000-array-abstraction-library.pd in the main directory.

Maintained by <Matt Barber> brbrofsvl at gmail dot com
