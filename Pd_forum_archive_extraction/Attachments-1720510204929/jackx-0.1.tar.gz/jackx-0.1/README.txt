
Another small external lib.
This one has two objects:
jack-connect :connect/disconnect/toggle/query connections from named ports
jack-ports: find the ports in the jack-graph. You can send it regular-expressions plus a few keywords to get client and port names.

There are two basic help patches included.



To compile:
make sure that m_pd.h is in your include path
type make.
Manually install everything :)

have fun

TODO
finally learn autotools
When and if the jack-developers finalize their transport structures add a jack-transport object.



Gerard van Dongen
gml@xs4all.nl
