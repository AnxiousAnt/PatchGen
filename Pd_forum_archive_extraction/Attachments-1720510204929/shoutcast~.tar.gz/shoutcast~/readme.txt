Version 0.01 
copyright (c) 2001 by Olaf Matthes

shoutcast~.dll is a MPEG I Layer III (mp3) streaming external for pd (by Miller 
Puckette) thats connects to a SHOUTcast server.

To run shoutcast~ place it in the directory of the patch or start pd with 
'-lib shoutcast~.dll' flag. 
In order to get mp3-encoding working lame_enc.dll needs to be in a directory that 
is part of your systems search path (e.g. c:\windows\system). You can get this 
DLL at http://www.mp3dev.org.

This software is published under GPL terms.

This is software with ABSOLUTELY NO WARRANTY.
Use it at your OWN RISK. It's possible to damage e.g. hardware or your hearing
due to a bug or for other reasons. 
We do not warrant that the program is free of infringement of any third-party
patents.

*****************************************************************************

shoutcast~ has been compiled for Win using LAME 3.89.
The newest version of LAME can be found at sourceforge.net

COPYING: you may use this source under GPL terms!

PLEASE NOTE: This software may contain patented alogrithm (at least
  patented in some countries). It may be not allowed to sell/use products
  based on this source code in these countries. Check this out first!

COPYRIGHT of MP3 music:
  Please note, that the duplicating of copyrighted music without explicit
  permission violates the rights of the owner.

*****************************************************************************

	using and setting up shoutcast~ external for Pure Data


  To run the shoutcast~ extern the lame_enc.dll needs to be placed in the windows 
directory (typicly c:\windows). The LAME version used to test shoutcast~ is 
currecntly 3.89.
You can get the latest version of lame_enc.dll from http://www.mp3dev.org.

  Sampling Rate (Hz): 
Possible values are 48000, 44100 and 32000. If Pd runs at a different sampling 
rate, LAME will resample the signal. Default value for mp3 sampling rate is Pd's 
sampling rate.

  Bitrate (kbit/s): 
Possible values are 32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256 
and 320. Default is 224.

  Mode: 
Possible values are 0 (stereo), 1 (joint stereo, the default), 2 (dual channel) 
and 3 (mono).

  Password:
The default is 'pd', can be changed with a message "passwd yourpassword".

  Server:
Use message "connect name_of_your_server.com port" to connect (same as with 
Pd's netsend). 'port' is the number specified in the server's config file. 
Attention: The actual port number used is one higher! Standard would be 8000 
resulting in a socket at port 8001!!! Bare this in mind when configuring proxys 
or using shoutcast~ in connection with netsend / netreceive.

  Outlet:
The outlet outputs an int, 1 if connected to SHOUTcast server, 0 if not. This could 
be used to build an automatic reconnect mechanism.

  Other things:
shoutcast~ prints the current status (connection, login, LAME status) to the pd 
window. To see the current settings, send it a message "print" and mp3 settings 
will be displayed.
Note that changing any mp3 settings will require to disconnect and reconnect again!
This has to be done manually. 

  Known problems:
If you turn off audio processing when you are connected with the server, no data will 
be sent to it. This will make the server disconnect after a certain time ('no data' 
error in server log). shoutcast~ does not recongnise this and attempts to keep on
streaming. To avoid this set 'AutoDumpSourceTime' in the servers config file to a 
fairly high value preventing the server from closing the socket to fast.

