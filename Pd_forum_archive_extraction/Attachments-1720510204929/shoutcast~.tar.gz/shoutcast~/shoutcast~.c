/* ------------------------ shoutcast~ ---------------------------------------- */
/*                                                                               */
/* Tilde object to send mp3-stream to shoutcast/icecast server.                  */
/* Written by Olaf Matthes (olaf.matthes@gmx.de).                               */
/* Get source at http://www.akustische-kunst.de/puredata/                       */
/*                                                                               */
/* This program is free software; you can redistribute it and/or                */
/* modify it under the terms of the GNU General Public License                    */
/* as published by the Free Software Foundation; either version 2                */
/* of the License, or (at your option) any later version.                        */
/*                                                                                */
/* See file LICENSE for further informations on licensing terms.                */
/*                                                                              */
/* This program is distributed in the hope that it will be useful,                */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of                */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                */
/* GNU General Public License for more details.                                 */
/*                                                                              */
/* You should have received a copy of the GNU General Public License             */
/* along with this program; if not, write to the Free Software                    */
/* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.    */
/*                                                                              */
/* Based on PureData by Miller Puckette and others.                             */
/* Uses the LAME MPEG 1 Layer 3 encoding library (lame_enc.dll) which can       */
/* be found at http://www.cdex.n3.net.                                          */
/*                                                                               */
/* ---------------------------------------------------------------------------- */



#ifdef NT
#pragma warning( disable : 4244 )
#pragma warning( disable : 4305 )
#endif

#include <sys/types.h>
#include <string.h>
#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <malloc.h>
#include <ctype.h>
#ifdef UNIX
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <time.h>
#include <sys/time.h>
#include <lame/lame.h>        /* lame encoder stuff */
#define SOCKET_ERROR -1
#else
#include <io.h>
#include <windows.h>
#include <winsock.h>
#include <windef.h>
#include "lame_enc.h"        /* lame encoder stuff */
#endif

#include "m_pd.h"            /* standard pd stuff */

#define        MY_MP3_MALLOC_IN_SIZE        65536
                                            /* max size taken from lame readme */
#define        MY_MP3_MALLOC_OUT_SIZE       1.25*MY_MP3_MALLOC_IN_SIZE+7200 

#define        MAXDATARATE 320        /* maximum mp3 data rate is 320kbit/s */
#define        STRBUF_SIZE 32

static char   *shoutcast_version = "shoutcast~ mp3 streamer version 0.01, written by Olaf Matthes";
static int    sockfd;

#ifndef UNIX
static        HINSTANCE           dll                = NULL;
static        BEINITSTREAM        initStream        = NULL;
static        BEENCODECHUNK       encodeChunk        = NULL;
static        BEDEINITSTREAM      deinitStream    = NULL;
static        BECLOSESTREAM       closeStream        = NULL;
static        BEVERSION           dllVersion        = NULL;
static        BEWRITEVBRHEADER    writeVBRHeader    = NULL;
#else
lame_global_flags *lgfp;
#endif


static t_class *shoutcast_class;

typedef struct _shoutcast
{
    t_object x_obj;

        /* LAME stuff */
    int x_lame;                /* info about encoder status */
    int x_lamechunk;           /* chunk size for LAME encoder */
    int x_mp3size;             /* number of returned mp3 samples */

        /* buffer stuff */
    unsigned short x_inp;     /* in position for buffer */
    unsigned short x_outp;    /* out position for buffer*/
    short *x_mp3inbuf;        /* data to be sent to LAME */
    char *x_mp3outbuf;        /* data returned by LAME -> our mp3 stream */
    short *x_buffer;          /* data to be buffered */
    int x_bytesbuffered;      /* number of unprocessed bytes in buffer */
    int x_start;

        /* mp3 format stuff */
    int x_samplerate;
    int x_bitrate;            /* bitrate of mp3 stream */
    int x_mp3mode;            /* mode (mono, joint stereo, stereo, dual mono) */
    int x_mp3quality;         /* quality of encoding */

        /* SHOUTcast server stuff */
    int x_fd;                 /* info about connection status */
    char* x_passwd;           /* password for server */

    t_float x_f;              /* float needed for signal input */
} t_shoutcast;


    /* encode PCM data to mp3 stream */
static void shoutcast_encode(t_shoutcast *x)
{
    short *bvec = (short*)(x->x_buffer);
    short *mp3vec = (short*)(x->x_mp3inbuf);
    unsigned short i, wp;
    int err = -1;
    int n = x->x_lamechunk;

#ifdef UNIX
    if(x->x_lamechunk < (int)sizeof(x->x_mp3inbuf))
#else
    if(x->x_lamechunk < sizeof(x->x_mp3inbuf))
#endif
    {
        error("not enough memory!");
        return;
    }

        /* on start/reconnect set outpoint that it not interferes with inpoint */ 
    if(x->x_start == -1)
    {
        post("shoutcast~: initialising buffers");
            /* we try to keep 2.5 times the data the encoder needs in the buffer */
        if(x->x_inp > (2 * x->x_lamechunk))
        {
            x->x_outp = (short) x->x_inp - (2.5 * x->x_lamechunk);
        }
        else if(x->x_inp < (2 * x->x_lamechunk))
        {
            x->x_outp = (short) MY_MP3_MALLOC_IN_SIZE - (2.5 * x->x_lamechunk);
        }
        x->x_start = 1;
    }
    if((unsigned short)(x->x_outp - x->x_inp) < x->x_lamechunk)error("shoutcast~: buffers overlap!");

    bvec += x->x_outp;                            /* poit to current reading position */

    i = MY_MP3_MALLOC_IN_SIZE - x->x_outp;

        /* read from buffer */
    if(x->x_lamechunk <= i)    
    {
            /* enough data until end of buffer */
        while(n--)                                /* fill encode buffer */
        {
            *mp3vec++ = (short) *(bvec++);
        }
        x->x_outp += x->x_lamechunk;
    }
    else                                        /* split data */
    {
        // post(" i = %d ", i);
        for(wp = 0; wp < i; wp++)                /* data at end of buffer */
        {
             *mp3vec++ = (short) *(bvec++);
        }

        bvec -= (short) MY_MP3_MALLOC_IN_SIZE;    /* jump to beginning of buffer */
        for(wp = i; wp < x->x_lamechunk; wp++)    /* write rest of data at beginning of buffer */
        {
            // post("wp = %d", wp); 
            *mp3vec++ = (short) *(bvec++);    /* ---------------------------------------------- this crashes pd !!! */
            // *mp3vec++ = (short) 0;        /* ------  using this works -> it's a problem concerning x->x_buffer  */
        }
        x->x_outp = x->x_lamechunk - i;
        // post(" splittet chunk %d", x->x_outp);
    }

        /* encode mp3 data */
#ifndef UNIX
    err = encodeChunk(x->x_lame, x->x_lamechunk, x->x_mp3inbuf, x->x_mp3outbuf, &x->x_mp3size);
#else
    x->x_mp3size = lame_encode_buffer_interleaved(lgfp, x->x_mp3inbuf, x->x_lamechunk, x->x_mp3outbuf, MY_MP3_MALLOC_OUT_SIZE);
    // post( "shoutcast~ : encoding returned %d frames", x->x_mp3size );
#endif

        /* check result */
#ifndef UNIX
    if(err != BE_ERR_SUCCESSFUL)
    {
        closeStream(x->x_lame);
        error("shoutcast~: lameEncodeChunk() failed (%lu)", err);
#else
    if(x->x_mp3size<0)
    {
        lame_close( lgfp );
        error("shoutcast~: lame_encode_buffer_interleaved failed (%d)", err);
#endif
        x->x_lame = -1;
    }
}


    /* stream mp3 to SHOUTcast server */
static void shoutcast_stream(t_shoutcast *x)
{
    int err = -1;            /* error return code */
    err = send(x->x_fd, x->x_mp3outbuf, x->x_mp3size, 0);
    if(err < 0)
    {
        error("shoutcast~: could not send encoded data to server (%d)", err);
#ifndef UNIX
        closeStream(x->x_lame);
#else
        lame_close( lgfp );
#endif
        x->x_lame = -1;
#ifndef UNIX
        closesocket(x->x_fd);
#else
        close(x->x_fd);
#endif
        x->x_fd = -1;
        outlet_float(x->x_obj.ob_outlet, 0);
    } 
    if((err > 0)&&(err != x->x_mp3size))error("shoutcast~: %d bytes skipped", x->x_mp3size - err);
}

    
    /* buffer data as channel interleaved PCM */
static t_int *shoutcast_perform(t_int *w)
{
    t_float *in1   = (t_float *)(w[1]);       /* left audio inlet */
    t_float *in2   = (t_float *)(w[2]);       /* right audio inlet */
    t_shoutcast *x = (t_shoutcast *)(w[3]);
    int n = (int)(w[4]);                      /* number of samples */
    unsigned short i,wp;
    short *ivec = (short *)(x->x_buffer);     /* interleaved stereo PCM goes here */
    float ina, inb;

        /* copy the data into the buffer */
    i = MY_MP3_MALLOC_IN_SIZE - x->x_inp;    /* space left at the end of buffer */
    n *= 2;                                  /* two channels go into one buffer */

    ivec += x->x_inp;                        /* go to current in-point in buffer */
    if ( n <= i ) 
    {
            /* the place between inp and MY_MP3_MALLOC_IN_SIZE is */
            /* big enough to hold the data            */
    
        for(wp = 0; wp < n; wp++)
        {
            ina = *(in1++);
            inb = *(in2++);
            if (ina > 1. ) { ina = 1. ; }
            if (ina < -1. ) { ina = -1. ; }
            if (inb > 1. ) { inb = 1. ; }
            if (inb < -1. ) { inb = -1. ; }
            /* too bad : zeros because of the lack of parenthesis */
            *ivec++ = (short) (ina * 32768);
            *ivec++ = (short) (inb * 32768);
        }
        x->x_inp += n;    /* n more samples written to buffer */
    } 
    else 
    {
        /* the place between inp and MY_MP3_MALLOC_IN_SIZE is not */    
        /* big enough to hold the data                              */
        /* writing will take place in two turns, one from         */
        /* x->x_inp -> MY_MP3_MALLOC_IN_SIZE, then from 0 on      */

        for(wp = 0; wp < i; wp++)            /* fill up to end of buffer */
        {
            ina = *(in1++);
            inb = *(in2++);
            if (ina > 1. ) { ina = 1. ; }
            if (ina < -1. ) { ina = -1. ; }
            if (inb > 1. ) { inb = 1. ; }
            if (inb < -1. ) { inb = -1. ; }
            *ivec++ = (short) ina * 32768;
            *ivec++ = (short) inb * 32768;
        }
        ivec -= (short) MY_MP3_MALLOC_IN_SIZE;    /* jump to beginning of buffer */
        for(wp = i; wp < n; wp++)        /* write rest at start of buffer */
        {
            ina = *(in1++);
            inb = *(in2++);
            if (ina > 1. ) { ina = 1. ; }
            if (ina < -1. ) { ina = -1. ; }
            if (inb > 1. ) { inb = 1. ; }
            if (inb < -1. ) { inb = -1. ; }
            *ivec++ = (short) ina * 32768;
            *ivec++ = (short) inb * 32768;
        }
        x->x_inp = x->x_inp + n;
    }

    if((x->x_fd >= 0)&&(x->x_lame >= 0))
    { 
            /* count buffered samples when things are running */
        x->x_bytesbuffered += n;

            /* encode and send to server */
        if(x->x_bytesbuffered > x->x_lamechunk)
        {
            shoutcast_encode(x);        /* encode to mp3 */
            shoutcast_stream(x);        /* stream mp3 to server */
            x->x_bytesbuffered -= x->x_lamechunk;
        }
    }
    else
    {
        x->x_start = -1;
    }
    return (w+5);
}

static void shoutcast_dsp(t_shoutcast *x, t_signal **sp)
{
    dsp_add(shoutcast_perform, 4, sp[0]->s_vec, sp[1]->s_vec, x, sp[0]->s_n);
}

    /* initialize the lame library */
static void shoutcast_tilde_lame_init(t_shoutcast *x)
{
#ifndef UNIX
        /* encoder related stuff (calculating buffer size) */
    BE_VERSION    lameVersion        = {0,};                                /* version number of LAME */
    BE_CONFIG    lameConfig        = {0,};                                /* config structure of LAME */
    unsigned int    ret;
#else
    int    ret;
    lgfp = lame_init();
#endif

#ifndef UNIX
    /* load lame_enc.dll library */

    dll=LoadLibrary("lame_enc.dll");
    if(dll==NULL)
    {
        error("shoutcast~: error loading lame_enc.dll");
        closesocket(x->x_fd);
        x->x_fd = -1;
        outlet_float(x->x_obj.ob_outlet, 0);
        post("shoutcast~: connection closed");
        return;
    }

        /* get Interface functions */
    initStream        = (BEINITSTREAM) GetProcAddress(dll, TEXT_BEINITSTREAM);
    encodeChunk        = (BEENCODECHUNK) GetProcAddress(dll, TEXT_BEENCODECHUNK);
    deinitStream    = (BEDEINITSTREAM) GetProcAddress(dll, TEXT_BEDEINITSTREAM);
    closeStream        = (BECLOSESTREAM) GetProcAddress(dll, TEXT_BECLOSESTREAM);
    dllVersion        = (BEVERSION) GetProcAddress(dll, TEXT_BEVERSION);
    writeVBRHeader    = (BEWRITEVBRHEADER) GetProcAddress(dll,TEXT_BEWRITEVBRHEADER);

        /* check if all interfaces are present */
    if(!initStream || !encodeChunk || !deinitStream || !closeStream || !dllVersion || !writeVBRHeader)
    {

        error("shoutcast~: unable to get LAME interfaces");
        closesocket(x->x_fd);
        x->x_fd = -1;
        outlet_float(x->x_obj.ob_outlet, 0);
        post("shoutcast~: connection closed");
        return;
    }

        /* get LAME version number */
    dllVersion(&lameVersion);

    post(   "shoutcast~: lame_enc.dll version %u.%02u (%u/%u/%u)\n"
            "            lame_enc engine %u.%02u",    
            lameVersion.byDLLMajorVersion, lameVersion.byDLLMinorVersion,
            lameVersion.byDay, lameVersion.byMonth, lameVersion.wYear,
            lameVersion.byMajorVersion, lameVersion.byMinorVersion);

    memset(&lameConfig,0,sizeof(lameConfig));                        /* clear all fields */
#else
    {
       const char *lameVersion = get_lame_version();
       post( "shoutcast~ : using lame version : %s", lameVersion );
    }
#endif 

#ifndef UNIX

        /* use the LAME config structure */
    lameConfig.dwConfig = BE_CONFIG_LAME;

        /* set the mpeg format flags */
    lameConfig.format.LHV1.dwStructVersion    = 1;
    lameConfig.format.LHV1.dwStructSize        = sizeof(lameConfig);        
    lameConfig.format.LHV1.dwSampleRate        = (int)sys_getsr();        /* input frequency - pd's sample rate */
    lameConfig.format.LHV1.dwReSampleRate    = x->x_samplerate;        /* output s/r - resample if necessary */
    lameConfig.format.LHV1.nMode            = x->x_mp3mode;            /* output mode */
    lameConfig.format.LHV1.dwBitrate        = x->x_bitrate;            /* mp3 bitrate */
    lameConfig.format.LHV1.nPreset            = x->x_mp3quality;        /* mp3 encoding quality */
    lameConfig.format.LHV1.dwMpegVersion    = MPEG1;                /* use MPEG1 */
    lameConfig.format.LHV1.dwPsyModel        = 0;                    /* USE DEFAULT PSYCHOACOUSTIC MODEL */
    lameConfig.format.LHV1.dwEmphasis        = 0;                    /* NO EMPHASIS TURNED ON */
    lameConfig.format.LHV1.bOriginal        = TRUE;                    /* SET ORIGINAL FLAG */
    lameConfig.format.LHV1.bCopyright        = TRUE;                    /* SET COPYRIGHT FLAG */
    lameConfig.format.LHV1.bNoRes            = TRUE;                    /* no bit resorvoir */

        /* init the MP3 stream */
    ret = initStream(&lameConfig, &x->x_lamechunk, &x->x_mp3size, &x->x_lame);

        /* check result */
    if(ret != BE_ERR_SUCCESSFUL)
    {
        post("shoutcast~: error opening encoding stream (%lu)", ret);
        return;
    }

#else
        /* setting lame parameters */
    lame_set_num_channels( lgfp, 2);
    lame_set_in_samplerate( lgfp, sys_getsr() );
    lame_set_brate( lgfp, x->x_bitrate );
    lame_set_mode( lgfp, x->x_mp3mode );
    lame_set_quality( lgfp, x->x_mp3quality );
    ret = lame_init_params( lgfp );
    if ( ret<0 ) {
       post( "shoutcast~ : error : lame initialization returned : %d", ret );
    } else {
       x->x_lame=1;
       post( "shoutcast~ : lame initialization done. (%d)", x->x_lame );
    }
#endif


}

    /* connect to SHOUTcast server */
static void shoutcast_connect(t_shoutcast *x, t_symbol *hostname, t_floatarg fportno)
{
    struct          sockaddr_in server;
    struct          hostent *hp;
#ifdef ICECAST
    int             portno            = fportno;    /* get port from message box */
#else
#ifdef SHOUTCAST
    int             portno            = fportno+1;    /* get port from message box, use one port higher */
#else
#error Should compile for icecast (-DICECAST) or shoutcast (-DSHOUTCAST)
#endif
#endif

        /* information about this broadcast to be send to the server */
    const char     *name            = "PureData";                    /* name of broadcast */
    const char     *url             = "http://localhost";            /* url of broadcast */
    const char     *genre           = "abstract break";              /* genre of broadcast */
    const char     *aim             = "N/A";                         /* aim of broadcast */
    const char     *irc             = "#shoutcast";                  /* ??? what's this ??? */
    const char     *icq             = "";                            /* icq id of broadcaster */
    int            isPublic         = 1;                             /* don't publish broadcast on www.shoutcast.com */

        /* variables used for communication with server */
    const char      * buf = 0;
    char            resp[STRBUF_SIZE];
    unsigned int    len;
    fd_set          fdset;
    struct timeval  tv;

#ifndef UNIX
    unsigned int    ret;
#else
    int    ret;
#endif

    if (x->x_fd >= 0)
    {
        error("shoutcast~: already connected");
        return;
    }

    sockfd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (sockfd < 0)
    {
        error("shoutcast~: internal error while attempting to open socket");
        return;
    }

        /* connect socket using hostname provided in command line */
    server.sin_family = AF_INET;
    hp = gethostbyname(hostname->s_name);
    if (hp == 0)
    {
        post("shoutcast~: bad host?");
#ifndef UNIX
        closesocket(sockfd);
#else
        close(sockfd);
#endif
        return;
    }
    memcpy((char *)&server.sin_addr, (char *)hp->h_addr, hp->h_length);

        /* assign client port number */
    server.sin_port = htons((unsigned short)portno);

        /* try to connect.  */
    post("shoutcast~: connecting to port %d", portno);
    if (connect(sockfd, (struct sockaddr *) &server, sizeof (server)) < 0)
    {
        error("shoutcast~: connection failed!\n");
#ifndef UNIX
        closesocket(sockfd);
#else
        close(sockfd);
#endif
        return;
    }

        /* sheck if we can read/write from/to the socket */
    FD_ZERO( &fdset);
    FD_SET( sockfd, &fdset);
    tv.tv_sec  = 0;            /* seconds */
    tv.tv_usec = 500;        /* microseconds */

    ret = select(sockfd + 1, &fdset, NULL, NULL, &tv);
    if(ret < 0)
    {
        error("shoutcast~: can not read from socket");
#ifndef UNIX
        closesocket(sockfd);
#else
        close(sockfd);
#endif
        return;
    }
    ret = select(sockfd + 1, NULL, &fdset, NULL, &tv);
    if(ret < 0)
    {
        error("shoutcast~: can not write to socket");
#ifndef UNIX
        closesocket(sockfd);
#else
        close(sockfd);
#endif
        return;
    }


        /* now try to log in at SHOUTcast server */
    post("shoutcast~: logging in...");

        /* first line is the passwd */
    buf = x->x_passwd;
    send(sockfd, buf, strlen(buf), 0);
    buf = "\n";
    send(sockfd, buf, strlen(buf), 0);

         /* header for SHOUTcast server */
    buf = "icy-name:";                        /* name of broadcast */
    send(sockfd, buf, strlen(buf), 0);
    buf = name;
    send(sockfd, buf, strlen(buf), 0);
    buf = "\nicy-url:";                        /* URL of broadcast */
    send(sockfd, buf, strlen(buf), 0);
    buf = url;
    send(sockfd, buf, strlen(buf), 0);
    buf = "\nicy-genre:";                    /* genre of broadcast */
    send(sockfd, buf, strlen(buf), 0);
    buf = genre;
    send(sockfd, buf, strlen(buf), 0);
    buf = "\nicy-irc:";
    send(sockfd, buf, strlen(buf), 0);
    buf = irc;
    send(sockfd, buf, strlen(buf), 0);
    buf = "\nicy-aim:";
    send(sockfd, buf, strlen(buf), 0);
    buf = aim;
    send(sockfd, buf, strlen(buf), 0);
    buf = "\nicy-icq:";
    send(sockfd, buf, strlen(buf), 0);
    buf = icq;
    send(sockfd, buf, strlen(buf), 0);
    buf = "\nicy-br:";
    send(sockfd, buf, strlen(buf), 0);
    if(sprintf(resp, "%d", x->x_bitrate) == -1)    /* convert int to a string */
    {
        error("shoutcast~: wrong bitrate");
    }
    send(sockfd, resp, strlen(resp), 0);
    buf = "\nicy-pub:";
    send(sockfd, buf, strlen(buf), 0);
    if(isPublic==0)                            /* set the public flag for broadcast */
    {
        buf = "no";
    }
    else
    {
        buf ="yes";
    }
    send(sockfd, buf, strlen(buf), 0);
    buf = "\n\n";
    send(sockfd, buf, strlen(buf), 0);

        /* read the anticipated response: "OK" */
    len = recv(sockfd, resp, STRBUF_SIZE, 0);
    if ( len < 2 || resp[0] != 'O' || resp[1] != 'K' ) 
    {
        post("shoutcast~: login failed!");
#ifndef UNIX
        closesocket(sockfd);
#else
        close(sockfd);
#endif
        return;
    }
    
        /* suck anything that the other side has to say */
    // while (len = recv(sockfd, resp, STRBUF_SIZE,0)) 
    // {
        ; /* do nothing, just wait ! */
    // }

    x->x_fd = sockfd;
    outlet_float(x->x_obj.ob_outlet, 1);
    post("shoutcast~: logged in to %s", hp->h_name);

    shoutcast_tilde_lame_init(x);

}

    /* close connection to SHOUTcast server */
static void shoutcast_disconnect(t_shoutcast *x)
{
    int err = -1;
    if(x->x_lame >= 0)
    {
#ifndef UNIX
            /* deinit the stream */
        err = deinitStream(x->x_lame, x->x_mp3outbuf, &x->x_mp3size);

            /* check result */
        if(err != BE_ERR_SUCCESSFUL)
        {
            error("exiting mp3 stream failed (%lu)", err);
        }
        closeStream(x->x_lame); /* close mp3 encoder stream */
#else
        lame_close( lgfp );
#endif
        x->x_lame = -1;
        post("shoutcast~: encoder stream closed");
    }

    if(x->x_fd >= 0)            /* close socket */
    {
#ifndef UNIX
        closesocket(sockfd);
#else
        close(sockfd);
#endif
        x->x_fd = -1;
        outlet_float(x->x_obj.ob_outlet, 0);
        post("shoutcast~: connection closed");
    }
}

    /* set password for SHOUTcast server */
static void shoutcast_password(t_shoutcast *x, t_symbol *password)
{
    x->x_passwd = password->s_name;
}

    /* settings for mp3 encoding */
static void shoutcast_mpeg(t_shoutcast *x, t_floatarg fsamplerate, t_floatarg fbitrate,
                           t_floatarg fmode, t_floatarg fquality)
{
    x->x_samplerate = fsamplerate;
    if(fbitrate > MAXDATARATE)
    {
        fbitrate = MAXDATARATE;
    }
    x->x_bitrate = fbitrate;
    x->x_mp3mode = fmode;
    x->x_mp3quality = fquality;
    post("shoutcast~: setting mp3 stream to %dHz, %dkbit/s, mode %d, quality %d",
          x->x_samplerate, x->x_bitrate, x->x_mp3mode, x->x_mp3quality);
    if(x->x_fd>=0)post("shoutcast~ : reconnect to make changes take effect! ");
}

    /* print settings */
static void shoutcast_print(t_shoutcast *x)
{
    const char        * buf = 0;
    post(shoutcast_version);
    post(" mp3 settings:\n"
         "    output sample rate: %d Hz\n"
         "    bitrate: %d kbit/s", x->x_samplerate, x->x_bitrate);
    switch(x->x_mp3mode)
    {
        case 0 : 
            buf = "stereo";
            break;
        case 1 : 
            buf = "joint stereo";
            break;
        case 2 : 
            buf = "dual channel";
            break;
        case 3 : 
            buf = "mono";
            break;
    }
    post("    mode: %s\n"
         "    quality: %d", buf, x->x_mp3quality);
#ifndef UNIX
    post("    calculated mp3 chunk size: %d", x->x_lamechunk);
#else
    post("    mp3 chunk size: %d", x->x_lamechunk);
#endif
    if(x->x_samplerate!=sys_getsr())
    {
        post("    resampling from %d to %d Hz!", (int)sys_getsr(), x->x_samplerate);
    }
}

    /* clean up */
static void shoutcast_free(t_shoutcast *x)    
{
    if(x->x_lame >= 0)
#ifndef UNIX
        closeStream(x->x_lame);
#else
        lame_close( lgfp );
#endif
    if(x->x_fd >= 0)
#ifndef UNIX
        closesocket(sockfd);
#else
        close(sockfd);
#endif
    freebytes(x->x_mp3inbuf, MY_MP3_MALLOC_IN_SIZE*sizeof(short));
    freebytes(x->x_mp3outbuf, MY_MP3_MALLOC_OUT_SIZE);
    freebytes(x->x_buffer, MY_MP3_MALLOC_IN_SIZE*sizeof(short));
}

static void *shoutcast_new(void)
{
    t_shoutcast *x = (t_shoutcast *)pd_new(shoutcast_class);
    inlet_new (&x->x_obj, &x->x_obj.ob_pd, gensym ("signal"), gensym ("signal"));
    outlet_new(&x->x_obj, gensym("float"));
    x->x_fd = -1;
    x->x_lame = -1;
    x->x_passwd = "pd";
    x->x_samplerate = sys_getsr();
    x->x_bitrate = 224;
    x->x_mp3mode = 1;
    x->x_mp3quality = 5;
#ifdef UNIX
    x->x_lamechunk = 1024; /* lame chunk must be set by hand for UNIX */
#endif
    x->x_mp3inbuf = getbytes(MY_MP3_MALLOC_IN_SIZE*sizeof(short));            /* buffer for encoder input */
    x->x_mp3outbuf = getbytes(MY_MP3_MALLOC_OUT_SIZE*sizeof(char));    /* our mp3 stream */
    x->x_buffer = getbytes(MY_MP3_MALLOC_IN_SIZE*sizeof(short));    /* what we get from pd, converted to PCM */
    if ((!x->x_buffer)||(!x->x_mp3inbuf)||(!x->x_mp3outbuf))        /* check buffers... */
    {
        error("out of memory!");
    }
    x->x_bytesbuffered = 0;
    x->x_inp = 0;
    x->x_outp = 0;
    x->x_start = -1;
    return (x);
}

void shoutcast_tilde_setup(void)
{
    post(shoutcast_version);
    shoutcast_class = class_new(gensym("shoutcast~"), (t_newmethod)shoutcast_new, (t_method)shoutcast_free,
        sizeof(t_shoutcast), 0, 0);
    CLASS_MAINSIGNALIN(shoutcast_class, t_shoutcast, x_f );
    class_addmethod(shoutcast_class, (t_method)shoutcast_dsp, gensym("dsp"), 0);
    class_addmethod(shoutcast_class, (t_method)shoutcast_connect, gensym("connect"), A_SYMBOL, A_FLOAT, 0);
    class_addmethod(shoutcast_class, (t_method)shoutcast_disconnect, gensym("disconnect"), 0);
    class_addmethod(shoutcast_class, (t_method)shoutcast_password, gensym("passwd"), A_SYMBOL, 0);
    class_addmethod(shoutcast_class, (t_method)shoutcast_mpeg, gensym("mpeg"), A_FLOAT, A_FLOAT, A_FLOAT, A_FLOAT, 0);
    class_addmethod(shoutcast_class, (t_method)shoutcast_print, gensym("print"), 0);
}
