/* Copyright (c) 2000 Miller Puckette.
* For information on usage and redistribution, and for a DISCLAIMER OF ALL
* WARRANTIES, see the file, "LICENSE.txt," in the Pd distribution.  */

/* the "pdsend" command.  This is a standalone program that forwards messages
from its standard input to Pd via the netsend/netreceive ("FUDI") protocol. */

#include <sys/types.h>
#include <string.h>
#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#ifdef MSW
#include <winsock.h>
#else
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <netdb.h>
#include <stdio.h>
#include <unistd.h>
#define SOCKET_ERROR -1
#endif

#include "u_pdsend.h"


#define BUFSIZE 4096

int sockfd;


// ***********************************************************
void pdsend_init(char *hostname, int portno, char *protocol)
{
	struct sockaddr_in server;	
	struct hostent *hp;
	int nretry = 10;
	int proto;
	
	// note: protocol should be 'tcp' or 'udp' for SOCK_STREAM or SOCK_DGRAM respectively
	
	if (!strcmp(protocol, "tcp"))
		proto = SOCK_STREAM;
	else if (!strcmp(protocol, "udp"))
		proto = SOCK_DGRAM;
	else
	{
		pdsend_sockerror("init: not a valid protocol");
		exit(1);
	}
	
	#ifdef MSW
	short version = MAKEWORD(2, 0);
	WSADATA nobby;
	if (WSAStartup(version, &nobby)) pdsend_sockerror("WSAstartup");
	#endif

	sockfd = socket(AF_INET, proto, 0);
	if (sockfd < 0)
	{
		pdsend_sockerror("socket()");
		exit(1);
	}
	
	// connect socket using hostname provided in command line:
	server.sin_family = AF_INET;
	hp = gethostbyname(hostname);
	if (hp == 0)
	{
		fprintf(stderr, "%s: unknown host\n", hostname);
		pdsend_closesocket(sockfd);
		exit(1);
	}
	memcpy((char *)&server.sin_addr, (char *)hp->h_addr, hp->h_length);

	// assign client port number:
	server.sin_port = htons((unsigned short)portno);


	if (connect(sockfd, (struct sockaddr *) &server, sizeof (server)) < 0)
	{
		pdsend_sockerror("connect");
		pdsend_closesocket(sockfd);
		exit(1);
	}
	
}

// ***********************************************************
void pdsend_message(char *msg)
{
	//printf("sending '%s' (length=%d) to Pd\n", msg, strlen(msg));

	int res = send(sockfd, msg, strlen(msg), 0);
	if (res < 0)
	{
		pdsend_sockerror("send");
		exit (0);
	}
	
}

// ***********************************************************
void pdsend_list(int argc, char **argv)
{
	int i;
	int msgLength = 0; // should this be 1?
	char *msg;
	
	for (i=0; i<argc; i++)
	{
		// the +1 is to hold the space between words, or the semicolon in case of the last word
		msgLength += strlen(argv[i]) + 1;
	}
	
	msg = (char *) malloc(msgLength);
	strcpy(msg, argv[0]);
	
	for (i=0; i<argc; i++)
	{
		strcat(msg, " ");
		strcat(msg, argv[i]);
	}
	
	strcat(msg, ";");
	
	pdsend_message(msg);
	
}

// ***********************************************************
void pdsend_sockerror(char *s)
{
#ifdef MSW
	int err = WSAGetLastError();
	if (err == 10054) return;
	else if (err == 10044)
	{
		fprintf(stderr, "Warning: you might not have TCP/IP \"networking\" turned on\n");
	}
#else
	int err = errno;
#endif
	fprintf(stderr, "%s: %s (%d)\n", s, strerror(err), err);
}

void pdsend_closesocket(int fd)
{
#ifdef MSW
	closesocket(fd);
#else
	close(fd);
#endif
}
