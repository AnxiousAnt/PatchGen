// C++ includes.
#include <iostream>
#include <stdio.h>

// OpenCV includes.
#include <cv.h>
#include <highgui.h>

void printCamResolution(CvCapture* camera)
{
	std::cout << std::endl;
	std::cout << "Camera Capture Resolution:" << std::endl;
	std::cout << "=================" << std::endl;
	std::cout << "Video width: " << cvGetCaptureProperty(camera, CV_CAP_PROP_FRAME_WIDTH) << std::endl;
	std::cout << "Video height: " << cvGetCaptureProperty(camera, CV_CAP_PROP_FRAME_HEIGHT) << std::endl;
	std::cout << std::endl;
}


// A Simple Camera Capture Framework
int main(int argc, char **argv) {

	int cameraID;
	CvSize frameSize;
	CvCapture* capture;
	
	if (argc) sscanf(argv[0], "%d", &cameraID);
	else cameraID = CV_CAP_ANY;
	
	capture = cvCaptureFromCAM( cameraID );
	printCamResolution(capture);
	
	if( !capture ) {
		fprintf( stderr, "ERROR: capture is NULL \n" );
		getchar();
		return -1;
	}
	
	
  // Create a window in which the captured images will be presented
	cvNamedWindow( "RAW Feed", CV_WINDOW_AUTOSIZE );
	
	// MAIN LOOP:
	while( 1 ) {
		
		// Get a frame from the camera
		IplImage* frame = cvQueryFrame( capture );
		if( !frame ) {
			fprintf( stderr, "ERROR: frame is null...\n" );
			getchar();
			break;
		}
		frameSize = cvSize(frame->width,frame->height);

		cvShowImage( "RAW Feed", frame );
		// Do not release the frame!

		//If ESC key pressed, Key=0x10001B under OpenCV 0.9.7(linux version),
		//remove higher bits using AND operator
		if( (cvWaitKey(10) & 255) == 27 ) break;
	}

	// Release the capture device housekeeping
	cvReleaseCapture( &capture );
	cvDestroyWindow( "RAW Feed" );
	return 0;
}

