#include "blobtrack.h"
#include "u_pdsend.h"
#include <stdio.h>

#define MAX_PROCESSED_BLOBS 6

int SHOW_DEBUG_DISPLAYS = true;


CvBlobTrackerAutoParam1 param = {0};

int trackbarPos = 0;

void set_FG_NG (int id) { id; (param.pFG)->SetParam("NG",(double)trackbarPos); }

void set_BD_HMin (int id) { id; (param.pBD)->SetParam("HMin",(double)trackbarPos/100); };
void set_BD_WMin (int id) { id; (param.pBD)->SetParam("WMin",(double)trackbarPos/100); };
void set_BD_Latency (int id) { id; (param.pBD)->SetParam("Latency",(double)trackbarPos); };
void set_BD_Clastering (int id) { id; (param.pBD)->SetParam("Clastering",(double)trackbarPos); };
void set_BD_MinDistToBorder (int id) { id; (param.pBD)->SetParam("MinDistToBorder",(double)trackbarPos/10); };
void set_BD_OnlyROI (int id) { id; (param.pBD)->SetParam("OnlyROI",(double)trackbarPos); };

void set_BT_PosVar (int id) { id; (param.pBT)->SetParam("PosVar",(double)trackbarPos/10); };
void set_BT_AlphaSize (int id) { id; (param.pBT)->SetParam("AlphaSize",(double)trackbarPos/100); };
void set_BT_Alpha (int id) { id; (param.pBT)->SetParam("Alpha",(double)trackbarPos/100); };
void set_BT_UseVel (int id) { id; (param.pBT)->SetParam("UseVel",(double)trackbarPos); };

void set_Kalman_ModelNoise (int id) { id; (param.pBTPP)->SetParam("ModelNoise",(double)trackbarPos/1000); };
void set_Kalman_DataNoisePos (int id) { id; (param.pBTPP)->SetParam("DataNoisePos",(double)trackbarPos/1000); };
void set_Kalman_DataNoiseSize (int id) { id; (param.pBTPP)->SetParam("DataNoiseSize",(double)trackbarPos/1000); };

IplImage*   pImg = NULL;
IplImage*   pMask = NULL;	

int mouseButtonDown = 0;
CvPoint origin;
CvRect selection;
CvRect ROI;
CvBox2D track_box;
void on_mouse( int event, int x, int y, int flags, void* param )
{
	if ( !pImg )
		return;

	if (pImg->origin)
		y = pImg->height - y;

	if (mouseButtonDown)
	{
		selection.x = MIN(x,origin.x);
		selection.y = MIN(y,origin.y);
		selection.width = selection.x + CV_IABS(x - origin.x);
		selection.height = selection.y + CV_IABS(y - origin.y);
		
		selection.x = MAX( selection.x, 0 );
		selection.y = MAX( selection.y, 0 );
		selection.width = MIN( selection.width, pImg->width );
		selection.height = MIN( selection.height, pImg->height );
		selection.width -= selection.x;
		selection.height -= selection.y;
	}

	switch(event)
	{
		case CV_EVENT_LBUTTONDOWN:
			origin = cvPoint(x,y);
			selection = cvRect(x,y,0,0);
			mouseButtonDown = 1;
			break;
		case CV_EVENT_LBUTTONUP:
			mouseButtonDown = 0;
			if ( selection.width>0 && selection.height>0 )
			{
				ROI = selection;
				printf("ROI set to (%d,%d,%d,%d)\n", selection.x, selection.y, selection.width, selection.height);
			} else {
				ROI.x = 0;
				ROI.y = 0;
				ROI.width = 639;
				ROI.height = 479;
			}
			break;
	}
}


// ***********************************************************
// run pipeline on all frames:
static int RunBlobTrackingAuto( CvCapture* pCap, CvBlobTrackerAuto* pTracker,char* fgavi_name = NULL, char* btavi_name = NULL )
{
	int                     OneFrameProcess = 0;
	int                     key;
	CvVideoWriter*          pFGAvi = NULL;
	CvVideoWriter*          pBTAvi = NULL;

	
	
	if (SHOW_DEBUG_DISPLAYS)
	{
	
		cvNamedWindow( "FG", CV_WINDOW_AUTOSIZE );
		cvNamedWindow( "Tracking", CV_WINDOW_AUTOSIZE);
		
		cvSetMouseCallback( "Tracking", on_mouse, 0 );
		
		trackbarPos = (int) (param.pFG->GetParam("NG"));
		cvCreateTrackbar( "Number of Gaussians", "FG", &trackbarPos, 100, set_FG_NG );
		
		
		trackbarPos = (int) (param.pBD->GetParam("HMin") * 100) +1;
		cvCreateTrackbar( "Min blob width (1/100)", "Tracking", &trackbarPos, 100, set_BD_HMin );
		trackbarPos = (int) (param.pBD->GetParam("WMin") * 100) +1;
		cvCreateTrackbar( "Min blob height (1/100)", "Tracking", &trackbarPos, 100, set_BD_WMin );
		
		trackbarPos = (int) (param.pBD->GetParam("Latency"));
		cvCreateTrackbar( "Blob Detection Latency", "Tracking", &trackbarPos, 100, set_BD_Latency );

		
		// Clastering: enables Minimal allowed distance from blob center to image border in blob sizes
		trackbarPos = (int) (param.pBD->GetParam("Clastering"));
		cvCreateTrackbar( "Enable Clastering", "Tracking", &trackbarPos, 1, set_BD_Clastering );
		trackbarPos = (int) (param.pBD->GetParam("MinDistToBorder") * 10);
		cvCreateTrackbar( "Blob MinDistToBorder (1/10)", "Tracking", &trackbarPos, 100, set_BD_MinDistToBorder );
		
		trackbarPos = (int) (param.pBD->GetParam("OnlyROI"));
		cvCreateTrackbar( "Show ROI", "Tracking", &trackbarPos, 1, set_BD_OnlyROI );
		
		
		/*
		// PosVar = Position variation (in object size), default=0.2
		trackbarPos = (int) (param.pBT->GetParam("PosVar") * 10);
		cvCreateTrackbar( "Blob Positional Variance (1/10)", "Tracking", &trackbarPos, 100, set_BT_PosVar );
		// AlphaSize = size update speed (0..1), default=0.05
		trackbarPos = (int) (param.pBT->GetParam("AlphaSize") * 100);
		cvCreateTrackbar( "Blob AlphaSize (1/100)", "Tracking", &trackbarPos, 100, set_BT_AlphaSize );
		// Alpha = Coefficient for model histogramm updating (0 - hist is not upated), default=0.05
		trackbarPos = (int) (param.pBT->GetParam("Alpha)") * 100) +1;
		cvCreateTrackbar( "Blob Alpha (1/100)", "Tracking", &trackbarPos, 100, set_BT_Alpha );
		// UseVel = Percent of particles which use velocity feature
		trackbarPos = (int) (param.pBT->GetParam("UseVel"));
		cvCreateTrackbar( "Percent of Particles with Velocity", "Tracking", &trackbarPos, 100, set_BT_UseVel );
		*/
		/*
		trackbarPos = (int) (param.pBTPP->GetParam("ModelNoise") * 1000);
		cvCreateTrackbar( "Kalman ModelNoise (1/1000)", "Tracking", &trackbarPos, 100, set_Kalman_ModelNoise );
		trackbarPos = (int) (param.pBTPP->GetParam("DataNoisePos") * 1000);
		cvCreateTrackbar( "Kalman DataNoisePos (1/1000)", "Tracking", &trackbarPos, 100, set_Kalman_DataNoisePos );
		trackbarPos = (int) (param.pBTPP->GetParam("DataNoiseSize") * 1000);
		cvCreateTrackbar( "Kalman DataNoiseSize (1/1000)", "Tracking", &trackbarPos, 100, set_Kalman_DataNoiseSize );
		*/
	}
	
	
	ROI.x = 0;
	ROI.y = 0;
	ROI.width = 639;
	ROI.height = 479;
	
	IplImage*   pCapture = NULL;
	
	// main loop:
	while ((key=cvWaitKey(10))!=27) // key 27 is escape
	{
		pCapture = cvQueryFrame(pCap);
		if (pCapture == NULL) break;
	
		//cvShowImage( "RAW Feed", pImg );
		
		if (key=='p')
		{
			
			printf("***********************************************************\n");
			print_params(param.pFG,"FG",NULL);
			print_params(param.pBD,"BlobDetector",NULL);
			print_params(param.pBTPP,"BlobTracker",NULL);
		}
		
		
		// Process:
		//printf("ROI is (%d,%d,%d,%d)\n", ROI.x, ROI.y, ROI.width, ROI.height);
		
		
		/*
		// Set up the size of the crop rectangle.
		cvSetImageROI(pCapture,ROI);
		cvGetImageROI(pCapture);
		pImg = cvCreateImage(cvSize(ROI.width,ROI.height),pCapture->depth,pCapture->nChannels);

		// pImg receives the cropped portion.
		cvCopy(pCapture, pImg, 0);
		*/
		
		
		
		// why doesn't the following work:
		/*
		cvSetImageROI( pImg, ROI );
		cvGetImageROI(pImg);
		pTracker->Process(pImg, pMask);
		cvResetImageROI( pImg );
		*/
		
		pImg=pCapture;

		
		// The process:
		pTracker->Process(pImg, pMask);
		
		
		if (pTracker->GetFGMask())
		{
			IplImage*           pFG = pTracker->GetFGMask();
			CvSize              S = cvSize(pFG->width,pFG->height);
			static IplImage*    pI = NULL;
	
			if (pI==NULL) pI = cvCreateImage(S,pFG->depth,3);
			cvCvtColor( pFG, pI, CV_GRAY2BGR );
			
			// draw detected blobs:
			if (pTracker->GetBlobNum()>0)
			{
				int i;
				for (i=pTracker->GetBlobNum(); i>0; i--)
				{
					// limit the amount of blobs we process:
					if (pTracker->GetBlobNum()-i > MAX_PROCESSED_BLOBS) break;
					
					CvBlob* pB = pTracker->GetBlob(i-1);
					CvPoint p = cvPointFrom32f(CV_BLOB_CENTER(pB));
					CvSize  s = cvSize(MAX(1,cvRound(CV_BLOB_RX(pB))), MAX(1,cvRound(CV_BLOB_RY(pB))));
					int c = cvRound(255*pTracker->GetState(CV_BLOB_ID(pB)));
					cvEllipse( pI,
									p,
									s,
									0, 0, 360,
									CV_RGB(c,255-c,0), cvRound(1+(3*c)/255) );
				} // next blob;
			}
	
			if (SHOW_DEBUG_DISPLAYS) cvShowImage( "FG", pI );
		
		}
		
		
	
	
		// draw debug info
		if (pImg)
		{
			char        str[1024];
			int         line_type = CV_AA; // change it to 8 to see non-antialiased graphics
			CvFont      font;
			int         i;
			
			//cvSetImageROI( pImg, ROI );
			IplImage*   pI = cvCloneImage(pImg);
			//cvResetImageROI( pImg );
				
			cvInitFont( &font, CV_FONT_HERSHEY_PLAIN, 0.7, 0.7, 0, 1, line_type );
	
			
			for (i=pTracker->GetBlobNum(); i>0; i--)
			{
				// limit the amount of blobs we process:
				if (pTracker->GetBlobNum()-i > MAX_PROCESSED_BLOBS) break;
				
				CvSize  TextSize;
				CvBlob* pB = pTracker->GetBlob(i-1);
				CvPoint p = cvPoint(cvRound(pB->x*256),cvRound(pB->y*256));
				CvSize  s = cvSize(MAX(1,cvRound(CV_BLOB_RX(pB)*256)), MAX(1,cvRound(CV_BLOB_RY(pB)*256)));
				int c = cvRound(255*pTracker->GetState(CV_BLOB_ID(pB)));
	
				cvEllipse( pI,
								p,
								s,
								0, 0, 360,
								CV_RGB(c,255-c,0), cvRound(1+(3*0)/255), CV_AA, 8 );
				p.x >>= 8;
				p.y >>= 8;
				s.width >>= 8;
				s.height >>= 8;
				//sprintf(str,"%03d",CV_BLOB_ID(pB));
				sprintf(str,"%03d",i);
				cvGetTextSize( str, &font, &TextSize, NULL );
				p.y -= s.height;
				cvPutText( pI, str, p, &font, CV_RGB(0,255,255));
				
				/*
				// show blob state (ie, normal/abnormal)
				{
					char* pS = pTracker->GetStateDesc(CV_BLOB_ID(pB));
					if(pS)
					{
						char* pStr = strdup(pS);
						char* pStrFree = pStr;
						for(;pStr && strlen(pStr)>0;)
						{
							char* str_next = strchr(pStr,'\n');
							if(str_next)
							{
								str_next[0] = 0;
								str_next++;
							}
							p.y += TextSize.height+1;
							cvPutText( pI, pStr, p, &font, CV_RGB(0,255,255));
							pStr = str_next;
						}
						free(pStrFree);
					}
				}
				*/
				
				// send blob to Pd:
				sprintf(str,"%03d %d %d %d %d;",i,p.x,p.y,s.width,s.height);
				pdsend_message(str);
	
			} // next blob
					
			if (SHOW_DEBUG_DISPLAYS)
			{
				//cvEllipseBox( pI, selection, CV_RGB(255,0,0), 3, CV_AA, 0 );
				//cvEllipseBox( pi, track_box, CV_RGB(255,0,0), 3, CV_AA, 0 );
				cvRectangle( pI, cvPoint(selection.x,selection.y), cvPoint(selection.x+selection.width,selection.y+selection.height), CV_RGB(255,255,0), 1 );
				cvShowImage( "Tracking",pI );
			}
	
			cvReleaseImage(&pI);
		}
			
	} // main loop
		
		
	if(pFGAvi)cvReleaseVideoWriter( &pFGAvi );
	if(pBTAvi)cvReleaseVideoWriter( &pBTAvi );
	return 0;

} // RunBlobTrackingAuto

// ***********************************************************
// read parameters from command line and transfer to specified module:
static void set_params(int argc, char* argv[], CvVSModule* pM, char* prefix, char* module)
{
	int prefix_len = strlen(prefix);
	int i;
	for(i=0;i<argc;++i)
	{
		int j;
		char* ptr_eq = NULL;
		int   cmd_param_len=0;
		char* cmd = argv[i];
		if(MY_STRNICMP(prefix,cmd,prefix_len)!=0) continue;
		cmd += prefix_len;
		if(cmd[0]!=':')continue;
		cmd++;
	
		ptr_eq = strchr(cmd,'=');
		if(ptr_eq)cmd_param_len = ptr_eq-cmd;
		for(j=0;;++j)
		{
			int     param_len;
			char*   param = pM->GetParamName(j);
			if(param==NULL) break;
			param_len = strlen(param);
			if(cmd_param_len!=param_len) continue;
			if(MY_STRNICMP(param,cmd,param_len)!=0) continue;
			cmd+=param_len;
			if(cmd[0]!='=')continue;
			cmd++;
			pM->SetParamStr(param,cmd);
			printf("%s:%s param set to %g\n",module,param,pM->GetParam(param));
		}
	}
	pM->ParamUpdate();
}

// ***********************************************************
// print all parameters value for given module:
static void print_params (CvVSModule* pM, char* module, char* log_name)
{
	FILE* log = log_name?fopen(log_name,"at"):NULL;
	int i;
	if(pM->GetParamName(0)==NULL) return;
	
	printf("%s(%s) module parameters:\n",module,pM->GetNickName());
	if (log) fprintf(log,"%s(%s) module parameters:\n",module,pM->GetNickName());
	for (i=0;;++i)
	{
		char*   param = pM->GetParamName(i);
		char*   str = param?pM->GetParamStr(param):NULL;
		if (param==NULL) break;
		if (str)
		{
			printf("  %s: %s\n",param,str);
			if(log) fprintf(log,"  %s: %s\n",param,str);
		}
		else
		{
			printf("  %s: %g\n",param,pM->GetParam(param));
			if (log) fprintf(log,"  %s: %g\n",param,pM->GetParam(param));
		}
	}
	if (log) fclose(log);
}


// ***********************************************************
// print help:
static void print_help ()
{
	
	int i;
	printf("blobtrack [fg=<fg_name>] [bd=<bd_name>]\n"
			"          [bt=<bt_name>] [btpp=<btpp_name>]\n"
			"          [bta=<bta_name>\n"
			"          [bta_data=<bta_data_name>\n"
			"          [bt_corr=<bt_corr_way>]\n"
			"          [btgen=<btgen_name>]\n"
			"          [track=<track_file_name>]\n"
			"          [scale=<scale val>] [noise=<noise_name>] [IVar=<IVar_name>]\n"
			"          [FGTrainFrames=<FGTrainFrames>]\n"
			"          [btavi=<avi output>] [fgavi=<avi output on FG>]\n"
			"          <avi_file>\n");
	printf("  <bt_corr_way> is way of blob position corrrection for \"Blob Tracking\" module\n"
			"     <bt_corr_way>=none,PostProcRes\n"
			"  <FGTrainFrames> is number of frames for FG training\n"
			"  <track_file_name> is file name for save tracked trajectories\n"
			"  <bta_data> is file name for data base of trajectory analysis module\n"
			"  <avi_file> is file name of avi to process by BlobTrackerAuto\n");
	
	puts("\nModules:");
#define PR(_name,_m,_mt)\
	printf("<%s> is \"%s\" module name and can be:\n",_name,_mt);\
	for(i=0;_m[i].nickname;++i)\
	{\
	printf("  %d. %s",i+1,_m[i].nickname);\
	if(_m[i].description)printf(" - %s",_m[i].description);\
	printf("\n");\
}
	
	PR("fg_name",FGDetector_Modules,"FG/BG Detection");
	PR("bd_name",BlobDetector_Modules,"Blob Entrance Detection");
	PR("bt_name",BlobTracker_Modules,"Blob Tracking");
	PR("btpp_name",BlobTrackPostProc_Modules, "Blob Trajectory Post Processing");
	PR("btgen_name",BlobTrackGen_Modules, "Blob Trajectory Generation");
	PR("bta_name",BlobTrackAnalysis_Modules, "Blob Trajectory Analysis");
#undef PR

}


int main(int argc, char* argv[])
{
	CvCapture*                  pCap = NULL;
	
	CvBlobTrackerAuto*          pTracker = NULL;
	
	int i;
	CvFileStorage* fs = NULL;
	
	float       scale = 1;
	char*       scale_name = NULL;
	char*       yml_name = NULL;
	char**      yml_video_names = NULL;
	int         yml_video_num = 0;
	char*       avi_name = NULL;
	char*       fg_name = NULL;
	char*       fgavi_name = NULL;
	char*       btavi_name = NULL;
	char*       bd_name = NULL;
	char*       bt_name = NULL;
	char*       btgen_name = NULL;
	char*       btpp_name = NULL;
	char*       bta_name = NULL;
	char*       bta_data_name = NULL;
	char*       track_name = NULL;
	char*       comment_name = NULL;
	char*       FGTrainFrames = NULL;
	char*       log_name = NULL;
	char*       savestate_name = NULL;
	char*       loadstate_name = NULL;
	char*       bt_corr = NULL;

	char*       host = "localhost";
	int         port = 8779;
	char*       protocol = "tcp";


	DefModule_FGDetector*           pFGModule = NULL;
	DefModule_BlobDetector*         pBDModule = NULL;
	DefModule_BlobTracker*          pBTModule = NULL;
	DefModule_BlobTrackPostProc*    pBTPostProcModule = NULL;
	DefModule_BlobTrackGen*         pBTGenModule = NULL;
	DefModule_BlobTrackAnalysis*    pBTAnalysisModule = NULL;
	
	cvInitSystem(argc, argv);
	
	// ***************************************************************************
	// parse arguments:
	for(i=1;i<argc;++i)
	{
		int bParsed = 0;
		size_t len = strlen(argv[i]);
		
		#define RO(_n1,_n2) if(strncmp(argv[i],_n1,strlen(_n1))==0) {_n2 = argv[i]+strlen(_n1);bParsed=1;};
		RO("fg=",fg_name);
		RO("fgavi=",fgavi_name);
		RO("btavi=",btavi_name);
		RO("bd=",bd_name);
		RO("bt=",bt_name);
		RO("bt_corr=",bt_corr);
		RO("btpp=",btpp_name);
		RO("bta=",bta_name);
		RO("bta_data=",bta_data_name);
		RO("btgen=",btgen_name);
		RO("track=",track_name);
		RO("comment=",comment_name);
		RO("FGTrainFrames=",FGTrainFrames);
		RO("log=",log_name);
		RO("savestate=",savestate_name);
		RO("loadstate=",loadstate_name);

		RO("host=",host);
		RO("protocol=",protocol);
		#undef RO

		if (!bParsed)
		{
			if (MY_STRICMP(argv[i],"port=")==0)
			{
				sscanf(argv[i]+5, "%d", &port);
			}

			else if (MY_STRICMP(argv[i],"-nodisplays")==0)
			{
				SHOW_DEBUG_DISPLAYS = false;
			}

			//else if (strrchr(argv[i],'=')==NULL))
			//{}
			
			else if (MY_STRICMP(argv[i],"--help")==0)
			{
				print_help();
				exit(1);

			} else {
				char* ext = argv[i] + len-4;
				if ((len>3) && (MY_STRICMP(ext,".avi") == 0 ))
				{
					avi_name = argv[i];
					break;
				}
			}
		}
	} // next argument
	
	// ***************************************************************************
	// get source video:
	if (avi_name) pCap = cvCaptureFromFile(avi_name);
	else pCap = cvCaptureFromCAM( 0 ); // hack to use 2nd camera
	//else pCap = cvCaptureFromCAM( CV_CAP_ANY );
	
	if (pCap==NULL)
	{
		printf("Can't open capture (pCap)\n");
		return -1;
	}
	
	// ***************************************************************************
	// connect to pd:
	pdsend_init(host, port, protocol);
	
	
	// ***************************************************************************
	// set Trajectory Generator module
	if (track_name)
	{
		if(!btgen_name)btgen_name=BlobTrackGen_Modules[0].nickname;
		for(i=0;BlobTrackGen_Modules[i].nickname;++i)
		{
		if(MY_STRICMP(BlobTrackGen_Modules[i].nickname,btgen_name)==0)
			pBTGenModule = BlobTrackGen_Modules + i;
		}
	}
	
	// ***************************************************************************
	// init postprocessing module if tracker correction by postporcessing is reqierd
	if(bt_corr && MY_STRICMP(bt_corr,"PostProcRes")!=0 && !btpp_name)
	{
		btpp_name = bt_corr;
		if (MY_STRICMP(btpp_name,"none")!=0) bt_corr = "PostProcRes";
	}
	
	// ***************************************************************************
	// set default parameters for one processing
	if(!bt_corr) bt_corr = "none";
	if(!fg_name) fg_name = FGDetector_Modules[2].nickname;
	if(!bd_name) bd_name = BlobDetector_Modules[0].nickname;
	if(!bt_name) bt_name = BlobTracker_Modules[0].nickname;
	if(!btpp_name) btpp_name = BlobTrackPostProc_Modules[0].nickname;
	if(!bta_name) bta_name = BlobTrackAnalysis_Modules[0].nickname;
	if(!scale_name) scale_name = "1";
	
	if(scale_name) 
		scale = (float)atof(scale_name);
	for(pFGModule=FGDetector_Modules;pFGModule->nickname;++pFGModule)
		if( fg_name && MY_STRICMP(fg_name,pFGModule->nickname)==0 ) break;
	for(pBDModule=BlobDetector_Modules;pBDModule->nickname;++pBDModule)
		if( bd_name && MY_STRICMP(bd_name,pBDModule->nickname)==0 ) break;
	for(pBTModule=BlobTracker_Modules;pBTModule->nickname;++pBTModule)
		if( bt_name && MY_STRICMP(bt_name,pBTModule->nickname)==0 ) break;
	for(pBTPostProcModule=BlobTrackPostProc_Modules;pBTPostProcModule->nickname;++pBTPostProcModule)
		if( btpp_name && MY_STRICMP(btpp_name,pBTPostProcModule->nickname)==0 ) break;
	for(pBTAnalysisModule=BlobTrackAnalysis_Modules;pBTAnalysisModule->nickname;++pBTAnalysisModule)
		if( bta_name && MY_STRICMP(bta_name,pBTAnalysisModule->nickname)==0 ) break;
	

	
	// ***************************************************************************
	// display parameters:
	FILE* log = log_name?fopen(log_name,"at"):NULL;
	if (log)
	{ // print to log file
		fprintf(log,"\n=== Blob Tracking pipline in processing mode===\n");
		if(avi_name)
		{
			fprintf(log,"AVIFile: %s\n",avi_name);
		}
		fprintf(log,"FGDetector:   %s\n", pFGModule->nickname);
		fprintf(log,"BlobDetector: %s\n", pBDModule->nickname);
		fprintf(log,"BlobTracker:  %s\n", pBTModule->nickname);
		fprintf(log,"BlobTrackPostProc:  %s\n", pBTPostProcModule->nickname);
		fprintf(log,"BlobCorrection:  %s\n", bt_corr);
		fprintf(log,"Blob Trajectory Generator:  %s (%s)\n", pBTGenModule?pBTGenModule->nickname:"None", track_name?track_name:"none");
		fprintf(log,"BlobTrackAnalysis:  %s\n", pBTAnalysisModule->nickname);
		fclose(log);
	}
	
	printf("\n=== Blob Tracking pipline in %s mode===\n","processing");
	if (yml_name)
	{
		printf("ConfigFile: %s\n",yml_name);
		printf("BG: %s\n",yml_video_names[0]);
		printf("FG: ");
		for(i=1;i<(yml_video_num);++i){printf(yml_video_names[i]);if((i+1)<yml_video_num)printf("|");};
		printf("\n");
	}
	if (avi_name)
	{
		printf("AVIFile: %s\n",avi_name);
	}
	printf("FGDetector:   %s\n", pFGModule->nickname);
	printf("BlobDetector: %s\n", pBDModule->nickname);
	printf("BlobTracker:  %s\n", pBTModule->nickname);
	printf("BlobTrackPostProc:  %s\n", pBTPostProcModule->nickname);
	printf("BlobCorrection:  %s\n", bt_corr);
	printf("Blob Trajectory Generator:  %s (%s)\n", pBTGenModule?pBTGenModule->nickname:"None", track_name?track_name:"none");
	printf("BlobTrackAnalysis:  %s\n", pBTAnalysisModule->nickname);
	
	
	// ***************************************************************************
	// create autotracker module and its components:
	param.FGTrainFrames = FGTrainFrames?atoi(FGTrainFrames):0;
	
	/* Create FG Detection module */
	param.pFG = pFGModule->create();
	if(!param.pFG)
	puts("Can not create FGDetector module");
	param.pFG->SetNickName(pFGModule->nickname);
	set_params(argc, argv, param.pFG, "fg", pFGModule->nickname);
	
	/* Create Blob Entrance Detection module */
	param.pBD = pBDModule->create();
	if(!param.pBD)
	puts("Can not create BlobDetector module");
	param.pBD->SetNickName(pBDModule->nickname);
	set_params(argc, argv, param.pBD, "bd", pBDModule->nickname);
	
	/* Create blob tracker module */
	param.pBT = pBTModule->create();
	if(!param.pBT)
	puts("Can not create BlobTracker module");
	param.pBT->SetNickName(pBTModule->nickname);
	set_params(argc, argv, param.pBT, "bt", pBTModule->nickname);
	
	/* create blob trajectory generation module */
	param.pBTGen = NULL;
	if(pBTGenModule && track_name && pBTGenModule->create)
	{
		param.pBTGen = pBTGenModule->create();
		param.pBTGen->SetFileName(track_name);
	}
	if(param.pBTGen)
	{
		param.pBTGen->SetNickName(pBTGenModule->nickname);
		set_params(argc, argv, param.pBTGen, "btgen", pBTGenModule->nickname);
	}
	
	/* create blob trajectory post processing module */
	param.pBTPP = NULL;
	if(pBTPostProcModule && pBTPostProcModule->create)
	{
		param.pBTPP = pBTPostProcModule->create();
	}
	if(param.pBTPP)
	{
		param.pBTPP->SetNickName(pBTPostProcModule->nickname);
		set_params(argc, argv, param.pBTPP, "btpp", pBTPostProcModule->nickname);
	}
	
	param.UsePPData = (bt_corr && MY_STRICMP(bt_corr,"PostProcRes")==0);
	
	/* create blob trajectory analysis module */
	param.pBTA = NULL;
	if(pBTAnalysisModule && pBTAnalysisModule->create)
	{
		param.pBTA = pBTAnalysisModule->create();
		param.pBTA->SetFileName(bta_data_name);
	}
	if(param.pBTA)
	{
		param.pBTA->SetNickName(pBTAnalysisModule->nickname);
		set_params(argc, argv, param.pBTA, "bta", pBTAnalysisModule->nickname);
	}
	
	/* create whole pipline */
	pTracker = cvCreateBlobTrackerAuto1(&param);
	if(!pTracker)
		puts("Can not create BlobTrackerAuto");
	
	
	// ***************************************************************************
	// load states of each module from state file:
	fs = NULL;
	if (loadstate_name) fs=cvOpenFileStorage(loadstate_name,NULL,CV_STORAGE_READ);
	if(fs)
	{
		printf("Load states for modules...\n");
		if(param.pBT)
		{
			CvFileNode* fn = cvGetFileNodeByName(fs,NULL,"BlobTracker");
			param.pBT->LoadState(fs,fn);
		}
		
		if(param.pBTA)
		{
			CvFileNode* fn = cvGetFileNodeByName(fs,NULL,"BlobTrackAnalyser");
			param.pBTA->LoadState(fs,fn);
		}
	
		if(pTracker)
		{
			CvFileNode* fn = cvGetFileNodeByName(fs,NULL,"BlobTrackerAuto");
			pTracker->LoadState(fs,fn);
		}
	
		cvReleaseFileStorage(&fs);
		printf("... Modules states loaded\n");
	}
	
	// ***************************************************************************
	// print modules parameters:
	struct DefMMM
	{
		CvVSModule* pM;
		char* name;
	}
	Modules[] = {
		{(CvVSModule*)param.pFG,"FGdetector"},
		{(CvVSModule*)param.pBD,"BlobDetector"},
		{(CvVSModule*)param.pBT,"BlobTracker"},
		{(CvVSModule*)param.pBTGen,"TrackGen"},
		{(CvVSModule*)param.pBTPP,"PostProcessing"},
		{(CvVSModule*)param.pBTA,"TrackAnalysis"},
		{NULL,NULL}
	};
	
	for(i=0;Modules[i].name;++i)
	{
		if(Modules[i].pM) print_params(Modules[i].pM,Modules[i].name,log_name);
	}
	
	// ***************************************************************************
	// run:
	
	// set some params first:
	set_BD_HMin(6);
	set_BD_WMin(6);
	set_BD_Latency(5);
	set_BD_MinDistToBorder(0);
	
	
	(param.pBD)->SetParam("HMin",0.06);
	(param.pBD)->SetParam("WMin",0.06);
	(param.pBD)->SetParam("Latency",5);
	(param.pBD)->SetParam("MinDistToBorder",0);
	
	
	RunBlobTrackingAuto( pCap, pTracker, fgavi_name, btavi_name );
	
	// ***************************************************************************
	// save state and release modules:
	fs = NULL;
	if(savestate_name)
	{
		fs=cvOpenFileStorage(savestate_name,NULL,CV_STORAGE_WRITE);
	}
	if(fs)
	{
		cvStartWriteStruct(fs,"BlobTracker",CV_NODE_MAP);
		if(param.pBT)param.pBT->SaveState(fs);
		cvEndWriteStruct(fs);
		cvStartWriteStruct(fs,"BlobTrackerAuto",CV_NODE_MAP);
		if(pTracker)pTracker->SaveState(fs);
		cvEndWriteStruct(fs);
		cvStartWriteStruct(fs,"BlobTrackAnalyser",CV_NODE_MAP);
		if(param.pBTA)param.pBTA->SaveState(fs);
		cvEndWriteStruct(fs);
		cvReleaseFileStorage(&fs);
	}
	if(param.pBT)cvReleaseBlobTracker(&param.pBT);
	if(param.pBD)cvReleaseBlobDetector(&param.pBD);
	if(param.pBTGen)cvReleaseBlobTrackGen(&param.pBTGen);
	if(param.pBTA)cvReleaseBlobTrackAnalysis(&param.pBTA);
	if(param.pFG)cvReleaseFGDetector(&param.pFG);
	if(pTracker)cvReleaseBlobTrackerAuto(&pTracker);

	
	if (pCap) cvReleaseCapture(&pCap);
	
	return 0;
}



