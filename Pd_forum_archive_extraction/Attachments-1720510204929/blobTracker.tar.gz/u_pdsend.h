#ifndef U_PDSEND_H
#define U_PDSEND_H

void pdsend_init(char *hostname, int portno, char *protocol);
void pdsend_message(char *msg);
void pdsend_list(int argc, char **argv);
void pdsend_sockerror(char *s);
void pdsend_closesocket(int fd);

#endif
