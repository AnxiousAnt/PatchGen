/* lozi Attractor PD External */
/* Copyright taken from Willi-Hans Steeb: Chaos and Fractals, 2006 */
/* This program is distributed under the params of the GNU Public License */

///////////////////////////////////////////////////////////////////////////////////
/* This file is part of Chaos PD Externals.                                      */
/*                                                                               */
/* Chaos PD Externals are free software; you can redistribute them and/or modify */
/* them under the terms of the GNU General Public License as published by        */
/* the Free Software Foundation; either version 2 of the License, or             */
/* (at your option) any later version.                                           */
/*                                                                               */
/* Chaos PD Externals are distributed in the hope that they will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of                */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                 */
/* GNU General Public License for more details.                                  */
/*                                                                               */
/* You should have received a copy of the GNU General Public License             */
/* along with the Chaos PD Externals; if not, write to the Free Software         */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA     */
///////////////////////////////////////////////////////////////////////////////////

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include "m_pd.h"

#define M_a_lo -1
#define M_a_hi 2
#define M_b_lo -1
#define M_b_hi 2

#define M_a 0
#define M_b 1

#define M_x 0
#define M_y 1

#define LY_ITERATIONS 50000
#define LY_ABERATION 10e-15
#define LY_COUNT 3

#define M_param_count 2
#define M_var_count 2
#define M_search_count 3
#define M_limits_count 4
#define M_failure_limit 1000

static char *version = "lozi v0.05, by taken from Willi-Hans Steeb: Chaos and Fractals, 2006";

t_class *lozi_class;

typedef struct lozi_struct {
	t_object x_obj;

	double vars[M_var_count];
	double vars_init[M_var_count];
	t_atom vars_out[M_var_count];
	t_outlet *vars_outlet;
	
	t_atom search_out[(M_search_count > M_limits_count) ? M_search_count + LY_COUNT : M_limits_count + LY_COUNT];
	t_outlet *search_outlet;
	
	double a, a_lo, a_hi, b, b_lo, b_hi;
	t_atom params_out[M_param_count];
	t_outlet *params_outlet;
	double lyap_exp, lyap_lo, lyap_hi, lyap_limit, failure_ratio;
	
	t_outlet *outlets[M_var_count - 1];
} lozi_struct;

static void calc(lozi_struct *lozi, double *vars) {
	double x_0, y_0;
	x_0 =(vars[M_y]+1)-(lozi -> a*abs(vars[M_x]));
	y_0 =lozi -> b*vars[M_x];
	vars[M_x] = x_0;
	vars[M_y] = y_0;
} // end calc

static void calculate(lozi_struct *lozi) {
	calc(lozi, lozi -> vars);
	outlet_float(lozi -> outlets[M_y - 1], lozi -> vars[M_y]);
	outlet_float(lozi -> x_obj.ob_outlet, lozi -> vars[M_x]);
} // end calculate

static void reset(lozi_struct *lozi, t_symbol *s, int argc, t_atom *argv) {
	if (argc == M_var_count) {
		lozi -> vars[M_x] = (double) atom_getfloatarg(M_x, argc, argv);
		lozi -> vars[M_y] = (double) atom_getfloatarg(M_y, argc, argv);
	} else {
		lozi -> vars[M_x] = lozi -> vars_init[M_x];
		lozi -> vars[M_y] = lozi -> vars_init[M_y];
	} // end if
} // end reset

static double lyapunov_eval(lozi_struct *lozi, int var_count, double *vars, double *test) {
	int i, j;
	double exponent, sum, d2, df, rs;
	double diff[M_var_count];

	exponent = sum = 0.0;
	for(i = 0; i < LY_ITERATIONS; i++) {
		calc(lozi, vars);
		calc(lozi, test);
		d2 = 0.0;
		for(j = 0; j < var_count; j++) {
			diff[j] = test[j] - vars[j];
			d2 += diff[j] * diff[j];
		}
		df = 1000000000000.0 * d2;
		rs = 1.0 / sqrt(df);
		sum += log(df);
		exponent = 0.721347 * sum / i;
		for(j = 0; j < var_count; j++) {
			test[j] = vars[j] + (rs * (test[j] - vars[j]));
		}
	}
	return exponent;
}

static double lyapunov(lozi_struct *lozi, int var_count, double *vars) {
	int i;
	double test[M_var_count];

	test[0] = vars[0] + LY_ABERATION;
	for(i = 1; i < var_count; i++) { test[i] = vars[i]; }

	return lyapunov_eval(lozi, var_count, vars, test);
}

static double *lyapunov_full(lozi_struct *lozi, int var_count, double *vars, double *results) {
	int i, j;
	double initial[M_var_count];
	double test[M_var_count];

	for(i = 0; i < var_count; i++) {
		initial[i] = vars[i];
	}
	for(i = 0; i < var_count; i++) {
		for(j = 0; j < var_count; j++) {
			if (j == i) {
				test[j] = vars[j] + LY_ABERATION;
			} else {
				test[j] = vars[j];
			}
		}
		results[i] = lyapunov_eval(lozi, var_count, vars, test);
		for(j = 0; j < var_count; j++) { vars[j] = initial[j]; }
	}
	return results;
}

static char *classify(lozi_struct *lozi) {
	static char buff[3];
	char *c = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	buff[0] = c[(int) (((lozi -> a - M_a_lo) * (1.0 / (M_a_hi - M_a_lo))) * 26)];
	buff[1] = c[(int) (((lozi -> b - M_b_lo) * (1.0 / (M_b_hi - M_b_lo))) * 26)];
	buff[2] = '\0';
	return buff;
}

static void limits(lozi_struct *lozi) {
	SETFLOAT(&lozi -> search_out[0], lozi -> a_lo);
	SETFLOAT(&lozi -> search_out[1], lozi -> a_hi);
	SETFLOAT(&lozi -> search_out[2], lozi -> b_lo);
	SETFLOAT(&lozi -> search_out[3], lozi -> b_hi);
	SETFLOAT(&lozi -> search_out[4], lozi -> lyap_lo);
	SETFLOAT(&lozi -> search_out[5], lozi -> lyap_hi);
	SETFLOAT(&lozi -> search_out[6], lozi -> lyap_limit);
	outlet_anything(lozi -> search_outlet, gensym("limits"), M_limits_count + LY_COUNT, lozi -> search_out);
}

static void make_results(lozi_struct *lozi) {
	SETFLOAT(&lozi -> search_out[0], lozi -> lyap_exp);
	SETSYMBOL(&lozi -> search_out[1], gensym(classify(lozi)));
	SETFLOAT(&lozi -> search_out[2], lozi -> failure_ratio);
	SETFLOAT(&lozi -> vars_out[M_x], lozi -> vars[M_x]);
	SETFLOAT(&lozi -> vars_out[M_y], lozi -> vars[M_y]);
	SETFLOAT(&lozi -> params_out[M_a], lozi -> a);
	SETFLOAT(&lozi -> params_out[M_b], lozi -> b);
	outlet_list(lozi -> params_outlet, gensym("list"), M_param_count, lozi -> params_out);
	outlet_list(lozi -> vars_outlet, gensym("list"), M_var_count, lozi -> vars_out);
}

static void show(lozi_struct *lozi) {
	double t_x = lozi -> vars[0];
	double t_y = lozi -> vars[1];
	lozi -> lyap_exp = lyapunov(lozi, M_var_count, (double *) lozi -> vars);
	lozi -> vars[0] = t_x;
	lozi -> vars[1] = t_y;
	make_results(lozi);
	outlet_anything(lozi -> search_outlet, gensym("show"), M_search_count, lozi -> search_out);
}

static void param(lozi_struct *lozi, t_symbol *s, int argc, t_atom *argv) {
	if (argc != 2) {
		post("Incorrect number of arguments for lozi fractal. Expecting 2 arguments.");
		return;
	}
	lozi -> a = (double) atom_getfloatarg(0, argc, argv);
	lozi -> b = (double) atom_getfloatarg(1, argc, argv);
}

static void seed(lozi_struct *lozi, t_symbol *s, int argc, t_atom *argv) {
	if (argc > 0) {
		srand48(((unsigned int)time(0))|1);
	} else {
		srand48((unsigned int) atom_getfloatarg(0, argc, argv));
	}
}

static void lyap(lozi_struct *lozi, t_floatarg l, t_floatarg h, t_floatarg lim) {
	lozi -> lyap_lo = l;
	lozi -> lyap_hi = h;
	lozi -> lyap_limit = (double) ((int) lim);
}

static void elyap(lozi_struct *lozi) {
	double results[M_var_count];
	int i;
	if (lyapunov_full(lozi, M_var_count, lozi -> vars, results) != NULL) {
		post("elyapunov:");
		for(i = 0; i < M_var_count; i++) { post("%d: %3.80f", i, results[i]); }
	}
}

static void limiter(lozi_struct *lozi) {
}

static void constrain(lozi_struct *lozi, t_symbol *s, int argc, t_atom *argv) {
	int i;
	t_atom *arg = argv;
	if (argc == 0) {
		// reset to full limits of search ranges
		lozi -> a_lo = M_a_lo;
		lozi -> a_hi = M_a_hi;
		lozi -> b_lo = M_b_lo;
		lozi -> b_hi = M_b_hi;
		return;
	}
	if (argc == 1) {
		// set the ranges based on percentage of full range
		double percent = atom_getfloat(arg);
		double a_spread = ((M_a_hi - M_a_lo) * percent) / 2;
		double b_spread = ((M_b_hi - M_b_lo) * percent) / 2;
		lozi -> a_lo = lozi -> a - a_spread;
		lozi -> a_hi = lozi -> a + a_spread;
		lozi -> b_lo = lozi -> b - b_spread;
		lozi -> b_hi = lozi -> b + b_spread;
		limiter(lozi);
		return;
	}
	if (argc != M_param_count * 2) {
		post("Invalid number of arguments for lozi constraints, requires 4 values, got %d", argc);
		return;
	}
	lozi -> a_lo = atom_getfloat(arg++);
	lozi -> a_hi = atom_getfloat(arg++);
	lozi -> b_lo = atom_getfloat(arg++);
	lozi -> b_hi = atom_getfloat(arg++);
	limiter(lozi);
}

static void search(lozi_struct *lozi, t_symbol *s, int argc, t_atom *argv) {
	int not_found, not_expired = lozi -> lyap_limit;
	int jump, i, iterations;
	t_atom vars[M_var_count];
	double t_a = lozi -> a;
	double t_b = lozi -> b;
	if (argc > 0) {
		for (i = 0; i < M_var_count; i++) {
			SETFLOAT(&vars[i], atom_getfloatarg(i, argc, argv));
		}
	} else {
		for (i = 0; i < M_var_count; i++) {
			SETFLOAT(&vars[i], lozi -> vars_init[i]);
		}
	}
	do {
		jump = 500;
		not_found = 0;
		iterations = 10000;
		bad_params:
		lozi -> a = (drand48() * (lozi -> a_hi - lozi -> a_lo)) + lozi -> a_lo;
		lozi -> b = (drand48() * (lozi -> b_hi - lozi -> b_lo)) + lozi -> b_lo;
		// put any preliminary checks specific to this fractal to eliminate bad_params

		reset(lozi, NULL, argc, vars);
		do { calc(lozi, lozi -> vars); } while(jump--);
		lozi -> lyap_exp = lyapunov(lozi, M_var_count, (double *) lozi -> vars);
		if (isnan(lozi -> lyap_exp)) { not_found = 1; }
		if (lozi -> lyap_exp < lozi -> lyap_lo || lozi -> lyap_exp > lozi -> lyap_hi) { not_found = 1; }
		not_expired--;
	} while(not_found && not_expired);
	reset(lozi, NULL, argc, vars);
	if (!not_expired) {
		post("Could not find a fractal after %d attempts.", (int) lozi -> lyap_limit);
		post("Try using wider constraints.");
		lozi -> a = t_a;
		lozi -> b = t_b;
		outlet_anything(lozi -> search_outlet, gensym("fail"), 0, NULL);
	} else {
		lozi -> failure_ratio = (lozi -> lyap_limit - not_expired) / lozi -> lyap_limit;
		make_results(lozi);
		outlet_anything(lozi -> search_outlet, gensym("search"), M_search_count, lozi -> search_out);
	}
}

void *lozi_new(t_symbol *s, int argc, t_atom *argv) {
	lozi_struct *lozi = (lozi_struct *) pd_new(lozi_class);
	if (lozi != NULL) {
		outlet_new(&lozi -> x_obj, &s_float);
		lozi -> outlets[0] = outlet_new(&lozi -> x_obj, &s_float);
		lozi -> search_outlet = outlet_new(&lozi -> x_obj, &s_list);
		lozi -> vars_outlet = outlet_new(&lozi -> x_obj, &s_list);
		lozi -> params_outlet = outlet_new(&lozi -> x_obj, &s_list);
		if (argc == M_param_count + M_var_count) {
			lozi -> vars_init[M_x] = lozi -> vars[M_x] = (double) atom_getfloatarg(0, argc, argv);
			lozi -> vars_init[M_y] = lozi -> vars[M_y] = (double) atom_getfloatarg(1, argc, argv);
			lozi -> a = (double) atom_getfloatarg(2, argc, argv);
			lozi -> b = (double) atom_getfloatarg(3, argc, argv);
		} else {
			if (argc != 0 && argc != M_param_count + M_var_count) {
				post("Incorrect number of arguments for lozi fractal. Expecting 4 arguments.");
			}
			lozi -> vars_init[M_x] = 1;
			lozi -> vars_init[M_y] = 1;
			lozi -> a = 1.4;
			lozi -> b = 0.3;
		}
		constrain(lozi, NULL, 0, NULL);
		lyap(lozi, -1000000.0, 1000000.0, M_failure_limit);
	}
	return (void *)lozi;
}

void lozi_setup(void) {
	post(version);
	lozi_class = class_new(gensym("lozi"), (t_newmethod) lozi_new, 0, sizeof(lozi_struct), 0, A_GIMME, 0);
	class_addbang(lozi_class, (t_method) calculate);
	class_addmethod(lozi_class, (t_method) reset, gensym("reset"), A_GIMME, 0);
	class_addmethod(lozi_class, (t_method) show, gensym("show"), 0);
	class_addmethod(lozi_class, (t_method) limits, gensym("limits"), 0);
	class_addmethod(lozi_class, (t_method) param, gensym("param"), A_GIMME, 0);
	class_addmethod(lozi_class, (t_method) seed, gensym("seed"), A_GIMME, 0);
	class_addmethod(lozi_class, (t_method) lyap, gensym("lyapunov"), A_DEFFLOAT, A_DEFFLOAT, A_DEFFLOAT, 0);
	class_addmethod(lozi_class, (t_method) elyap, gensym("elyapunov"), 0);
	class_addmethod(lozi_class, (t_method) search, gensym("search"), A_GIMME, 0);
	class_addmethod(lozi_class, (t_method) constrain, gensym("constrain"), A_GIMME, 0);
	class_sethelpsymbol(lozi_class, gensym("lozi-help.pd"));
}

