/* lotka_volterra Attractor PD External */
/* Copyright Michael McGonagle, 2003 */
/* This program is distributed under the params of the GNU Public License */

///////////////////////////////////////////////////////////////////////////////////
/* This file is part of Chaos PD Externals.                                      */
/*                                                                               */
/* Chaos PD Externals are free software; you can redistribute them and/or modify */
/* them under the terms of the GNU General Public License as published by        */
/* the Free Software Foundation; either version 2 of the License, or             */
/* (at your option) any later version.                                           */
/*                                                                               */
/* Chaos PD Externals are distributed in the hope that they will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of                */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                 */
/* GNU General Public License for more details.                                  */
/*                                                                               */
/* You should have received a copy of the GNU General Public License             */
/* along with the Chaos PD Externals; if not, write to the Free Software         */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA     */
///////////////////////////////////////////////////////////////////////////////////

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include "m_pd.h"

#define M_a_lo -1000
#define M_a_hi 1000
#define M_b_lo -1000
#define M_b_hi 1000
#define M_c_lo -1000
#define M_c_hi 1000
#define M_e_lo -1000
#define M_e_hi 1000

#define M_a 0
#define M_b 1
#define M_c 2
#define M_e 3

#define M_r 0
#define M_f 1

#define LY_ITERATIONS 50000
#define LY_ABERATION 10e-15
#define LY_COUNT 3

#define M_param_count 4
#define M_var_count 2
#define M_search_count 3
#define M_limits_count 8
#define M_failure_limit 1000

static char *version = "lotka_volterra v0.05, by Michael McGonagle, 2003";

t_class *lotka_volterra_class;

typedef struct lotka_volterra_struct {
	t_object x_obj;

	double vars[M_var_count];
	double vars_init[M_var_count];
	t_atom vars_out[M_var_count];
	t_outlet *vars_outlet;
	
	t_atom search_out[(M_search_count > M_limits_count) ? M_search_count + LY_COUNT : M_limits_count + LY_COUNT];
	t_outlet *search_outlet;
	
	double a, a_lo, a_hi, b, b_lo, b_hi, c, c_lo, c_hi, e, e_lo, e_hi;
	t_atom params_out[M_param_count];
	t_outlet *params_outlet;
	double lyap_exp, lyap_lo, lyap_hi, lyap_limit, failure_ratio;
	
	t_outlet *outlets[M_var_count - 1];
} lotka_volterra_struct;

static void calc(lotka_volterra_struct *lotka_volterra, double *vars) {
	double r_0, f_0;
	r_0 =vars[M_r]+lotka_volterra -> a*vars[M_r]-lotka_volterra -> b*vars[M_r]*vars[M_f];
	f_0 =vars[M_f]+lotka_volterra -> e*lotka_volterra -> b*vars[M_r]*vars[M_f]-lotka_volterra -> c*vars[M_f];
	vars[M_r] = r_0;
	vars[M_f] = f_0;
} // end calc

static void calculate(lotka_volterra_struct *lotka_volterra) {
	calc(lotka_volterra, lotka_volterra -> vars);
	outlet_float(lotka_volterra -> outlets[M_f - 1], lotka_volterra -> vars[M_f]);
	outlet_float(lotka_volterra -> x_obj.ob_outlet, lotka_volterra -> vars[M_r]);
} // end calculate

static void reset(lotka_volterra_struct *lotka_volterra, t_symbol *s, int argc, t_atom *argv) {
	if (argc == M_var_count) {
		lotka_volterra -> vars[M_r] = (double) atom_getfloatarg(M_r, argc, argv);
		lotka_volterra -> vars[M_f] = (double) atom_getfloatarg(M_f, argc, argv);
	} else {
		lotka_volterra -> vars[M_r] = lotka_volterra -> vars_init[M_r];
		lotka_volterra -> vars[M_f] = lotka_volterra -> vars_init[M_f];
	} // end if
} // end reset

static double lyapunov_eval(lotka_volterra_struct *lotka_volterra, int var_count, double *vars, double *test) {
	int i, j;
	double exponent, sum, d2, df, rs;
	double diff[M_var_count];

	exponent = sum = 0.0;
	for(i = 0; i < LY_ITERATIONS; i++) {
		calc(lotka_volterra, vars);
		calc(lotka_volterra, test);
		d2 = 0.0;
		for(j = 0; j < var_count; j++) {
			diff[j] = test[j] - vars[j];
			d2 += diff[j] * diff[j];
		}
		df = 1000000000000.0 * d2;
		rs = 1.0 / sqrt(df);
		sum += log(df);
		exponent = 0.721347 * sum / i;
		for(j = 0; j < var_count; j++) {
			test[j] = vars[j] + (rs * (test[j] - vars[j]));
		}
	}
	return exponent;
}

static double lyapunov(lotka_volterra_struct *lotka_volterra, int var_count, double *vars) {
	int i;
	double test[M_var_count];

	test[0] = vars[0] + LY_ABERATION;
	for(i = 1; i < var_count; i++) { test[i] = vars[i]; }

	return lyapunov_eval(lotka_volterra, var_count, vars, test);
}

static double *lyapunov_full(lotka_volterra_struct *lotka_volterra, int var_count, double *vars, double *results) {
	int i, j;
	double initial[M_var_count];
	double test[M_var_count];

	for(i = 0; i < var_count; i++) {
		initial[i] = vars[i];
	}
	for(i = 0; i < var_count; i++) {
		for(j = 0; j < var_count; j++) {
			if (j == i) {
				test[j] = vars[j] + LY_ABERATION;
			} else {
				test[j] = vars[j];
			}
		}
		results[i] = lyapunov_eval(lotka_volterra, var_count, vars, test);
		for(j = 0; j < var_count; j++) { vars[j] = initial[j]; }
	}
	return results;
}

static char *classify(lotka_volterra_struct *lotka_volterra) {
	static char buff[5];
	char *c = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	buff[0] = c[(int) (((lotka_volterra -> a - M_a_lo) * (1.0 / (M_a_hi - M_a_lo))) * 26)];
	buff[1] = c[(int) (((lotka_volterra -> b - M_b_lo) * (1.0 / (M_b_hi - M_b_lo))) * 26)];
	buff[2] = c[(int) (((lotka_volterra -> c - M_c_lo) * (1.0 / (M_c_hi - M_c_lo))) * 26)];
	buff[3] = c[(int) (((lotka_volterra -> e - M_e_lo) * (1.0 / (M_e_hi - M_e_lo))) * 26)];
	buff[4] = '\0';
	return buff;
}

static void limits(lotka_volterra_struct *lotka_volterra) {
	SETFLOAT(&lotka_volterra -> search_out[0], lotka_volterra -> a_lo);
	SETFLOAT(&lotka_volterra -> search_out[1], lotka_volterra -> a_hi);
	SETFLOAT(&lotka_volterra -> search_out[2], lotka_volterra -> b_lo);
	SETFLOAT(&lotka_volterra -> search_out[3], lotka_volterra -> b_hi);
	SETFLOAT(&lotka_volterra -> search_out[4], lotka_volterra -> c_lo);
	SETFLOAT(&lotka_volterra -> search_out[5], lotka_volterra -> c_hi);
	SETFLOAT(&lotka_volterra -> search_out[6], lotka_volterra -> e_lo);
	SETFLOAT(&lotka_volterra -> search_out[7], lotka_volterra -> e_hi);
	SETFLOAT(&lotka_volterra -> search_out[8], lotka_volterra -> lyap_lo);
	SETFLOAT(&lotka_volterra -> search_out[9], lotka_volterra -> lyap_hi);
	SETFLOAT(&lotka_volterra -> search_out[10], lotka_volterra -> lyap_limit);
	outlet_anything(lotka_volterra -> search_outlet, gensym("limits"), M_limits_count + LY_COUNT, lotka_volterra -> search_out);
}

static void make_results(lotka_volterra_struct *lotka_volterra) {
	SETFLOAT(&lotka_volterra -> search_out[0], lotka_volterra -> lyap_exp);
	SETSYMBOL(&lotka_volterra -> search_out[1], gensym(classify(lotka_volterra)));
	SETFLOAT(&lotka_volterra -> search_out[2], lotka_volterra -> failure_ratio);
	SETFLOAT(&lotka_volterra -> vars_out[M_r], lotka_volterra -> vars[M_r]);
	SETFLOAT(&lotka_volterra -> vars_out[M_f], lotka_volterra -> vars[M_f]);
	SETFLOAT(&lotka_volterra -> params_out[M_a], lotka_volterra -> a);
	SETFLOAT(&lotka_volterra -> params_out[M_b], lotka_volterra -> b);
	SETFLOAT(&lotka_volterra -> params_out[M_c], lotka_volterra -> c);
	SETFLOAT(&lotka_volterra -> params_out[M_e], lotka_volterra -> e);
	outlet_list(lotka_volterra -> params_outlet, gensym("list"), M_param_count, lotka_volterra -> params_out);
	outlet_list(lotka_volterra -> vars_outlet, gensym("list"), M_var_count, lotka_volterra -> vars_out);
}

static void show(lotka_volterra_struct *lotka_volterra) {
	double t_r = lotka_volterra -> vars[0];
	double t_f = lotka_volterra -> vars[1];
	lotka_volterra -> lyap_exp = lyapunov(lotka_volterra, M_var_count, (double *) lotka_volterra -> vars);
	lotka_volterra -> vars[0] = t_r;
	lotka_volterra -> vars[1] = t_f;
	make_results(lotka_volterra);
	outlet_anything(lotka_volterra -> search_outlet, gensym("show"), M_search_count, lotka_volterra -> search_out);
}

static void param(lotka_volterra_struct *lotka_volterra, t_symbol *s, int argc, t_atom *argv) {
	if (argc != 4) {
		post("Incorrect number of arguments for lotka_volterra fractal. Expecting 4 arguments.");
		return;
	}
	lotka_volterra -> a = (double) atom_getfloatarg(0, argc, argv);
	lotka_volterra -> b = (double) atom_getfloatarg(1, argc, argv);
	lotka_volterra -> c = (double) atom_getfloatarg(2, argc, argv);
	lotka_volterra -> e = (double) atom_getfloatarg(3, argc, argv);
}

static void seed(lotka_volterra_struct *lotka_volterra, t_symbol *s, int argc, t_atom *argv) {
	if (argc > 0) {
		srand48(((unsigned int)time(0))|1);
	} else {
		srand48((unsigned int) atom_getfloatarg(0, argc, argv));
	}
}

static void lyap(lotka_volterra_struct *lotka_volterra, t_floatarg l, t_floatarg h, t_floatarg lim) {
	lotka_volterra -> lyap_lo = l;
	lotka_volterra -> lyap_hi = h;
	lotka_volterra -> lyap_limit = (double) ((int) lim);
}

static void elyap(lotka_volterra_struct *lotka_volterra) {
	double results[M_var_count];
	int i;
	if (lyapunov_full(lotka_volterra, M_var_count, lotka_volterra -> vars, results) != NULL) {
		post("elyapunov:");
		for(i = 0; i < M_var_count; i++) { post("%d: %3.80f", i, results[i]); }
	}
}

static void limiter(lotka_volterra_struct *lotka_volterra) {
}

static void constrain(lotka_volterra_struct *lotka_volterra, t_symbol *s, int argc, t_atom *argv) {
	int i;
	t_atom *arg = argv;
	if (argc == 0) {
		// reset to full limits of search ranges
		lotka_volterra -> a_lo = M_a_lo;
		lotka_volterra -> a_hi = M_a_hi;
		lotka_volterra -> b_lo = M_b_lo;
		lotka_volterra -> b_hi = M_b_hi;
		lotka_volterra -> c_lo = M_c_lo;
		lotka_volterra -> c_hi = M_c_hi;
		lotka_volterra -> e_lo = M_e_lo;
		lotka_volterra -> e_hi = M_e_hi;
		return;
	}
	if (argc == 1) {
		// set the ranges based on percentage of full range
		double percent = atom_getfloat(arg);
		double a_spread = ((M_a_hi - M_a_lo) * percent) / 2;
		double b_spread = ((M_b_hi - M_b_lo) * percent) / 2;
		double c_spread = ((M_c_hi - M_c_lo) * percent) / 2;
		double e_spread = ((M_e_hi - M_e_lo) * percent) / 2;
		lotka_volterra -> a_lo = lotka_volterra -> a - a_spread;
		lotka_volterra -> a_hi = lotka_volterra -> a + a_spread;
		lotka_volterra -> b_lo = lotka_volterra -> b - b_spread;
		lotka_volterra -> b_hi = lotka_volterra -> b + b_spread;
		lotka_volterra -> c_lo = lotka_volterra -> c - c_spread;
		lotka_volterra -> c_hi = lotka_volterra -> c + c_spread;
		lotka_volterra -> e_lo = lotka_volterra -> e - e_spread;
		lotka_volterra -> e_hi = lotka_volterra -> e + e_spread;
		limiter(lotka_volterra);
		return;
	}
	if (argc != M_param_count * 2) {
		post("Invalid number of arguments for lotka_volterra constraints, requires 8 values, got %d", argc);
		return;
	}
	lotka_volterra -> a_lo = atom_getfloat(arg++);
	lotka_volterra -> a_hi = atom_getfloat(arg++);
	lotka_volterra -> b_lo = atom_getfloat(arg++);
	lotka_volterra -> b_hi = atom_getfloat(arg++);
	lotka_volterra -> c_lo = atom_getfloat(arg++);
	lotka_volterra -> c_hi = atom_getfloat(arg++);
	lotka_volterra -> e_lo = atom_getfloat(arg++);
	lotka_volterra -> e_hi = atom_getfloat(arg++);
	limiter(lotka_volterra);
}

static void search(lotka_volterra_struct *lotka_volterra, t_symbol *s, int argc, t_atom *argv) {
	int not_found, not_expired = lotka_volterra -> lyap_limit;
	int jump, i, iterations;
	t_atom vars[M_var_count];
	double t_a = lotka_volterra -> a;
	double t_b = lotka_volterra -> b;
	double t_c = lotka_volterra -> c;
	double t_e = lotka_volterra -> e;
	if (argc > 0) {
		for (i = 0; i < M_var_count; i++) {
			SETFLOAT(&vars[i], atom_getfloatarg(i, argc, argv));
		}
	} else {
		for (i = 0; i < M_var_count; i++) {
			SETFLOAT(&vars[i], lotka_volterra -> vars_init[i]);
		}
	}
	do {
		jump = 500;
		not_found = 0;
		iterations = 10000;
		bad_params:
		lotka_volterra -> a = (drand48() * (lotka_volterra -> a_hi - lotka_volterra -> a_lo)) + lotka_volterra -> a_lo;
		lotka_volterra -> b = (drand48() * (lotka_volterra -> b_hi - lotka_volterra -> b_lo)) + lotka_volterra -> b_lo;
		lotka_volterra -> c = (drand48() * (lotka_volterra -> c_hi - lotka_volterra -> c_lo)) + lotka_volterra -> c_lo;
		lotka_volterra -> e = (drand48() * (lotka_volterra -> e_hi - lotka_volterra -> e_lo)) + lotka_volterra -> e_lo;
		// put any preliminary checks specific to this fractal to eliminate bad_params

		reset(lotka_volterra, NULL, argc, vars);
		do { calc(lotka_volterra, lotka_volterra -> vars); } while(jump--);
		lotka_volterra -> lyap_exp = lyapunov(lotka_volterra, M_var_count, (double *) lotka_volterra -> vars);
		if (isnan(lotka_volterra -> lyap_exp)) { not_found = 1; }
		if (lotka_volterra -> lyap_exp < lotka_volterra -> lyap_lo || lotka_volterra -> lyap_exp > lotka_volterra -> lyap_hi) { not_found = 1; }
		not_expired--;
	} while(not_found && not_expired);
	reset(lotka_volterra, NULL, argc, vars);
	if (!not_expired) {
		post("Could not find a fractal after %d attempts.", (int) lotka_volterra -> lyap_limit);
		post("Try using wider constraints.");
		lotka_volterra -> a = t_a;
		lotka_volterra -> b = t_b;
		lotka_volterra -> c = t_c;
		lotka_volterra -> e = t_e;
		outlet_anything(lotka_volterra -> search_outlet, gensym("fail"), 0, NULL);
	} else {
		lotka_volterra -> failure_ratio = (lotka_volterra -> lyap_limit - not_expired) / lotka_volterra -> lyap_limit;
		make_results(lotka_volterra);
		outlet_anything(lotka_volterra -> search_outlet, gensym("search"), M_search_count, lotka_volterra -> search_out);
	}
}

void *lotka_volterra_new(t_symbol *s, int argc, t_atom *argv) {
	lotka_volterra_struct *lotka_volterra = (lotka_volterra_struct *) pd_new(lotka_volterra_class);
	if (lotka_volterra != NULL) {
		outlet_new(&lotka_volterra -> x_obj, &s_float);
		lotka_volterra -> outlets[0] = outlet_new(&lotka_volterra -> x_obj, &s_float);
		lotka_volterra -> search_outlet = outlet_new(&lotka_volterra -> x_obj, &s_list);
		lotka_volterra -> vars_outlet = outlet_new(&lotka_volterra -> x_obj, &s_list);
		lotka_volterra -> params_outlet = outlet_new(&lotka_volterra -> x_obj, &s_list);
		if (argc == M_param_count + M_var_count) {
			lotka_volterra -> vars_init[M_r] = lotka_volterra -> vars[M_r] = (double) atom_getfloatarg(0, argc, argv);
			lotka_volterra -> vars_init[M_f] = lotka_volterra -> vars[M_f] = (double) atom_getfloatarg(1, argc, argv);
			lotka_volterra -> a = (double) atom_getfloatarg(2, argc, argv);
			lotka_volterra -> b = (double) atom_getfloatarg(3, argc, argv);
			lotka_volterra -> c = (double) atom_getfloatarg(4, argc, argv);
			lotka_volterra -> e = (double) atom_getfloatarg(5, argc, argv);
		} else {
			if (argc != 0 && argc != M_param_count + M_var_count) {
				post("Incorrect number of arguments for lotka_volterra fractal. Expecting 6 arguments.");
			}
			lotka_volterra -> vars_init[M_r] = 0.1;
			lotka_volterra -> vars_init[M_f] = 0.1;
			lotka_volterra -> a = 0.04;
			lotka_volterra -> b = 0.0005;
			lotka_volterra -> c = 0.2;
			lotka_volterra -> e = 0.1;
		}
		constrain(lotka_volterra, NULL, 0, NULL);
		lyap(lotka_volterra, -1000000.0, 1000000.0, M_failure_limit);
	}
	return (void *)lotka_volterra;
}

void lotka_volterra_setup(void) {
	post(version);
	lotka_volterra_class = class_new(gensym("lotka_volterra"), (t_newmethod) lotka_volterra_new, 0, sizeof(lotka_volterra_struct), 0, A_GIMME, 0);
	class_addbang(lotka_volterra_class, (t_method) calculate);
	class_addmethod(lotka_volterra_class, (t_method) reset, gensym("reset"), A_GIMME, 0);
	class_addmethod(lotka_volterra_class, (t_method) show, gensym("show"), 0);
	class_addmethod(lotka_volterra_class, (t_method) limits, gensym("limits"), 0);
	class_addmethod(lotka_volterra_class, (t_method) param, gensym("param"), A_GIMME, 0);
	class_addmethod(lotka_volterra_class, (t_method) seed, gensym("seed"), A_GIMME, 0);
	class_addmethod(lotka_volterra_class, (t_method) lyap, gensym("lyapunov"), A_DEFFLOAT, A_DEFFLOAT, A_DEFFLOAT, 0);
	class_addmethod(lotka_volterra_class, (t_method) elyap, gensym("elyapunov"), 0);
	class_addmethod(lotka_volterra_class, (t_method) search, gensym("search"), A_GIMME, 0);
	class_addmethod(lotka_volterra_class, (t_method) constrain, gensym("constrain"), A_GIMME, 0);
	class_sethelpsymbol(lotka_volterra_class, gensym("lotka_volterra-help.pd"));
}

