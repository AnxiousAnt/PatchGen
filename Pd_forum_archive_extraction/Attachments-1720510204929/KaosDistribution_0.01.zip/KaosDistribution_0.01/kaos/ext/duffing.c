/* duffing Attractor PD External */
/* Copyright taken from Viktor Avrutin: AnT-Demos-4.669, 2006 */
/* This program is distributed under the params of the GNU Public License */

///////////////////////////////////////////////////////////////////////////////////
/* This file is part of Chaos PD Externals.                                      */
/*                                                                               */
/* Chaos PD Externals are free software; you can redistribute them and/or modify */
/* them under the terms of the GNU General Public License as published by        */
/* the Free Software Foundation; either version 2 of the License, or             */
/* (at your option) any later version.                                           */
/*                                                                               */
/* Chaos PD Externals are distributed in the hope that they will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of                */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                 */
/* GNU General Public License for more details.                                  */
/*                                                                               */
/* You should have received a copy of the GNU General Public License             */
/* along with the Chaos PD Externals; if not, write to the Free Software         */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA     */
///////////////////////////////////////////////////////////////////////////////////

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include "m_pd.h"

#define M_a_lo -1000
#define M_a_hi 1000
#define M_b_lo -1000
#define M_b_hi 1000

#define M_a 0
#define M_b 1

#define M_x 0
#define M_y 1

#define LY_ITERATIONS 50000
#define LY_ABERATION 10e-15
#define LY_COUNT 3

#define M_param_count 2
#define M_var_count 2
#define M_search_count 3
#define M_limits_count 4
#define M_failure_limit 1000

static char *version = "duffing v0.05, by taken from Viktor Avrutin: AnT-Demos-4.669, 2006";

t_class *duffing_class;

typedef struct duffing_struct {
	t_object x_obj;

	double vars[M_var_count];
	double vars_init[M_var_count];
	t_atom vars_out[M_var_count];
	t_outlet *vars_outlet;
	
	t_atom search_out[(M_search_count > M_limits_count) ? M_search_count + LY_COUNT : M_limits_count + LY_COUNT];
	t_outlet *search_outlet;
	
	double a, a_lo, a_hi, b, b_lo, b_hi;
	t_atom params_out[M_param_count];
	t_outlet *params_outlet;
	double lyap_exp, lyap_lo, lyap_hi, lyap_limit, failure_ratio;
	
	t_outlet *outlets[M_var_count - 1];
} duffing_struct;

static void calc(duffing_struct *duffing, double *vars) {
	double x_0, y_0;
	x_0 =vars[M_y];
	y_0 =-duffing -> b*vars[M_x]+duffing -> a*vars[M_y]-pow(vars[M_y],3);
	vars[M_x] = x_0;
	vars[M_y] = y_0;
} // end calc

static void calculate(duffing_struct *duffing) {
	calc(duffing, duffing -> vars);
	outlet_float(duffing -> outlets[M_y - 1], duffing -> vars[M_y]);
	outlet_float(duffing -> x_obj.ob_outlet, duffing -> vars[M_x]);
} // end calculate

static void reset(duffing_struct *duffing, t_symbol *s, int argc, t_atom *argv) {
	if (argc == M_var_count) {
		duffing -> vars[M_x] = (double) atom_getfloatarg(M_x, argc, argv);
		duffing -> vars[M_y] = (double) atom_getfloatarg(M_y, argc, argv);
	} else {
		duffing -> vars[M_x] = duffing -> vars_init[M_x];
		duffing -> vars[M_y] = duffing -> vars_init[M_y];
	} // end if
} // end reset

static double lyapunov_eval(duffing_struct *duffing, int var_count, double *vars, double *test) {
	int i, j;
	double exponent, sum, d2, df, rs;
	double diff[M_var_count];

	exponent = sum = 0.0;
	for(i = 0; i < LY_ITERATIONS; i++) {
		calc(duffing, vars);
		calc(duffing, test);
		d2 = 0.0;
		for(j = 0; j < var_count; j++) {
			diff[j] = test[j] - vars[j];
			d2 += diff[j] * diff[j];
		}
		df = 1000000000000.0 * d2;
		rs = 1.0 / sqrt(df);
		sum += log(df);
		exponent = 0.721347 * sum / i;
		for(j = 0; j < var_count; j++) {
			test[j] = vars[j] + (rs * (test[j] - vars[j]));
		}
	}
	return exponent;
}

static double lyapunov(duffing_struct *duffing, int var_count, double *vars) {
	int i;
	double test[M_var_count];

	test[0] = vars[0] + LY_ABERATION;
	for(i = 1; i < var_count; i++) { test[i] = vars[i]; }

	return lyapunov_eval(duffing, var_count, vars, test);
}

static double *lyapunov_full(duffing_struct *duffing, int var_count, double *vars, double *results) {
	int i, j;
	double initial[M_var_count];
	double test[M_var_count];

	for(i = 0; i < var_count; i++) {
		initial[i] = vars[i];
	}
	for(i = 0; i < var_count; i++) {
		for(j = 0; j < var_count; j++) {
			if (j == i) {
				test[j] = vars[j] + LY_ABERATION;
			} else {
				test[j] = vars[j];
			}
		}
		results[i] = lyapunov_eval(duffing, var_count, vars, test);
		for(j = 0; j < var_count; j++) { vars[j] = initial[j]; }
	}
	return results;
}

static char *classify(duffing_struct *duffing) {
	static char buff[3];
	char *c = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	buff[0] = c[(int) (((duffing -> a - M_a_lo) * (1.0 / (M_a_hi - M_a_lo))) * 26)];
	buff[1] = c[(int) (((duffing -> b - M_b_lo) * (1.0 / (M_b_hi - M_b_lo))) * 26)];
	buff[2] = '\0';
	return buff;
}

static void limits(duffing_struct *duffing) {
	SETFLOAT(&duffing -> search_out[0], duffing -> a_lo);
	SETFLOAT(&duffing -> search_out[1], duffing -> a_hi);
	SETFLOAT(&duffing -> search_out[2], duffing -> b_lo);
	SETFLOAT(&duffing -> search_out[3], duffing -> b_hi);
	SETFLOAT(&duffing -> search_out[4], duffing -> lyap_lo);
	SETFLOAT(&duffing -> search_out[5], duffing -> lyap_hi);
	SETFLOAT(&duffing -> search_out[6], duffing -> lyap_limit);
	outlet_anything(duffing -> search_outlet, gensym("limits"), M_limits_count + LY_COUNT, duffing -> search_out);
}

static void make_results(duffing_struct *duffing) {
	SETFLOAT(&duffing -> search_out[0], duffing -> lyap_exp);
	SETSYMBOL(&duffing -> search_out[1], gensym(classify(duffing)));
	SETFLOAT(&duffing -> search_out[2], duffing -> failure_ratio);
	SETFLOAT(&duffing -> vars_out[M_x], duffing -> vars[M_x]);
	SETFLOAT(&duffing -> vars_out[M_y], duffing -> vars[M_y]);
	SETFLOAT(&duffing -> params_out[M_a], duffing -> a);
	SETFLOAT(&duffing -> params_out[M_b], duffing -> b);
	outlet_list(duffing -> params_outlet, gensym("list"), M_param_count, duffing -> params_out);
	outlet_list(duffing -> vars_outlet, gensym("list"), M_var_count, duffing -> vars_out);
}

static void show(duffing_struct *duffing) {
	double t_x = duffing -> vars[0];
	double t_y = duffing -> vars[1];
	duffing -> lyap_exp = lyapunov(duffing, M_var_count, (double *) duffing -> vars);
	duffing -> vars[0] = t_x;
	duffing -> vars[1] = t_y;
	make_results(duffing);
	outlet_anything(duffing -> search_outlet, gensym("show"), M_search_count, duffing -> search_out);
}

static void param(duffing_struct *duffing, t_symbol *s, int argc, t_atom *argv) {
	if (argc != 2) {
		post("Incorrect number of arguments for duffing fractal. Expecting 2 arguments.");
		return;
	}
	duffing -> a = (double) atom_getfloatarg(0, argc, argv);
	duffing -> b = (double) atom_getfloatarg(1, argc, argv);
}

static void seed(duffing_struct *duffing, t_symbol *s, int argc, t_atom *argv) {
	if (argc > 0) {
		srand48(((unsigned int)time(0))|1);
	} else {
		srand48((unsigned int) atom_getfloatarg(0, argc, argv));
	}
}

static void lyap(duffing_struct *duffing, t_floatarg l, t_floatarg h, t_floatarg lim) {
	duffing -> lyap_lo = l;
	duffing -> lyap_hi = h;
	duffing -> lyap_limit = (double) ((int) lim);
}

static void elyap(duffing_struct *duffing) {
	double results[M_var_count];
	int i;
	if (lyapunov_full(duffing, M_var_count, duffing -> vars, results) != NULL) {
		post("elyapunov:");
		for(i = 0; i < M_var_count; i++) { post("%d: %3.80f", i, results[i]); }
	}
}

static void limiter(duffing_struct *duffing) {
}

static void constrain(duffing_struct *duffing, t_symbol *s, int argc, t_atom *argv) {
	int i;
	t_atom *arg = argv;
	if (argc == 0) {
		// reset to full limits of search ranges
		duffing -> a_lo = M_a_lo;
		duffing -> a_hi = M_a_hi;
		duffing -> b_lo = M_b_lo;
		duffing -> b_hi = M_b_hi;
		return;
	}
	if (argc == 1) {
		// set the ranges based on percentage of full range
		double percent = atom_getfloat(arg);
		double a_spread = ((M_a_hi - M_a_lo) * percent) / 2;
		double b_spread = ((M_b_hi - M_b_lo) * percent) / 2;
		duffing -> a_lo = duffing -> a - a_spread;
		duffing -> a_hi = duffing -> a + a_spread;
		duffing -> b_lo = duffing -> b - b_spread;
		duffing -> b_hi = duffing -> b + b_spread;
		limiter(duffing);
		return;
	}
	if (argc != M_param_count * 2) {
		post("Invalid number of arguments for duffing constraints, requires 4 values, got %d", argc);
		return;
	}
	duffing -> a_lo = atom_getfloat(arg++);
	duffing -> a_hi = atom_getfloat(arg++);
	duffing -> b_lo = atom_getfloat(arg++);
	duffing -> b_hi = atom_getfloat(arg++);
	limiter(duffing);
}

static void search(duffing_struct *duffing, t_symbol *s, int argc, t_atom *argv) {
	int not_found, not_expired = duffing -> lyap_limit;
	int jump, i, iterations;
	t_atom vars[M_var_count];
	double t_a = duffing -> a;
	double t_b = duffing -> b;
	if (argc > 0) {
		for (i = 0; i < M_var_count; i++) {
			SETFLOAT(&vars[i], atom_getfloatarg(i, argc, argv));
		}
	} else {
		for (i = 0; i < M_var_count; i++) {
			SETFLOAT(&vars[i], duffing -> vars_init[i]);
		}
	}
	do {
		jump = 500;
		not_found = 0;
		iterations = 10000;
		bad_params:
		duffing -> a = (drand48() * (duffing -> a_hi - duffing -> a_lo)) + duffing -> a_lo;
		duffing -> b = (drand48() * (duffing -> b_hi - duffing -> b_lo)) + duffing -> b_lo;
		// put any preliminary checks specific to this fractal to eliminate bad_params

		reset(duffing, NULL, argc, vars);
		do { calc(duffing, duffing -> vars); } while(jump--);
		duffing -> lyap_exp = lyapunov(duffing, M_var_count, (double *) duffing -> vars);
		if (isnan(duffing -> lyap_exp)) { not_found = 1; }
		if (duffing -> lyap_exp < duffing -> lyap_lo || duffing -> lyap_exp > duffing -> lyap_hi) { not_found = 1; }
		not_expired--;
	} while(not_found && not_expired);
	reset(duffing, NULL, argc, vars);
	if (!not_expired) {
		post("Could not find a fractal after %d attempts.", (int) duffing -> lyap_limit);
		post("Try using wider constraints.");
		duffing -> a = t_a;
		duffing -> b = t_b;
		outlet_anything(duffing -> search_outlet, gensym("fail"), 0, NULL);
	} else {
		duffing -> failure_ratio = (duffing -> lyap_limit - not_expired) / duffing -> lyap_limit;
		make_results(duffing);
		outlet_anything(duffing -> search_outlet, gensym("search"), M_search_count, duffing -> search_out);
	}
}

void *duffing_new(t_symbol *s, int argc, t_atom *argv) {
	duffing_struct *duffing = (duffing_struct *) pd_new(duffing_class);
	if (duffing != NULL) {
		outlet_new(&duffing -> x_obj, &s_float);
		duffing -> outlets[0] = outlet_new(&duffing -> x_obj, &s_float);
		duffing -> search_outlet = outlet_new(&duffing -> x_obj, &s_list);
		duffing -> vars_outlet = outlet_new(&duffing -> x_obj, &s_list);
		duffing -> params_outlet = outlet_new(&duffing -> x_obj, &s_list);
		if (argc == M_param_count + M_var_count) {
			duffing -> vars_init[M_x] = duffing -> vars[M_x] = (double) atom_getfloatarg(0, argc, argv);
			duffing -> vars_init[M_y] = duffing -> vars[M_y] = (double) atom_getfloatarg(1, argc, argv);
			duffing -> a = (double) atom_getfloatarg(2, argc, argv);
			duffing -> b = (double) atom_getfloatarg(3, argc, argv);
		} else {
			if (argc != 0 && argc != M_param_count + M_var_count) {
				post("Incorrect number of arguments for duffing fractal. Expecting 4 arguments.");
			}
			duffing -> vars_init[M_x] = 0.5;
			duffing -> vars_init[M_y] = 0.5;
			duffing -> a = 0.5;
			duffing -> b = 0.5;
		}
		constrain(duffing, NULL, 0, NULL);
		lyap(duffing, -1000000.0, 1000000.0, M_failure_limit);
	}
	return (void *)duffing;
}

void duffing_setup(void) {
	post(version);
	duffing_class = class_new(gensym("duffing"), (t_newmethod) duffing_new, 0, sizeof(duffing_struct), 0, A_GIMME, 0);
	class_addbang(duffing_class, (t_method) calculate);
	class_addmethod(duffing_class, (t_method) reset, gensym("reset"), A_GIMME, 0);
	class_addmethod(duffing_class, (t_method) show, gensym("show"), 0);
	class_addmethod(duffing_class, (t_method) limits, gensym("limits"), 0);
	class_addmethod(duffing_class, (t_method) param, gensym("param"), A_GIMME, 0);
	class_addmethod(duffing_class, (t_method) seed, gensym("seed"), A_GIMME, 0);
	class_addmethod(duffing_class, (t_method) lyap, gensym("lyapunov"), A_DEFFLOAT, A_DEFFLOAT, A_DEFFLOAT, 0);
	class_addmethod(duffing_class, (t_method) elyap, gensym("elyapunov"), 0);
	class_addmethod(duffing_class, (t_method) search, gensym("search"), A_GIMME, 0);
	class_addmethod(duffing_class, (t_method) constrain, gensym("constrain"), A_GIMME, 0);
	class_sethelpsymbol(duffing_class, gensym("duffing-help.pd"));
}

