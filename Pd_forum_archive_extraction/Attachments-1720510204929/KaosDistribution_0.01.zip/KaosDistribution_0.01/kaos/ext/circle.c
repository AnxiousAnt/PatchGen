/* circle Attractor PD External */
/* Copyright taken from Viktor Avrutin: AnT-Demos-4.669, 2006 */
/* This program is distributed under the params of the GNU Public License */

///////////////////////////////////////////////////////////////////////////////////
/* This file is part of Chaos PD Externals.                                      */
/*                                                                               */
/* Chaos PD Externals are free software; you can redistribute them and/or modify */
/* them under the terms of the GNU General Public License as published by        */
/* the Free Software Foundation; either version 2 of the License, or             */
/* (at your option) any later version.                                           */
/*                                                                               */
/* Chaos PD Externals are distributed in the hope that they will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of                */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                 */
/* GNU General Public License for more details.                                  */
/*                                                                               */
/* You should have received a copy of the GNU General Public License             */
/* along with the Chaos PD Externals; if not, write to the Free Software         */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA     */
///////////////////////////////////////////////////////////////////////////////////

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include "m_pd.h"

#define M_o_lo -1000
#define M_o_hi 1000
#define M_r_lo -1000
#define M_r_hi 1000

#define M_o 0
#define M_r 1

#define M_x 0

#define LY_ITERATIONS 50000
#define LY_ABERATION 10e-15
#define LY_COUNT 3

#define M_param_count 2
#define M_var_count 1
#define M_search_count 3
#define M_limits_count 4
#define M_failure_limit 1000

static char *version = "circle v0.05, by taken from Viktor Avrutin: AnT-Demos-4.669, 2006";

t_class *circle_class;

typedef struct circle_struct {
	t_object x_obj;

	double vars[M_var_count];
	double vars_init[M_var_count];
	t_atom vars_out[M_var_count];
	t_outlet *vars_outlet;
	
	t_atom search_out[(M_search_count > M_limits_count) ? M_search_count + LY_COUNT : M_limits_count + LY_COUNT];
	t_outlet *search_outlet;
	
	double o, o_lo, o_hi, r, r_lo, r_hi;
	t_atom params_out[M_param_count];
	t_outlet *params_outlet;
	double lyap_exp, lyap_lo, lyap_hi, lyap_limit, failure_ratio;
} circle_struct;

static void calc(circle_struct *circle, double *vars) {
	double x_0;
	x_0 =vars[M_x]+circle -> o-circle -> r/(2*M_PI)*sin(2*M_PI*vars[M_x]);
	vars[M_x] = x_0;
} // end calc

static void calculate(circle_struct *circle) {
	calc(circle, circle -> vars);
	outlet_float(circle -> x_obj.ob_outlet, circle -> vars[M_x]);
} // end calculate

static void reset(circle_struct *circle, t_symbol *s, int argc, t_atom *argv) {
	if (argc == M_var_count) {
		circle -> vars[M_x] = (double) atom_getfloatarg(M_x, argc, argv);
	} else {
		circle -> vars[M_x] = circle -> vars_init[M_x];
	} // end if
} // end reset

static double lyapunov_eval(circle_struct *circle, int var_count, double *vars, double *test) {
	int i, j;
	double exponent, sum, d2, df, rs;
	double diff[M_var_count];

	exponent = sum = 0.0;
	for(i = 0; i < LY_ITERATIONS; i++) {
		calc(circle, vars);
		calc(circle, test);
		d2 = 0.0;
		for(j = 0; j < var_count; j++) {
			diff[j] = test[j] - vars[j];
			d2 += diff[j] * diff[j];
		}
		df = 1000000000000.0 * d2;
		rs = 1.0 / sqrt(df);
		sum += log(df);
		exponent = 0.721347 * sum / i;
		for(j = 0; j < var_count; j++) {
			test[j] = vars[j] + (rs * (test[j] - vars[j]));
		}
	}
	return exponent;
}

static double lyapunov(circle_struct *circle, int var_count, double *vars) {
	int i;
	double test[M_var_count];

	test[0] = vars[0] + LY_ABERATION;
	for(i = 1; i < var_count; i++) { test[i] = vars[i]; }

	return lyapunov_eval(circle, var_count, vars, test);
}

static double *lyapunov_full(circle_struct *circle, int var_count, double *vars, double *results) {
	int i, j;
	double initial[M_var_count];
	double test[M_var_count];

	for(i = 0; i < var_count; i++) {
		initial[i] = vars[i];
	}
	for(i = 0; i < var_count; i++) {
		for(j = 0; j < var_count; j++) {
			if (j == i) {
				test[j] = vars[j] + LY_ABERATION;
			} else {
				test[j] = vars[j];
			}
		}
		results[i] = lyapunov_eval(circle, var_count, vars, test);
		for(j = 0; j < var_count; j++) { vars[j] = initial[j]; }
	}
	return results;
}

static char *classify(circle_struct *circle) {
	static char buff[3];
	char *c = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	buff[0] = c[(int) (((circle -> o - M_o_lo) * (1.0 / (M_o_hi - M_o_lo))) * 26)];
	buff[1] = c[(int) (((circle -> r - M_r_lo) * (1.0 / (M_r_hi - M_r_lo))) * 26)];
	buff[2] = '\0';
	return buff;
}

static void limits(circle_struct *circle) {
	SETFLOAT(&circle -> search_out[0], circle -> o_lo);
	SETFLOAT(&circle -> search_out[1], circle -> o_hi);
	SETFLOAT(&circle -> search_out[2], circle -> r_lo);
	SETFLOAT(&circle -> search_out[3], circle -> r_hi);
	SETFLOAT(&circle -> search_out[4], circle -> lyap_lo);
	SETFLOAT(&circle -> search_out[5], circle -> lyap_hi);
	SETFLOAT(&circle -> search_out[6], circle -> lyap_limit);
	outlet_anything(circle -> search_outlet, gensym("limits"), M_limits_count + LY_COUNT, circle -> search_out);
}

static void make_results(circle_struct *circle) {
	SETFLOAT(&circle -> search_out[0], circle -> lyap_exp);
	SETSYMBOL(&circle -> search_out[1], gensym(classify(circle)));
	SETFLOAT(&circle -> search_out[2], circle -> failure_ratio);
	SETFLOAT(&circle -> vars_out[M_x], circle -> vars[M_x]);
	SETFLOAT(&circle -> params_out[M_o], circle -> o);
	SETFLOAT(&circle -> params_out[M_r], circle -> r);
	outlet_list(circle -> params_outlet, gensym("list"), M_param_count, circle -> params_out);
	outlet_list(circle -> vars_outlet, gensym("list"), M_var_count, circle -> vars_out);
}

static void show(circle_struct *circle) {
	double t_x = circle -> vars[0];
	circle -> lyap_exp = lyapunov(circle, M_var_count, (double *) circle -> vars);
	circle -> vars[0] = t_x;
	make_results(circle);
	outlet_anything(circle -> search_outlet, gensym("show"), M_search_count, circle -> search_out);
}

static void param(circle_struct *circle, t_symbol *s, int argc, t_atom *argv) {
	if (argc != 2) {
		post("Incorrect number of arguments for circle fractal. Expecting 2 arguments.");
		return;
	}
	circle -> o = (double) atom_getfloatarg(0, argc, argv);
	circle -> r = (double) atom_getfloatarg(1, argc, argv);
}

static void seed(circle_struct *circle, t_symbol *s, int argc, t_atom *argv) {
	if (argc > 0) {
		srand48(((unsigned int)time(0))|1);
	} else {
		srand48((unsigned int) atom_getfloatarg(0, argc, argv));
	}
}

static void lyap(circle_struct *circle, t_floatarg l, t_floatarg h, t_floatarg lim) {
	circle -> lyap_lo = l;
	circle -> lyap_hi = h;
	circle -> lyap_limit = (double) ((int) lim);
}

static void elyap(circle_struct *circle) {
	double results[M_var_count];
	int i;
	if (lyapunov_full(circle, M_var_count, circle -> vars, results) != NULL) {
		post("elyapunov:");
		for(i = 0; i < M_var_count; i++) { post("%d: %3.80f", i, results[i]); }
	}
}

static void limiter(circle_struct *circle) {
}

static void constrain(circle_struct *circle, t_symbol *s, int argc, t_atom *argv) {
	int i;
	t_atom *arg = argv;
	if (argc == 0) {
		// reset to full limits of search ranges
		circle -> o_lo = M_o_lo;
		circle -> o_hi = M_o_hi;
		circle -> r_lo = M_r_lo;
		circle -> r_hi = M_r_hi;
		return;
	}
	if (argc == 1) {
		// set the ranges based on percentage of full range
		double percent = atom_getfloat(arg);
		double o_spread = ((M_o_hi - M_o_lo) * percent) / 2;
		double r_spread = ((M_r_hi - M_r_lo) * percent) / 2;
		circle -> o_lo = circle -> o - o_spread;
		circle -> o_hi = circle -> o + o_spread;
		circle -> r_lo = circle -> r - r_spread;
		circle -> r_hi = circle -> r + r_spread;
		limiter(circle);
		return;
	}
	if (argc != M_param_count * 2) {
		post("Invalid number of arguments for circle constraints, requires 4 values, got %d", argc);
		return;
	}
	circle -> o_lo = atom_getfloat(arg++);
	circle -> o_hi = atom_getfloat(arg++);
	circle -> r_lo = atom_getfloat(arg++);
	circle -> r_hi = atom_getfloat(arg++);
	limiter(circle);
}

static void search(circle_struct *circle, t_symbol *s, int argc, t_atom *argv) {
	int not_found, not_expired = circle -> lyap_limit;
	int jump, i, iterations;
	t_atom vars[M_var_count];
	double t_o = circle -> o;
	double t_r = circle -> r;
	if (argc > 0) {
		for (i = 0; i < M_var_count; i++) {
			SETFLOAT(&vars[i], atom_getfloatarg(i, argc, argv));
		}
	} else {
		for (i = 0; i < M_var_count; i++) {
			SETFLOAT(&vars[i], circle -> vars_init[i]);
		}
	}
	do {
		jump = 500;
		not_found = 0;
		iterations = 10000;
		bad_params:
		circle -> o = (drand48() * (circle -> o_hi - circle -> o_lo)) + circle -> o_lo;
		circle -> r = (drand48() * (circle -> r_hi - circle -> r_lo)) + circle -> r_lo;
		// put any preliminary checks specific to this fractal to eliminate bad_params

		reset(circle, NULL, argc, vars);
		do { calc(circle, circle -> vars); } while(jump--);
		circle -> lyap_exp = lyapunov(circle, M_var_count, (double *) circle -> vars);
		if (isnan(circle -> lyap_exp)) { not_found = 1; }
		if (circle -> lyap_exp < circle -> lyap_lo || circle -> lyap_exp > circle -> lyap_hi) { not_found = 1; }
		not_expired--;
	} while(not_found && not_expired);
	reset(circle, NULL, argc, vars);
	if (!not_expired) {
		post("Could not find a fractal after %d attempts.", (int) circle -> lyap_limit);
		post("Try using wider constraints.");
		circle -> o = t_o;
		circle -> r = t_r;
		outlet_anything(circle -> search_outlet, gensym("fail"), 0, NULL);
	} else {
		circle -> failure_ratio = (circle -> lyap_limit - not_expired) / circle -> lyap_limit;
		make_results(circle);
		outlet_anything(circle -> search_outlet, gensym("search"), M_search_count, circle -> search_out);
	}
}

void *circle_new(t_symbol *s, int argc, t_atom *argv) {
	circle_struct *circle = (circle_struct *) pd_new(circle_class);
	if (circle != NULL) {
		outlet_new(&circle -> x_obj, &s_float);
		circle -> search_outlet = outlet_new(&circle -> x_obj, &s_list);
		circle -> vars_outlet = outlet_new(&circle -> x_obj, &s_list);
		circle -> params_outlet = outlet_new(&circle -> x_obj, &s_list);
		if (argc == M_param_count + M_var_count) {
			circle -> vars_init[M_x] = circle -> vars[M_x] = (double) atom_getfloatarg(0, argc, argv);
			circle -> o = (double) atom_getfloatarg(1, argc, argv);
			circle -> r = (double) atom_getfloatarg(2, argc, argv);
		} else {
			if (argc != 0 && argc != M_param_count + M_var_count) {
				post("Incorrect number of arguments for circle fractal. Expecting 3 arguments.");
			}
			circle -> vars_init[M_x] = 0.4;
			circle -> o = 0.1;
			circle -> r = 3;
		}
		constrain(circle, NULL, 0, NULL);
		lyap(circle, -1000000.0, 1000000.0, M_failure_limit);
	}
	return (void *)circle;
}

void circle_setup(void) {
	post(version);
	circle_class = class_new(gensym("circle"), (t_newmethod) circle_new, 0, sizeof(circle_struct), 0, A_GIMME, 0);
	class_addbang(circle_class, (t_method) calculate);
	class_addmethod(circle_class, (t_method) reset, gensym("reset"), A_GIMME, 0);
	class_addmethod(circle_class, (t_method) show, gensym("show"), 0);
	class_addmethod(circle_class, (t_method) limits, gensym("limits"), 0);
	class_addmethod(circle_class, (t_method) param, gensym("param"), A_GIMME, 0);
	class_addmethod(circle_class, (t_method) seed, gensym("seed"), A_GIMME, 0);
	class_addmethod(circle_class, (t_method) lyap, gensym("lyapunov"), A_DEFFLOAT, A_DEFFLOAT, A_DEFFLOAT, 0);
	class_addmethod(circle_class, (t_method) elyap, gensym("elyapunov"), 0);
	class_addmethod(circle_class, (t_method) search, gensym("search"), A_GIMME, 0);
	class_addmethod(circle_class, (t_method) constrain, gensym("constrain"), A_GIMME, 0);
	class_sethelpsymbol(circle_class, gensym("circle-help.pd"));
}

