/* gauss Attractor PD External */
/* Copyright taken from Willi-Hans Steeb: Chaos and Fractals, 2006 */
/* This program is distributed under the params of the GNU Public License */

///////////////////////////////////////////////////////////////////////////////////
/* This file is part of Chaos PD Externals.                                      */
/*                                                                               */
/* Chaos PD Externals are free software; you can redistribute them and/or modify */
/* them under the terms of the GNU General Public License as published by        */
/* the Free Software Foundation; either version 2 of the License, or             */
/* (at your option) any later version.                                           */
/*                                                                               */
/* Chaos PD Externals are distributed in the hope that they will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of                */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                 */
/* GNU General Public License for more details.                                  */
/*                                                                               */
/* You should have received a copy of the GNU General Public License             */
/* along with the Chaos PD Externals; if not, write to the Free Software         */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA     */
///////////////////////////////////////////////////////////////////////////////////

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include "m_pd.h"



#define M_x 0

#define LY_ITERATIONS 50000
#define LY_ABERATION 10e-15
#define LY_COUNT 3

#define M_param_count 0
#define M_var_count 1
#define M_search_count 0
#define M_limits_count 0
#define M_failure_limit 1000

static char *version = "gauss v0.05, by taken from Willi-Hans Steeb: Chaos and Fractals, 2006";

t_class *gauss_class;

typedef struct gauss_struct {
	t_object x_obj;

	double vars[M_var_count];
	double vars_init[M_var_count];
} gauss_struct;

static void calc(gauss_struct *gauss, double *vars) {
	double x_0;
	x_0 =(vars[M_x]==0)?0.001:fmod(1/vars[M_x],1);
	vars[M_x] = x_0;
} // end calc

static void calculate(gauss_struct *gauss) {
	calc(gauss, gauss -> vars);
	outlet_float(gauss -> x_obj.ob_outlet, gauss -> vars[M_x]);
} // end calculate

static void reset(gauss_struct *gauss, t_symbol *s, int argc, t_atom *argv) {
	if (argc == M_var_count) {
		gauss -> vars[M_x] = (double) atom_getfloatarg(M_x, argc, argv);
	} else {
		gauss -> vars[M_x] = gauss -> vars_init[M_x];
	} // end if
} // end reset

void *gauss_new(t_symbol *s, int argc, t_atom *argv) {
	gauss_struct *gauss = (gauss_struct *) pd_new(gauss_class);
	if (gauss != NULL) {
		outlet_new(&gauss -> x_obj, &s_float);
		if (argc == M_param_count + M_var_count) {
			gauss -> vars_init[M_x] = gauss -> vars[M_x] = (double) atom_getfloatarg(0, argc, argv);
		} else {
			if (argc != 0 && argc != M_param_count + M_var_count) {
				post("Incorrect number of arguments for gauss fractal. Expecting 1 arguments.");
			}
			gauss -> vars_init[M_x] = 0.1;
		}
	}
	return (void *)gauss;
}

void gauss_setup(void) {
	post(version);
	gauss_class = class_new(gensym("gauss"), (t_newmethod) gauss_new, 0, sizeof(gauss_struct), 0, A_GIMME, 0);
	class_addbang(gauss_class, (t_method) calculate);
	class_addmethod(gauss_class, (t_method) reset, gensym("reset"), A_GIMME, 0);
	class_sethelpsymbol(gauss_class, gensym("gauss-help.pd"));
}

