/* bungalow Attractor PD External */
/* Copyright taken from Willi-Hans Steeb: Chaos and Fractals, 2006 */
/* This program is distributed under the params of the GNU Public License */

///////////////////////////////////////////////////////////////////////////////////
/* This file is part of Chaos PD Externals.                                      */
/*                                                                               */
/* Chaos PD Externals are free software; you can redistribute them and/or modify */
/* them under the terms of the GNU General Public License as published by        */
/* the Free Software Foundation; either version 2 of the License, or             */
/* (at your option) any later version.                                           */
/*                                                                               */
/* Chaos PD Externals are distributed in the hope that they will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of                */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                 */
/* GNU General Public License for more details.                                  */
/*                                                                               */
/* You should have received a copy of the GNU General Public License             */
/* along with the Chaos PD Externals; if not, write to the Free Software         */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA     */
///////////////////////////////////////////////////////////////////////////////////

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include "m_pd.h"

#define M_r_lo -0.5
#define M_r_hi 1

#define M_r 0

#define M_x 0

#define LY_ITERATIONS 50000
#define LY_ABERATION 10e-15
#define LY_COUNT 3

#define M_param_count 1
#define M_var_count 1
#define M_search_count 3
#define M_limits_count 2
#define M_failure_limit 1000

static char *version = "bungalow v0.05, by taken from Willi-Hans Steeb: Chaos and Fractals, 2006";

t_class *bungalow_class;

typedef struct bungalow_struct {
	t_object x_obj;

	double vars[M_var_count];
	double vars_init[M_var_count];
	t_atom vars_out[M_var_count];
	t_outlet *vars_outlet;
	
	t_atom search_out[(M_search_count > M_limits_count) ? M_search_count + LY_COUNT : M_limits_count + LY_COUNT];
	t_outlet *search_outlet;
	
	double r, r_lo, r_hi;
	t_atom params_out[M_param_count];
	t_outlet *params_outlet;
	double lyap_exp, lyap_lo, lyap_hi, lyap_limit, failure_ratio;
} bungalow_struct;

static void calc(bungalow_struct *bungalow, double *vars) {
	double x_0 = vars[M_x];
	if(x_0 <-0.5){
		x_0 =1+2*bungalow -> r+2*(bungalow -> r+1)*x_0;
	} else if(x_0 <0){
		x_0 =1+2*(1-bungalow -> r)*x_0;
	}else if(x_0 <0.5){
		x_0 =1+2*(bungalow -> r-1)*x_0;
	}else{
		x_0 =1+2*bungalow -> r-2*(bungalow -> r+1)*x_0;
	}
	vars[M_x] = x_0;
} // end calc

static void calculate(bungalow_struct *bungalow) {
	calc(bungalow, bungalow -> vars);
	outlet_float(bungalow -> x_obj.ob_outlet, bungalow -> vars[M_x]);
} // end calculate

static void reset(bungalow_struct *bungalow, t_symbol *s, int argc, t_atom *argv) {
	if (argc == M_var_count) {
		bungalow -> vars[M_x] = (double) atom_getfloatarg(M_x, argc, argv);
	} else {
		bungalow -> vars[M_x] = bungalow -> vars_init[M_x];
	} // end if
} // end reset

static double lyapunov_eval(bungalow_struct *bungalow, int var_count, double *vars, double *test) {
	int i, j;
	double exponent, sum, d2, df, rs;
	double diff[M_var_count];

	exponent = sum = 0.0;
	for(i = 0; i < LY_ITERATIONS; i++) {
		calc(bungalow, vars);
		calc(bungalow, test);
		d2 = 0.0;
		for(j = 0; j < var_count; j++) {
			diff[j] = test[j] - vars[j];
			d2 += diff[j] * diff[j];
		}
		df = 1000000000000.0 * d2;
		rs = 1.0 / sqrt(df);
		sum += log(df);
		exponent = 0.721347 * sum / i;
		for(j = 0; j < var_count; j++) {
			test[j] = vars[j] + (rs * (test[j] - vars[j]));
		}
	}
	return exponent;
}

static double lyapunov(bungalow_struct *bungalow, int var_count, double *vars) {
	int i;
	double test[M_var_count];

	test[0] = vars[0] + LY_ABERATION;
	for(i = 1; i < var_count; i++) { test[i] = vars[i]; }

	return lyapunov_eval(bungalow, var_count, vars, test);
}

static double *lyapunov_full(bungalow_struct *bungalow, int var_count, double *vars, double *results) {
	int i, j;
	double initial[M_var_count];
	double test[M_var_count];

	for(i = 0; i < var_count; i++) {
		initial[i] = vars[i];
	}
	for(i = 0; i < var_count; i++) {
		for(j = 0; j < var_count; j++) {
			if (j == i) {
				test[j] = vars[j] + LY_ABERATION;
			} else {
				test[j] = vars[j];
			}
		}
		results[i] = lyapunov_eval(bungalow, var_count, vars, test);
		for(j = 0; j < var_count; j++) { vars[j] = initial[j]; }
	}
	return results;
}

static char *classify(bungalow_struct *bungalow) {
	static char buff[2];
	char *c = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	buff[0] = c[(int) (((bungalow -> r - M_r_lo) * (1.0 / (M_r_hi - M_r_lo))) * 26)];
	buff[1] = '\0';
	return buff;
}

static void limits(bungalow_struct *bungalow) {
	SETFLOAT(&bungalow -> search_out[0], bungalow -> r_lo);
	SETFLOAT(&bungalow -> search_out[1], bungalow -> r_hi);
	SETFLOAT(&bungalow -> search_out[2], bungalow -> lyap_lo);
	SETFLOAT(&bungalow -> search_out[3], bungalow -> lyap_hi);
	SETFLOAT(&bungalow -> search_out[4], bungalow -> lyap_limit);
	outlet_anything(bungalow -> search_outlet, gensym("limits"), M_limits_count + LY_COUNT, bungalow -> search_out);
}

static void make_results(bungalow_struct *bungalow) {
	SETFLOAT(&bungalow -> search_out[0], bungalow -> lyap_exp);
	SETSYMBOL(&bungalow -> search_out[1], gensym(classify(bungalow)));
	SETFLOAT(&bungalow -> search_out[2], bungalow -> failure_ratio);
	SETFLOAT(&bungalow -> vars_out[M_x], bungalow -> vars[M_x]);
	SETFLOAT(&bungalow -> params_out[M_r], bungalow -> r);
	outlet_list(bungalow -> params_outlet, gensym("list"), M_param_count, bungalow -> params_out);
	outlet_list(bungalow -> vars_outlet, gensym("list"), M_var_count, bungalow -> vars_out);
}

static void show(bungalow_struct *bungalow) {
	double t_x = bungalow -> vars[0];
	bungalow -> lyap_exp = lyapunov(bungalow, M_var_count, (double *) bungalow -> vars);
	bungalow -> vars[0] = t_x;
	make_results(bungalow);
	outlet_anything(bungalow -> search_outlet, gensym("show"), M_search_count, bungalow -> search_out);
}

static void param(bungalow_struct *bungalow, t_symbol *s, int argc, t_atom *argv) {
	if (argc != 1) {
		post("Incorrect number of arguments for bungalow fractal. Expecting 1 arguments.");
		return;
	}
	bungalow -> r = (double) atom_getfloatarg(0, argc, argv);
}

static void seed(bungalow_struct *bungalow, t_symbol *s, int argc, t_atom *argv) {
	if (argc > 0) {
		srand48(((unsigned int)time(0))|1);
	} else {
		srand48((unsigned int) atom_getfloatarg(0, argc, argv));
	}
}

static void lyap(bungalow_struct *bungalow, t_floatarg l, t_floatarg h, t_floatarg lim) {
	bungalow -> lyap_lo = l;
	bungalow -> lyap_hi = h;
	bungalow -> lyap_limit = (double) ((int) lim);
}

static void elyap(bungalow_struct *bungalow) {
	double results[M_var_count];
	int i;
	if (lyapunov_full(bungalow, M_var_count, bungalow -> vars, results) != NULL) {
		post("elyapunov:");
		for(i = 0; i < M_var_count; i++) { post("%d: %3.80f", i, results[i]); }
	}
}

static void limiter(bungalow_struct *bungalow) {
}

static void constrain(bungalow_struct *bungalow, t_symbol *s, int argc, t_atom *argv) {
	int i;
	t_atom *arg = argv;
	if (argc == 0) {
		// reset to full limits of search ranges
		bungalow -> r_lo = M_r_lo;
		bungalow -> r_hi = M_r_hi;
		return;
	}
	if (argc == 1) {
		// set the ranges based on percentage of full range
		double percent = atom_getfloat(arg);
		double r_spread = ((M_r_hi - M_r_lo) * percent) / 2;
		bungalow -> r_lo = bungalow -> r - r_spread;
		bungalow -> r_hi = bungalow -> r + r_spread;
		limiter(bungalow);
		return;
	}
	if (argc != M_param_count * 2) {
		post("Invalid number of arguments for bungalow constraints, requires 2 values, got %d", argc);
		return;
	}
	bungalow -> r_lo = atom_getfloat(arg++);
	bungalow -> r_hi = atom_getfloat(arg++);
	limiter(bungalow);
}

static void search(bungalow_struct *bungalow, t_symbol *s, int argc, t_atom *argv) {
	int not_found, not_expired = bungalow -> lyap_limit;
	int jump, i, iterations;
	t_atom vars[M_var_count];
	double t_r = bungalow -> r;
	if (argc > 0) {
		for (i = 0; i < M_var_count; i++) {
			SETFLOAT(&vars[i], atom_getfloatarg(i, argc, argv));
		}
	} else {
		for (i = 0; i < M_var_count; i++) {
			SETFLOAT(&vars[i], bungalow -> vars_init[i]);
		}
	}
	do {
		jump = 500;
		not_found = 0;
		iterations = 10000;
		bad_params:
		bungalow -> r = (drand48() * (bungalow -> r_hi - bungalow -> r_lo)) + bungalow -> r_lo;
		// put any preliminary checks specific to this fractal to eliminate bad_params

		reset(bungalow, NULL, argc, vars);
		do { calc(bungalow, bungalow -> vars); } while(jump--);
		bungalow -> lyap_exp = lyapunov(bungalow, M_var_count, (double *) bungalow -> vars);
		if (isnan(bungalow -> lyap_exp)) { not_found = 1; }
		if (bungalow -> lyap_exp < bungalow -> lyap_lo || bungalow -> lyap_exp > bungalow -> lyap_hi) { not_found = 1; }
		not_expired--;
	} while(not_found && not_expired);
	reset(bungalow, NULL, argc, vars);
	if (!not_expired) {
		post("Could not find a fractal after %d attempts.", (int) bungalow -> lyap_limit);
		post("Try using wider constraints.");
		bungalow -> r = t_r;
		outlet_anything(bungalow -> search_outlet, gensym("fail"), 0, NULL);
	} else {
		bungalow -> failure_ratio = (bungalow -> lyap_limit - not_expired) / bungalow -> lyap_limit;
		make_results(bungalow);
		outlet_anything(bungalow -> search_outlet, gensym("search"), M_search_count, bungalow -> search_out);
	}
}

void *bungalow_new(t_symbol *s, int argc, t_atom *argv) {
	bungalow_struct *bungalow = (bungalow_struct *) pd_new(bungalow_class);
	if (bungalow != NULL) {
		outlet_new(&bungalow -> x_obj, &s_float);
		bungalow -> search_outlet = outlet_new(&bungalow -> x_obj, &s_list);
		bungalow -> vars_outlet = outlet_new(&bungalow -> x_obj, &s_list);
		bungalow -> params_outlet = outlet_new(&bungalow -> x_obj, &s_list);
		if (argc == M_param_count + M_var_count) {
			bungalow -> vars_init[M_x] = bungalow -> vars[M_x] = (double) atom_getfloatarg(0, argc, argv);
			bungalow -> r = (double) atom_getfloatarg(1, argc, argv);
		} else {
			if (argc != 0 && argc != M_param_count + M_var_count) {
				post("Incorrect number of arguments for bungalow fractal. Expecting 2 arguments.");
			}
			bungalow -> vars_init[M_x] = 0.1;
			bungalow -> r = 0.618;
		}
		constrain(bungalow, NULL, 0, NULL);
		lyap(bungalow, -1000000.0, 1000000.0, M_failure_limit);
	}
	return (void *)bungalow;
}

void bungalow_setup(void) {
	post(version);
	bungalow_class = class_new(gensym("bungalow"), (t_newmethod) bungalow_new, 0, sizeof(bungalow_struct), 0, A_GIMME, 0);
	class_addbang(bungalow_class, (t_method) calculate);
	class_addmethod(bungalow_class, (t_method) reset, gensym("reset"), A_GIMME, 0);
	class_addmethod(bungalow_class, (t_method) show, gensym("show"), 0);
	class_addmethod(bungalow_class, (t_method) limits, gensym("limits"), 0);
	class_addmethod(bungalow_class, (t_method) param, gensym("param"), A_GIMME, 0);
	class_addmethod(bungalow_class, (t_method) seed, gensym("seed"), A_GIMME, 0);
	class_addmethod(bungalow_class, (t_method) lyap, gensym("lyapunov"), A_DEFFLOAT, A_DEFFLOAT, A_DEFFLOAT, 0);
	class_addmethod(bungalow_class, (t_method) elyap, gensym("elyapunov"), 0);
	class_addmethod(bungalow_class, (t_method) search, gensym("search"), A_GIMME, 0);
	class_addmethod(bungalow_class, (t_method) constrain, gensym("constrain"), A_GIMME, 0);
	class_sethelpsymbol(bungalow_class, gensym("bungalow-help.pd"));
}

