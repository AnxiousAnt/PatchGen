/* gaussian Attractor PD External */
/* Copyright taken from Robert C. Hilborn: Chaos and Nonlinear Dynamics, 2006 */
/* This program is distributed under the params of the GNU Public License */

///////////////////////////////////////////////////////////////////////////////////
/* This file is part of Chaos PD Externals.                                      */
/*                                                                               */
/* Chaos PD Externals are free software; you can redistribute them and/or modify */
/* them under the terms of the GNU General Public License as published by        */
/* the Free Software Foundation; either version 2 of the License, or             */
/* (at your option) any later version.                                           */
/*                                                                               */
/* Chaos PD Externals are distributed in the hope that they will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of                */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                 */
/* GNU General Public License for more details.                                  */
/*                                                                               */
/* You should have received a copy of the GNU General Public License             */
/* along with the Chaos PD Externals; if not, write to the Free Software         */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA     */
///////////////////////////////////////////////////////////////////////////////////

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include "m_pd.h"

#define M_b_lo -1000
#define M_b_hi 1000
#define M_c_lo -1000
#define M_c_hi 1000

#define M_b 0
#define M_c 1

#define M_x 0

#define LY_ITERATIONS 50000
#define LY_ABERATION 10e-15
#define LY_COUNT 3

#define M_param_count 2
#define M_var_count 1
#define M_search_count 3
#define M_limits_count 4
#define M_failure_limit 1000

static char *version = "gaussian v0.05, by taken from Robert C. Hilborn: Chaos and Nonlinear Dynamics, 2006";

t_class *gaussian_class;

typedef struct gaussian_struct {
	t_object x_obj;

	double vars[M_var_count];
	double vars_init[M_var_count];
	t_atom vars_out[M_var_count];
	t_outlet *vars_outlet;
	
	t_atom search_out[(M_search_count > M_limits_count) ? M_search_count + LY_COUNT : M_limits_count + LY_COUNT];
	t_outlet *search_outlet;
	
	double b, b_lo, b_hi, c, c_lo, c_hi;
	t_atom params_out[M_param_count];
	t_outlet *params_outlet;
	double lyap_exp, lyap_lo, lyap_hi, lyap_limit, failure_ratio;
} gaussian_struct;

static void calc(gaussian_struct *gaussian, double *vars) {
	double x_0;
	x_0 =exp(-gaussian -> b*vars[M_x]*vars[M_x])+gaussian -> c;
	vars[M_x] = x_0;
} // end calc

static void calculate(gaussian_struct *gaussian) {
	calc(gaussian, gaussian -> vars);
	outlet_float(gaussian -> x_obj.ob_outlet, gaussian -> vars[M_x]);
} // end calculate

static void reset(gaussian_struct *gaussian, t_symbol *s, int argc, t_atom *argv) {
	if (argc == M_var_count) {
		gaussian -> vars[M_x] = (double) atom_getfloatarg(M_x, argc, argv);
	} else {
		gaussian -> vars[M_x] = gaussian -> vars_init[M_x];
	} // end if
} // end reset

static double lyapunov_eval(gaussian_struct *gaussian, int var_count, double *vars, double *test) {
	int i, j;
	double exponent, sum, d2, df, rs;
	double diff[M_var_count];

	exponent = sum = 0.0;
	for(i = 0; i < LY_ITERATIONS; i++) {
		calc(gaussian, vars);
		calc(gaussian, test);
		d2 = 0.0;
		for(j = 0; j < var_count; j++) {
			diff[j] = test[j] - vars[j];
			d2 += diff[j] * diff[j];
		}
		df = 1000000000000.0 * d2;
		rs = 1.0 / sqrt(df);
		sum += log(df);
		exponent = 0.721347 * sum / i;
		for(j = 0; j < var_count; j++) {
			test[j] = vars[j] + (rs * (test[j] - vars[j]));
		}
	}
	return exponent;
}

static double lyapunov(gaussian_struct *gaussian, int var_count, double *vars) {
	int i;
	double test[M_var_count];

	test[0] = vars[0] + LY_ABERATION;
	for(i = 1; i < var_count; i++) { test[i] = vars[i]; }

	return lyapunov_eval(gaussian, var_count, vars, test);
}

static double *lyapunov_full(gaussian_struct *gaussian, int var_count, double *vars, double *results) {
	int i, j;
	double initial[M_var_count];
	double test[M_var_count];

	for(i = 0; i < var_count; i++) {
		initial[i] = vars[i];
	}
	for(i = 0; i < var_count; i++) {
		for(j = 0; j < var_count; j++) {
			if (j == i) {
				test[j] = vars[j] + LY_ABERATION;
			} else {
				test[j] = vars[j];
			}
		}
		results[i] = lyapunov_eval(gaussian, var_count, vars, test);
		for(j = 0; j < var_count; j++) { vars[j] = initial[j]; }
	}
	return results;
}

static char *classify(gaussian_struct *gaussian) {
	static char buff[3];
	char *c = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	buff[0] = c[(int) (((gaussian -> b - M_b_lo) * (1.0 / (M_b_hi - M_b_lo))) * 26)];
	buff[1] = c[(int) (((gaussian -> c - M_c_lo) * (1.0 / (M_c_hi - M_c_lo))) * 26)];
	buff[2] = '\0';
	return buff;
}

static void limits(gaussian_struct *gaussian) {
	SETFLOAT(&gaussian -> search_out[0], gaussian -> b_lo);
	SETFLOAT(&gaussian -> search_out[1], gaussian -> b_hi);
	SETFLOAT(&gaussian -> search_out[2], gaussian -> c_lo);
	SETFLOAT(&gaussian -> search_out[3], gaussian -> c_hi);
	SETFLOAT(&gaussian -> search_out[4], gaussian -> lyap_lo);
	SETFLOAT(&gaussian -> search_out[5], gaussian -> lyap_hi);
	SETFLOAT(&gaussian -> search_out[6], gaussian -> lyap_limit);
	outlet_anything(gaussian -> search_outlet, gensym("limits"), M_limits_count + LY_COUNT, gaussian -> search_out);
}

static void make_results(gaussian_struct *gaussian) {
	SETFLOAT(&gaussian -> search_out[0], gaussian -> lyap_exp);
	SETSYMBOL(&gaussian -> search_out[1], gensym(classify(gaussian)));
	SETFLOAT(&gaussian -> search_out[2], gaussian -> failure_ratio);
	SETFLOAT(&gaussian -> vars_out[M_x], gaussian -> vars[M_x]);
	SETFLOAT(&gaussian -> params_out[M_b], gaussian -> b);
	SETFLOAT(&gaussian -> params_out[M_c], gaussian -> c);
	outlet_list(gaussian -> params_outlet, gensym("list"), M_param_count, gaussian -> params_out);
	outlet_list(gaussian -> vars_outlet, gensym("list"), M_var_count, gaussian -> vars_out);
}

static void show(gaussian_struct *gaussian) {
	double t_x = gaussian -> vars[0];
	gaussian -> lyap_exp = lyapunov(gaussian, M_var_count, (double *) gaussian -> vars);
	gaussian -> vars[0] = t_x;
	make_results(gaussian);
	outlet_anything(gaussian -> search_outlet, gensym("show"), M_search_count, gaussian -> search_out);
}

static void param(gaussian_struct *gaussian, t_symbol *s, int argc, t_atom *argv) {
	if (argc != 2) {
		post("Incorrect number of arguments for gaussian fractal. Expecting 2 arguments.");
		return;
	}
	gaussian -> b = (double) atom_getfloatarg(0, argc, argv);
	gaussian -> c = (double) atom_getfloatarg(1, argc, argv);
}

static void seed(gaussian_struct *gaussian, t_symbol *s, int argc, t_atom *argv) {
	if (argc > 0) {
		srand48(((unsigned int)time(0))|1);
	} else {
		srand48((unsigned int) atom_getfloatarg(0, argc, argv));
	}
}

static void lyap(gaussian_struct *gaussian, t_floatarg l, t_floatarg h, t_floatarg lim) {
	gaussian -> lyap_lo = l;
	gaussian -> lyap_hi = h;
	gaussian -> lyap_limit = (double) ((int) lim);
}

static void elyap(gaussian_struct *gaussian) {
	double results[M_var_count];
	int i;
	if (lyapunov_full(gaussian, M_var_count, gaussian -> vars, results) != NULL) {
		post("elyapunov:");
		for(i = 0; i < M_var_count; i++) { post("%d: %3.80f", i, results[i]); }
	}
}

static void limiter(gaussian_struct *gaussian) {
}

static void constrain(gaussian_struct *gaussian, t_symbol *s, int argc, t_atom *argv) {
	int i;
	t_atom *arg = argv;
	if (argc == 0) {
		// reset to full limits of search ranges
		gaussian -> b_lo = M_b_lo;
		gaussian -> b_hi = M_b_hi;
		gaussian -> c_lo = M_c_lo;
		gaussian -> c_hi = M_c_hi;
		return;
	}
	if (argc == 1) {
		// set the ranges based on percentage of full range
		double percent = atom_getfloat(arg);
		double b_spread = ((M_b_hi - M_b_lo) * percent) / 2;
		double c_spread = ((M_c_hi - M_c_lo) * percent) / 2;
		gaussian -> b_lo = gaussian -> b - b_spread;
		gaussian -> b_hi = gaussian -> b + b_spread;
		gaussian -> c_lo = gaussian -> c - c_spread;
		gaussian -> c_hi = gaussian -> c + c_spread;
		limiter(gaussian);
		return;
	}
	if (argc != M_param_count * 2) {
		post("Invalid number of arguments for gaussian constraints, requires 4 values, got %d", argc);
		return;
	}
	gaussian -> b_lo = atom_getfloat(arg++);
	gaussian -> b_hi = atom_getfloat(arg++);
	gaussian -> c_lo = atom_getfloat(arg++);
	gaussian -> c_hi = atom_getfloat(arg++);
	limiter(gaussian);
}

static void search(gaussian_struct *gaussian, t_symbol *s, int argc, t_atom *argv) {
	int not_found, not_expired = gaussian -> lyap_limit;
	int jump, i, iterations;
	t_atom vars[M_var_count];
	double t_b = gaussian -> b;
	double t_c = gaussian -> c;
	if (argc > 0) {
		for (i = 0; i < M_var_count; i++) {
			SETFLOAT(&vars[i], atom_getfloatarg(i, argc, argv));
		}
	} else {
		for (i = 0; i < M_var_count; i++) {
			SETFLOAT(&vars[i], gaussian -> vars_init[i]);
		}
	}
	do {
		jump = 500;
		not_found = 0;
		iterations = 10000;
		bad_params:
		gaussian -> b = (drand48() * (gaussian -> b_hi - gaussian -> b_lo)) + gaussian -> b_lo;
		gaussian -> c = (drand48() * (gaussian -> c_hi - gaussian -> c_lo)) + gaussian -> c_lo;
		// put any preliminary checks specific to this fractal to eliminate bad_params

		reset(gaussian, NULL, argc, vars);
		do { calc(gaussian, gaussian -> vars); } while(jump--);
		gaussian -> lyap_exp = lyapunov(gaussian, M_var_count, (double *) gaussian -> vars);
		if (isnan(gaussian -> lyap_exp)) { not_found = 1; }
		if (gaussian -> lyap_exp < gaussian -> lyap_lo || gaussian -> lyap_exp > gaussian -> lyap_hi) { not_found = 1; }
		not_expired--;
	} while(not_found && not_expired);
	reset(gaussian, NULL, argc, vars);
	if (!not_expired) {
		post("Could not find a fractal after %d attempts.", (int) gaussian -> lyap_limit);
		post("Try using wider constraints.");
		gaussian -> b = t_b;
		gaussian -> c = t_c;
		outlet_anything(gaussian -> search_outlet, gensym("fail"), 0, NULL);
	} else {
		gaussian -> failure_ratio = (gaussian -> lyap_limit - not_expired) / gaussian -> lyap_limit;
		make_results(gaussian);
		outlet_anything(gaussian -> search_outlet, gensym("search"), M_search_count, gaussian -> search_out);
	}
}

void *gaussian_new(t_symbol *s, int argc, t_atom *argv) {
	gaussian_struct *gaussian = (gaussian_struct *) pd_new(gaussian_class);
	if (gaussian != NULL) {
		outlet_new(&gaussian -> x_obj, &s_float);
		gaussian -> search_outlet = outlet_new(&gaussian -> x_obj, &s_list);
		gaussian -> vars_outlet = outlet_new(&gaussian -> x_obj, &s_list);
		gaussian -> params_outlet = outlet_new(&gaussian -> x_obj, &s_list);
		if (argc == M_param_count + M_var_count) {
			gaussian -> vars_init[M_x] = gaussian -> vars[M_x] = (double) atom_getfloatarg(0, argc, argv);
			gaussian -> b = (double) atom_getfloatarg(1, argc, argv);
			gaussian -> c = (double) atom_getfloatarg(2, argc, argv);
		} else {
			if (argc != 0 && argc != M_param_count + M_var_count) {
				post("Incorrect number of arguments for gaussian fractal. Expecting 3 arguments.");
			}
			gaussian -> vars_init[M_x] = 0.1;
			gaussian -> b = 1;
			gaussian -> c = 1;
		}
		constrain(gaussian, NULL, 0, NULL);
		lyap(gaussian, -1000000.0, 1000000.0, M_failure_limit);
	}
	return (void *)gaussian;
}

void gaussian_setup(void) {
	post(version);
	gaussian_class = class_new(gensym("gaussian"), (t_newmethod) gaussian_new, 0, sizeof(gaussian_struct), 0, A_GIMME, 0);
	class_addbang(gaussian_class, (t_method) calculate);
	class_addmethod(gaussian_class, (t_method) reset, gensym("reset"), A_GIMME, 0);
	class_addmethod(gaussian_class, (t_method) show, gensym("show"), 0);
	class_addmethod(gaussian_class, (t_method) limits, gensym("limits"), 0);
	class_addmethod(gaussian_class, (t_method) param, gensym("param"), A_GIMME, 0);
	class_addmethod(gaussian_class, (t_method) seed, gensym("seed"), A_GIMME, 0);
	class_addmethod(gaussian_class, (t_method) lyap, gensym("lyapunov"), A_DEFFLOAT, A_DEFFLOAT, A_DEFFLOAT, 0);
	class_addmethod(gaussian_class, (t_method) elyap, gensym("elyapunov"), 0);
	class_addmethod(gaussian_class, (t_method) search, gensym("search"), A_GIMME, 0);
	class_addmethod(gaussian_class, (t_method) constrain, gensym("constrain"), A_GIMME, 0);
	class_sethelpsymbol(gaussian_class, gensym("gaussian-help.pd"));
}

