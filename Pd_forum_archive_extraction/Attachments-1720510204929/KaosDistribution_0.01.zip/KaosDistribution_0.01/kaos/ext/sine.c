/* sine Attractor PD External */
/* Copyright taken from Willi-Hans Steeb: Chaos and Fractals, 2006 */
/* This program is distributed under the params of the GNU Public License */

///////////////////////////////////////////////////////////////////////////////////
/* This file is part of Chaos PD Externals.                                      */
/*                                                                               */
/* Chaos PD Externals are free software; you can redistribute them and/or modify */
/* them under the terms of the GNU General Public License as published by        */
/* the Free Software Foundation; either version 2 of the License, or             */
/* (at your option) any later version.                                           */
/*                                                                               */
/* Chaos PD Externals are distributed in the hope that they will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of                */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                 */
/* GNU General Public License for more details.                                  */
/*                                                                               */
/* You should have received a copy of the GNU General Public License             */
/* along with the Chaos PD Externals; if not, write to the Free Software         */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA     */
///////////////////////////////////////////////////////////////////////////////////

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include "m_pd.h"



#define M_x 0

#define LY_ITERATIONS 50000
#define LY_ABERATION 10e-15
#define LY_COUNT 3

#define M_param_count 0
#define M_var_count 1
#define M_search_count 0
#define M_limits_count 0
#define M_failure_limit 1000

static char *version = "sine v0.05, by taken from Willi-Hans Steeb: Chaos and Fractals, 2006";

t_class *sine_class;

typedef struct sine_struct {
	t_object x_obj;

	double vars[M_var_count];
	double vars_init[M_var_count];
} sine_struct;

static void calc(sine_struct *sine, double *vars) {
	double x_0;
	x_0 =sin(M_PI*vars[M_x]);
	vars[M_x] = x_0;
} // end calc

static void calculate(sine_struct *sine) {
	calc(sine, sine -> vars);
	outlet_float(sine -> x_obj.ob_outlet, sine -> vars[M_x]);
} // end calculate

static void reset(sine_struct *sine, t_symbol *s, int argc, t_atom *argv) {
	if (argc == M_var_count) {
		sine -> vars[M_x] = (double) atom_getfloatarg(M_x, argc, argv);
	} else {
		sine -> vars[M_x] = sine -> vars_init[M_x];
	} // end if
} // end reset

void *sine_new(t_symbol *s, int argc, t_atom *argv) {
	sine_struct *sine = (sine_struct *) pd_new(sine_class);
	if (sine != NULL) {
		outlet_new(&sine -> x_obj, &s_float);
		if (argc == M_param_count + M_var_count) {
			sine -> vars_init[M_x] = sine -> vars[M_x] = (double) atom_getfloatarg(0, argc, argv);
		} else {
			if (argc != 0 && argc != M_param_count + M_var_count) {
				post("Incorrect number of arguments for sine fractal. Expecting 1 arguments.");
			}
			sine -> vars_init[M_x] = 0.1;
		}
	}
	return (void *)sine;
}

void sine_setup(void) {
	post(version);
	sine_class = class_new(gensym("sine"), (t_newmethod) sine_new, 0, sizeof(sine_struct), 0, A_GIMME, 0);
	class_addbang(sine_class, (t_method) calculate);
	class_addmethod(sine_class, (t_method) reset, gensym("reset"), A_GIMME, 0);
	class_sethelpsymbol(sine_class, gensym("sine-help.pd"));
}

