/*
 * mask			- inspired by CMask (a CSound score generator)
 *
 *	signal		- the input signal
 *	cntrl		- controls how the map is applied (.5 = sqrt, 1 = linear, 2 = pow)
 *	out_lo		- the output low range
 *	out_hi		- the output hi range
 *
 * The input 'signal', in the range of 0..1, is first adjusted by the 'cntrl', the signal
 * is then scaled to the output range. Adjusting the 'cntrl', 'out_lo', or 'out_hi',
 * and sending a band to the input will  will recalculate the signal with the most
 * recent input value.
 */
#include "m_pd.h"
#include <math.h>

static char *version = "mask v0.5, by Michael McGonagle 2003-2006";

static t_class *mask_class;

typedef struct mask {
	t_object	x_obj;		// the base object
	
	t_float		signal, cntrl, out_lo, out_hi;
	
	t_outlet	*outlet1;
} t_mask;

static void mask_float(t_mask *x, t_floatarg sig) {
	t_float out;
	
	x -> signal = sig;
	out = (pow(sig, x -> cntrl) * (x -> out_hi - x -> out_lo)) + x -> out_lo;
	outlet_float(x -> outlet1, out);
}

static void mask_bang(t_mask *x) {
	mask_float(x, x -> signal);
}

static void *mask_new(t_floatarg f_cntrl, t_floatarg f_out_lo, t_floatarg f_out_hi) {
	t_mask *x = (t_mask *) pd_new(mask_class);
	
	if (x != NULL) {
		floatinlet_new(&x -> x_obj, &x -> cntrl);
		floatinlet_new(&x -> x_obj, &x -> out_lo);
		floatinlet_new(&x -> x_obj, &x -> out_hi);
		
		x -> outlet1 = outlet_new(&x -> x_obj, gensym("float"));
		
		x -> signal = 0;
		
		x -> cntrl = f_cntrl;
		x -> out_lo = f_out_lo;
		x -> out_hi = f_out_hi;
	}
	return (void *)x;
}

void mask_setup(void) {
	post(version);
	
	mask_class = class_new(gensym("mask"), (t_newmethod)mask_new, 0, sizeof(t_mask), 0, A_DEFFLOAT, A_DEFFLOAT, A_DEFFLOAT, 0);

	class_addfloat(mask_class, mask_float);
	class_addbang(mask_class, mask_bang);
	class_sethelpsymbol(mask_class, gensym("mask-help.pd"));
}
