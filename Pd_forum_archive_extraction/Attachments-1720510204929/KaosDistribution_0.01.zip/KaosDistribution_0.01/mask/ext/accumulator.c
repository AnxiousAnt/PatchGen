/*
 * accumulator			- inspired by CMask
 *
 *	x_signal	- the input signal
 *	x_mode		- the function to use
 *	x_init		- the initial value to use (also can be set with 'init' message)
 *	x_lo		- the output low range
 *	x_hi		- the output hi range
 */
#include "m_pd.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

static char *version = "accumulator v0.5, by Michael McGonagle";

static t_class *accumulator_class;

typedef struct accumulator {
	t_object	x_obj;

	t_float		x_signal, x_mode, x_init, x_lo, x_hi;
	
	t_outlet	*x_outlet1;
} t_accumulator;

static double myfmod(double l, double h, double v) {
	double diff, a;
	diff = h - l;
	a = (v - l) / diff;
	a = a - (int) a;
	a = (a < 0) ? a + 1 : a;
	return (a * diff) + l;
}

/* values for x_map */
#define ACCM_LIMIT		0
#define ACCM_MIRROR		1
#define ACCM_WRAP		2

static void accumulator_float(t_accumulator *x, t_floatarg in) {
	int mode = (int) x -> x_mode;
	double lo = x -> x_lo;
	double hi = x -> x_hi;
	double sig;

	sig = x -> x_signal;
	sig += in;
	switch(mode) {
		case ACCM_LIMIT:
			sig = (sig < hi) ? ((sig > lo) ? sig : lo) : hi;
			break;
		case ACCM_MIRROR:
			sig = (sig > hi) ? (hi - (sig - hi)) : (sig < lo) ? (lo + (lo - sig)) : sig;
			break;
		case ACCM_WRAP:
			sig = (sig > hi) ? (lo + (sig - hi)) : (sig < lo) ? (hi - (lo - sig)) : sig;
			break;
		default:
			post("Unknown mode for 'accumulator' of %ld\n", mode);
			break;
	}
	x -> x_signal = myfmod(lo, hi, sig);
	outlet_float(x -> x_outlet1, x -> x_signal);
}

static void accumulator_bang(t_accumulator *x) {
	outlet_float(x -> x_outlet1, x -> x_signal);
}

static void accumulator_reset(t_accumulator *x) {
	x -> x_signal = x -> x_init;
	accumulator_bang(x);
}

/*
static void accumulator_init(t_accumulator *x, t_floatarg i) {
	x -> x_init = i;
}
*/

static void *accumulator_new(t_floatarg f_mode, t_floatarg f_init, t_floatarg f_lo, t_floatarg f_hi) {
	t_accumulator *x = (t_accumulator *) pd_new(accumulator_class);

	if (x != NULL) {
		floatinlet_new(&x -> x_obj, &x -> x_mode);
		floatinlet_new(&x -> x_obj, &x -> x_init);
		floatinlet_new(&x -> x_obj, &x -> x_lo);
		floatinlet_new(&x -> x_obj, &x -> x_hi);
		
		x -> x_outlet1 = outlet_new(&x -> x_obj, gensym("float"));
		
		accumulator_reset(x);
		x -> x_mode = f_mode;
		x -> x_init = f_init;
		x -> x_lo = f_lo;
		x -> x_hi = f_hi;
	}
	return (void *)x;
}

void accumulator_setup(void) {
	post(version);
	
	accumulator_class = class_new(
		gensym("accumulator"),
		(t_newmethod)accumulator_new,
		0,
		sizeof(t_accumulator),
		0,
		A_DEFFLOAT, A_DEFFLOAT, A_DEFFLOAT, A_DEFFLOAT,
		0
	);
	
	class_addfloat(accumulator_class, accumulator_float);
	class_addbang(accumulator_class, accumulator_bang);
	class_addmethod(accumulator_class, (t_method)accumulator_reset, gensym("reset"), 0);
	//class_addmethod(accumulator_class, (t_method)accumulator_init, gensym("init"), A_DEFFLOAT, 0);
	class_sethelpsymbol(accumulator_class, gensym("accumulator-help.pd"));
}
