/*
 * inverter - this expects a signal in the range of 0..1 (inclusive), and if the
 * flag is set, will return a signal that is the inverted value.
 */
#include "m_pd.h"
#include <math.h>

static char *version = "inverter v0.5, by Michael McGonagle 2003-2006";

static t_class *inverter_class;

typedef struct _inverter {
	t_object  x_obj;
	
	t_float signal;
	t_float state;
} t_inverter;

/*
 * this will calculate a new signal.
 */
void inverter_float(t_inverter *x, t_floatarg sig) {
	if (x -> state != 0) {
		// invert the signal before outputing
		sig = -(sig - 1.0);
	}
	
	outlet_float(x -> x_obj.ob_outlet, sig);
}

/*
 * a bang will 'reoutput' the last value computed.
 */
void inverter_bang(t_inverter *x) {
	inverter_float(x, x -> signal);
}

void *inverter_new(void) {
	t_inverter *x = (t_inverter *)pd_new(inverter_class);
	
	if (x != NULL) {
		floatinlet_new(&x -> x_obj, &x -> state);
		outlet_new(&x -> x_obj, &s_float);
	}
	return (void *)x;
}

void inverter_setup(void) {
	post(version);
	inverter_class = class_new(gensym("inverter"), (t_newmethod)inverter_new, 0, sizeof(t_inverter), CLASS_DEFAULT, 0);
	class_addbang(inverter_class, inverter_bang);
	class_addfloat(inverter_class, inverter_float);
	class_sethelpsymbol(inverter_class, gensym("inverter-help.pd"));
}
