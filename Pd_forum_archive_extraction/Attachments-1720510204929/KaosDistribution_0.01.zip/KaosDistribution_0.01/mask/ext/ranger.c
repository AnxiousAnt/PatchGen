/*
 * the ranger external will take a signal, and over time, capture its highest and lowest values.
 * the object responds to an inlet of a float on its first input, as well as a 'reset' message that
 * is used to reset the values for the limits to their initial states. there is also two additional
 * inlets that allow the setting of the 'high' and 'low' limits at the start. as these values are
 * optional.
 
 * 1. initial state - if desired, high and low are set to the initial values, otherwise they are set
 *		to 'low = HIGHEST_VALUE, high = -low'
 * 2. with a float inlet on the first value, this signal is checked against 'high' and 'low', adjustments
 *		are made as necessary
 * 3. the 3 outlets, (1) adjusted signal, (2) lowest value (3) highest value
 * 4. using the 'reset' message, the 'high' and 'low' values are set to the initial state.
 */
#include "m_pd.h"

static char *version = "ranger v0.5, by Michael McGonagle 2003-2006";

static t_class *ranger_class;

typedef struct _ranger {
	t_object  x_obj;
	
	t_float		high;		// the current high value
	t_float		low;		// the current low value
	
	t_float		signal;		// the current signal
	
	t_outlet	*outlet_low;
	t_outlet	*outlet_high;
} t_ranger;

/*
 * a bang will 'reoutput' the last value computed.
 */
void ranger_bang(t_ranger *x)
{
	outlet_float(x -> x_obj.ob_outlet, x -> signal);
}

/*
 * this will calculate a new signal.
 */
void ranger_float(t_ranger *x, t_floatarg sig)
{
	// is the value with the current range, if no reset the current range
	if (sig > x -> high) {
		x -> high = sig;
		outlet_float(x -> outlet_high, x -> high);
	}
	if (sig < x -> low) {
		x -> low = sig;
		outlet_float(x -> outlet_low, x -> low);
	}
	// calculate the 'ranged' signal
	x -> signal = (sig - x -> low) * (1.0 / (x -> high - x -> low));
	ranger_bang(x);
}

static void ranger_reset(t_ranger *x, t_floatarg lo, t_floatarg hi)
{
	x -> low = lo;
	x -> high = hi;
}

void *ranger_new(void)
{
	t_ranger *x = (t_ranger *)pd_new(ranger_class);
	
	if (x != NULL) {
		// connect up the two inlets
		outlet_new(&x -> x_obj, &s_float);
		
		x -> outlet_low = outlet_new(&x -> x_obj, gensym("float"));
		x -> outlet_high = outlet_new(&x -> x_obj, gensym("float"));
		
		ranger_reset(x, 10000000.0, -10000000.0);
	}
	return (void *)x;
}

void ranger_setup(void)
{
	post(version);
	ranger_class = class_new(gensym("ranger"), (t_newmethod)ranger_new, 0, sizeof(t_ranger), CLASS_DEFAULT, 0);
	class_addbang(ranger_class, ranger_bang);
	class_addfloat(ranger_class, ranger_float);
	class_addmethod(ranger_class, (t_method)ranger_reset, gensym("reset"), A_DEFFLOAT, A_DEFFLOAT, 0);
	class_sethelpsymbol(ranger_class, gensym("ranger-help.pd"));
}
