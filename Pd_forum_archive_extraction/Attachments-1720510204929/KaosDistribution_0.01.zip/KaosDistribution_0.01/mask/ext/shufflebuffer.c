/*
 
 [shufflebuffer <count> {<size> {<indices-list>}}]
 
 count = the number of outlets
 size = the size of the buffer, must be 'size >= count'
 indices-list = list of indices into the buffer, number of items on list should match 'count'
 	if indices-list is not given, list is assumed to be 0..count
 
 messages:
 	[reset] - clears the buffer
 	[indices <list>] - used to reset the indices list
	[bang] - output current values
	[float] - adds the float to the buffer
		if buffer is not full, send bang to 'trigger', else do bang
 */
#include "m_pd.h"
#include <math.h>

static char *version = "shufflebuffer v0.5, by Michael McGonagle 2003-2006";

t_class *shufflebuffer_class;

typedef struct _coutlets {
	t_outlet	*out;
} t_coutlets;

typedef struct _shufflebuffer {
	t_object	x_obj;
	t_int		count, size, head, filled;
	t_float		state;
	t_int		*indices;
	t_float		*buffer;
	t_coutlets	*outlets;
	t_outlet	*trigger;
} t_shufflebuffer;

static void shufflebuffer_bang(t_shufflebuffer *sbuf) {
	// if filled, output all values from right to left
	if (sbuf -> state != 0) {
		t_coutlets *out;
		t_int ind, i;
		
		out = &sbuf -> outlets[sbuf -> count - 2];
		
		for (i = sbuf -> count - 1; i > 0; i--, out--) {
			ind = (sbuf -> head + sbuf -> indices[i]) % sbuf -> size;
			outlet_float(out -> out, sbuf -> buffer[ind]);
		}
		ind = (sbuf -> head + sbuf -> indices[i]) % sbuf -> size;
		outlet_float(sbuf -> x_obj.ob_outlet, sbuf -> buffer[ind]);
	}
}

static void shufflebuffer_float(t_shufflebuffer *sbuf, t_floatarg v) {
	// put the value into the buffer
	sbuf -> buffer[sbuf -> head++] = v;
	if (sbuf -> head == sbuf -> size) {
		sbuf -> filled = (sbuf -> filled < 2) ? ++(sbuf -> filled) : 2;
		sbuf -> head = 0;
	}
	// now bang it...
	if (sbuf -> filled > 1) {
		shufflebuffer_bang(sbuf);
	} else {
		outlet_bang(sbuf -> trigger);
	}
}

static void shufflebuffer_reset(t_shufflebuffer *sbuf) {
	sbuf -> head = sbuf -> filled = 0;
}

void shufflebuffer_indices(t_shufflebuffer *sbuf, t_symbol *s, int argc, t_atom *argv) {
	t_int i = 0;
	if (argc != sbuf -> count) {
		post("Incorrect number of arguments. Expecting %d indices.", sbuf -> count);
		return;
	}
	for(i = 0; i < sbuf -> count; i++) {
		sbuf -> indices[i] = (t_int) atom_getfloatarg(i, argc, argv);
		if (sbuf -> indices[i] < 0 || sbuf -> indices[i] >= sbuf -> size) {
			post("index out of range: %d", sbuf -> indices[i]);
		}
	}
}

#define DEALLOC(x, s) if (sbuf -> x != NULL) { freebytes(sbuf -> x, s * sizeof(*sbuf -> x)); }
static void shufflebuffer_free(t_shufflebuffer *sbuf) {
	DEALLOC(indices, sbuf -> count);
	DEALLOC(outlets, sbuf -> count);
	DEALLOC(buffer, sbuf -> size);
}

void *shufflebuffer_new(t_symbol *s, int argc, t_atom *argv) {
	t_shufflebuffer *sbuf = (t_shufflebuffer *)pd_new(shufflebuffer_class);
	t_coutlets *out;
	t_int i;
	
	if (sbuf != NULL) {
		if (argc < 1) {
			shufflebuffer_free(sbuf);
			post("Insufficient arguments to 'shufflebuffer'. Requires size of buffer.");
			return NULL;
		}
		// set count
		sbuf -> count = (t_int) atom_getfloatarg(0, argc, argv);
		// set size from arg, else from count
		if (argc >= 2) {
			sbuf -> size = (t_int) atom_getfloatarg(1, argc, argv);
		} else {
			sbuf -> size = sbuf -> count;
		}
		// create the buffer - the size MUST be > 0
		sbuf -> buffer = (t_float *) getbytes(sbuf -> size * sizeof(*sbuf -> buffer));
		sbuf -> outlets = (t_coutlets *) getbytes((sbuf -> count - 1) * sizeof(*sbuf -> outlets));
		// set the indices
		sbuf -> indices = (t_int *) getbytes(sbuf -> count * sizeof(*sbuf -> indices));
		if (argc > 2) {
			if (sbuf -> count != argc - 2) {
				post("expecting %d indices for creation.", sbuf -> count);
				shufflebuffer_free(sbuf);
				return NULL;
			}
			shufflebuffer_indices(sbuf, NULL, argc - 2, argv + 2);
		} else {
			for(i = 0; i < sbuf -> count; i++) {
				sbuf -> indices[i] = i;
			}
		}
		if (sbuf -> buffer == NULL || sbuf -> outlets == NULL) {
			shufflebuffer_free(sbuf);
			return NULL;
		}
		// setup the 'state' input
		floatinlet_new(&sbuf -> x_obj, &sbuf -> state);
		// setup the output
		outlet_new(&sbuf -> x_obj, &s_float);
		for (i = 0, out = sbuf -> outlets; i < (sbuf -> count - 1); out++, i++) {
			out -> out = outlet_new(&sbuf -> x_obj, &s_float);
		}
		sbuf -> trigger = outlet_new(&sbuf -> x_obj, &s_bang);
		
		shufflebuffer_reset(sbuf);
	}
	return (void *)sbuf;
}

void shufflebuffer_setup(void) {
	post(version);
	
	shufflebuffer_class = class_new(
		gensym("shufflebuffer"),
		(t_newmethod)shufflebuffer_new,
		(t_method)shufflebuffer_free,
		sizeof(t_shufflebuffer),
		CLASS_DEFAULT,
		A_GIMME,
		0
	);
	
	class_addfloat(shufflebuffer_class, shufflebuffer_float);
	class_addbang(shufflebuffer_class, (t_method)shufflebuffer_bang);
	class_addmethod(shufflebuffer_class, (t_method)shufflebuffer_indices, gensym("indices"), A_GIMME, 0);
	class_addmethod(shufflebuffer_class, (t_method)shufflebuffer_reset, gensym("reset"), 0);
	class_sethelpsymbol(shufflebuffer_class, gensym("shufflebuffer-help.pd"));
}
