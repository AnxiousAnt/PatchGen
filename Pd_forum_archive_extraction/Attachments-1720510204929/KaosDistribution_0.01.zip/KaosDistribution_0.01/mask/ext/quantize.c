/*
 * quantize		- inspired by CMask quantize function
 *
 *	signal		- the input signal
 *	grid			- the quantization grid
 *	strength		- the amount of quantization to apply (0 = none, 1 = full)
 *	offset		- the amount of offset to apply
 */
#include "m_pd.h"

static char *version = "quantize v0.5, by Michael McGonagle 2003-2006";

typedef struct quantize {
	t_object	x_obj;
	
	t_float		signal, grid, strength, offset;
	
	t_outlet	*outlet1;
} t_quantize;

static t_class *quantize_class;

static void quantize_float(t_quantize *x, t_floatarg sig) {
	t_float mul, adj;
	
	x -> signal = sig;
	
	if (x -> grid == 0) { x -> grid = .00001; }
	mul = (int)((sig / x -> grid) + .5);
	adj = ((x -> grid * mul) - sig) * x -> strength;
	
	outlet_float(x -> outlet1, (sig + adj + x -> offset));
}

static void quantize_bang(t_quantize *x) {
	quantize_float(x, x -> signal);
}

static void *quantize_new(t_floatarg f_grid, t_floatarg f_strength, t_floatarg f_offset) {
	t_quantize *x = (t_quantize *)pd_new(quantize_class);
	
	if (x != NULL) {
		floatinlet_new(&x -> x_obj, &x -> grid);
		floatinlet_new(&x -> x_obj, &x -> strength);
		floatinlet_new(&x -> x_obj, &x -> offset);
		
		x -> outlet1 = outlet_new(&x -> x_obj, gensym("float"));
		
		// set the defaults from the inputs
		x -> grid = f_grid;
		x -> strength = f_strength;
		x -> offset = f_offset;
		
		x -> signal = 0;
	}
	return (void *)x;
}

void quantize_setup(void) {
	post(version);
	
	quantize_class = class_new(
		gensym("quantize"),
		(t_newmethod)quantize_new,
		0,
		sizeof(t_quantize),
		0,
		A_DEFFLOAT, A_DEFFLOAT, A_DEFFLOAT,
		0
	);
	
	class_addfloat(quantize_class, quantize_float);
	class_addbang(quantize_class, quantize_bang);
	class_sethelpsymbol(quantize_class, gensym("quantize-help.pd"));
}
