#include "m_pd.h"

static char *version = "precision v0.5, by Michael McGonagle 2003-2006";

static t_class *precision_class;

typedef struct _precision {
	t_object	x_obj;
	t_float		signal;		// the current signal
	t_float		multiplier;
} t_precision;

void precision_float(t_precision *x, t_floatarg sig)
{
	t_float mul = x -> multiplier;
	t_float out;
	
	x -> signal = sig;
	if (mul > 0) {
		out = ((int) (sig * x -> multiplier)) / x -> multiplier;
	} else {
		out = (int) sig;
	}
	outlet_float(x -> x_obj.ob_outlet, out);
}

void precision_bang(t_precision *x)
{
	precision_float(x, x -> signal);
}

void *precision_new(void)
{
	t_precision *x = (t_precision *)pd_new(precision_class);
	
	if (x != NULL) {
		floatinlet_new(&x -> x_obj, &x -> multiplier);
		outlet_new(&x -> x_obj, &s_float);
	}
	return (void *)x;
}

void precision_setup(void)
{
	post(version);
	
	precision_class = class_new(
		gensym("precision"),
		(t_newmethod)precision_new,
		0,
		sizeof(t_precision),
		CLASS_DEFAULT, A_DEFFLOAT, A_DEFFLOAT,
		0
	);
	
	class_addbang(precision_class, precision_bang);
	class_addfloat(precision_class, precision_float);
	class_sethelpsymbol(precision_class, gensym("precision-help.pd"));
}
