#include "m_pd.h"

#ifndef __DATE__
#define __DATE__ "without using a gnu compiler"
#endif

typedef struct _masker
{
	t_object x_obj;
} t_masker;

static t_class* masker_class;

/* objects */
extern void accumulator_setup();
extern void ctoh_setup();
extern void htoc_setup();
extern void mask_setup();
extern void quantize_setup();
extern void ranger_setup();
extern void precision_setup();
extern void cbuffer_setup();
extern void inverter_setup();
//extern void split_setup();
extern void shufflebuffer_setup();

static void* masker_new(t_symbol* s)
{
    t_masker *x = (t_masker *)pd_new(masker_class);
    return (x);
}

void masker_setup(void)
{
	masker_class = class_new(
		gensym("masker"),
		(t_newmethod)masker_new,
		0,
		sizeof(t_masker),
		0,
		0
	);
	
	post("-------------------------");
	post("Masker Number Shaping Toolset");
	post("Copyright Michael McGonagle 2003");
	
	accumulator_setup();
	ctoh_setup();
	htoc_setup();
	mask_setup();
	quantize_setup();
	ranger_setup();
	precision_setup();
	cbuffer_setup();
	inverter_setup();
	shufflebuffer_setup();
//	split_setup();
	
	post("-------------------------");
}
