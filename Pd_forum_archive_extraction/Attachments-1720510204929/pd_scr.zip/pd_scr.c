#include <stdio.h>
#include <unistd.h>

int main ()
{
	execl("c:/pd_scr.bat", NULL, NULL);
	return 0;
}
