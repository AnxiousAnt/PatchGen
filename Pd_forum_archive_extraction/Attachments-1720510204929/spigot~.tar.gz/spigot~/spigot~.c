/* spigot~ -- just turn off the output signal when needed */

/*  Copyleft 2001 Yves Degoyon.
Permission is granted to use this software for any purpose provided you
keep this copyright notice intact.

THE AUTHOR AND HIS EXPLOITERS MAKE NO WARRANTY, EXPRESS OR IMPLIED,
IN CONNECTION WITH THIS SOFTWARE.

Use money as toilet paper
and do anything written in those silly notes.

*/

#include "m_pd.h"

typedef struct _spigot
{
    t_object x_obj;
    t_int x_on;
    t_float x_f;
} t_spigot;

static t_class *spigot_class;

static void *spigot_new(void)
{
    t_spigot *x = (t_spigot *)pd_new(spigot_class);
    x->x_on = 1;
    inlet_new(&x->x_obj, &x->x_obj.ob_pd, gensym("float"), gensym("seton") );
    outlet_new(&x->x_obj, &s_signal);
    return (x);
}

static t_int *spigot_perform(t_int *w)
{
    t_float *in = (t_float *)(w[1]);
    t_float *out = (t_float *)(w[2]);
    int n = (int)(w[3]);
    int on = (int)(w[4]);
    while (n--) {
       if ( on==0.0 ) {
          *(out)=0.0;
       } else {
          *(out)=*(in);
       }
       in++;out++;
    }
    return (w+5);
}

static void spigot_dsp(t_spigot *x, t_signal **sp)
{
    dsp_add(spigot_perform, 4, sp[0]->s_vec, sp[1]->s_vec, 
            sp[0]->s_n, x->x_on);
}

static void spigot_set(t_spigot *x, t_float f)
{
    x->x_on=f;
    /* modify the dsp chain : requires pd src patch */
    dsp_mod(spigot_perform, 4, x->x_on);
}

void spigot_tilde_setup(void)
{
    spigot_class = class_new(gensym("spigot~"), (t_newmethod)spigot_new, 0,
    	sizeof(t_spigot), 0, 0);
    CLASS_MAINSIGNALIN( spigot_class, t_spigot, x_f );
    class_addmethod(spigot_class, (t_method)spigot_dsp, gensym("dsp"), 0);
    class_addmethod(spigot_class, (t_method)spigot_set, gensym("seton"), A_FLOAT, 0);
}
