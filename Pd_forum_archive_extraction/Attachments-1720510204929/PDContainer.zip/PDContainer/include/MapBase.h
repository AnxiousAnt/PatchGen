// *********************(c)*2004*********************>
// -holzilib--holzilib--holzilib--holzilib--holzilib->
// ++++PD-External++by+Georg+Holzmann++grh@gmx.at++++>
//
// PDContainer: 
// this is a port of the containers from the C++ STL
// (Standard Template Library)
// for usage see the documentation and PD help files
// for license see readme.txt
//
// MapBase.h

#ifndef _map_base_h__
#define _map_base_h__


#include "include/ContainerBase.h"


//---------------------------------------------------
/* this is the base class of map and multimap
 */
template <class ContainerType, class ContTypeIterator>
class MapBase : public ContainerBase<ContainerType,ContTypeIterator>
{

 private:

  /* Copy Construction is not allowed
   */
  MapBase(const MapBase<ContainerType,ContTypeIterator> &src)
    { }

  /* assignement operator is not allowed
   */
  const MapBase<ContainerType,ContTypeIterator>& operator = 
    (const MapBase<ContainerType,ContTypeIterator>&)
    { }

 public:

  /* Standard Constructor
   * no namespace
   */
  MapBase()
    { }

  /* Destructor
   */
  virtual ~MapBase() { };

  /* Add a key-value pair
   */
  virtual void add(Element key, Element value)
    {  data_[h_namespace_].insert(std::pair<Element,Element>(key,value)); }

  /* Get a value from the specific Key
   */
  virtual Element &get(Element &key) const
    {
      ContTypeIterator iter = data_[h_namespace_].find(key);
      return (*iter).second;
    }

  /* removes a pair with this key
   */
  virtual void remove(const Element &key)
    {  data_[h_namespace_].erase(key); }

  /* prints all the data of the current namespace to the console
   */
  virtual void printAll();

  /* saves all the data of the current namespace to a file
   * Fileformat: 
   * <key_atom_type1> <key_atom1> ... -  <data_atom_type1> <data_atom1> ...
   * e.g.:
   * f 1 f 2 - f 4
   * s foo f 12.34234 - f 3 f 5 s gege
   * types: s=symbol, f=float
   * ATTENTION: if the file exists, all the old data of
   * the file is lost
   * returns true on success
   */
  virtual bool saveToFile(string filename);

  /* reads from an input file and adds the data to
   * the current namespace
   * Fileformat: see saveToFile
   * returns true on success
   */
  virtual bool readFromFile(string filename);
};

//----------------------------------------------------
/* prints all the data of the current namespace to the console
 */
template<class ContainerType, class ContTypeIterator>
void MapBase<ContainerType,ContTypeIterator>::printAll()
{
  ContTypeIterator iter  = data_[h_namespace_].begin();

  post("\n%s: printing namespace %s",dataname_.c_str(),h_namespace_.c_str());
  post("--------------------------------------------------");

  bool data_here = false;
  while(iter != data_[h_namespace_].end())
    {
      ostringstream output("");

      // Key:
      Element key((*iter).first);
      if (key.length > 1)  // list
	{
	  output << "list ";
	  for (int i=0; i < key.length; i++)
	    {
	      if (key.atom[i].a_type == A_FLOAT)
		output << key.atom[i].a_w.w_float << " ";
	      if (key.atom[i].a_type == A_SYMBOL)
		output << key.atom[i].a_w.w_symbol->s_name << " ";
	    }
	}
      else // no list
	{
	  if (key.atom[0].a_type == A_FLOAT)
	    output << "float " << key.atom[0].a_w.w_float << " ";
	  if (key.atom[0].a_type == A_SYMBOL)
	    output << "symbol " 
		   << key.atom[0].a_w.w_symbol->s_name << " ";
	    }
      
      // Value:
      output << "  --  ";
      Element el((*iter).second);
      if (el.length > 1)  // list
	{
	  output << "list ";
	  for (int i=0; i < el.length; i++)
	    {
	      if (el.atom[i].a_type == A_FLOAT)
		output << el.atom[i].a_w.w_float << " ";
	      if (el.atom[i].a_type == A_SYMBOL)
		output << el.atom[i].a_w.w_symbol->s_name << " ";
	    }
	}
      else // no list
	{
	  if (el.atom[0].a_type == A_FLOAT)  // hier segfault nach get !!!
	    output << "float " << el.atom[0].a_w.w_float << " ";
	  if (el.atom[0].a_type == A_SYMBOL)
	    output << "symbol " 
		   << el.atom[0].a_w.w_symbol->s_name << " ";
	}

      post("%s",output.str().c_str());
      data_here = true;
      iter++;
    }
  if(!data_here)
    post("no data in current namespace!");
  post("--------------------------------------------------");
}

//----------------------------------------------------
/* saves all the data of the current namespace to a file
 * Fileformat: 
 * <key_atom_type1> <key_atom1> ... -  <data_atom_type1> <data_atom1> ...
 * e.g.:
 * f 1 f 2 - f 4
 * s foo f 12.34234 - f 3 f 5 s gege
 * types: s=symbol, f=float
 * ATTENTION: if the file exists, all the old data of
 * the file is lost
 * returns true on success
 */
template<class ContainerType, class ContTypeIterator>
bool MapBase<ContainerType,ContTypeIterator>::saveToFile(string filename)
{
  ofstream outfile;
  ContTypeIterator iter  = data_[h_namespace_].begin();

  outfile.open(filename.c_str());

  if(!outfile)
    return false;

  while(iter != data_[h_namespace_].end())
    {
      // add Key:  
      Element key((*iter).first);

      for (int i=0; i < key.length; i++)
	{
	  if (key.atom[i].a_type == A_FLOAT)
	    outfile << "f " << key.atom[i].a_w.w_float << " ";
	  if (key.atom[i].a_type == A_SYMBOL)
	    outfile << "s " << key.atom[i].a_w.w_symbol->s_name << " ";
	}

      outfile << "- ";

      // add Value:
      Element el((*iter).second);
	     
      for (int i=0; i < el.length; i++)
	{
	  if (el.atom[i].a_type == A_FLOAT)
	    outfile << "f " << el.atom[i].a_w.w_float << " ";
	  if (el.atom[i].a_type == A_SYMBOL)
	    outfile << "s " << el.atom[i].a_w.w_symbol->s_name << " ";
	}
      
      outfile << endl;
      iter++;
    }

  outfile.close();

  return true;
}

//----------------------------------------------------
/* reads the data from the file into the current
 * namespace
 * Fileformat: see saveToFile
 * returns true on success
 */
template<class ContainerType, class ContTypeIterator>
bool MapBase<ContainerType,ContTypeIterator>::readFromFile(string filename)
{
  ifstream infile;
  infile.open(filename.c_str());

  if(!infile)
      return false;

  Element key;
  Element el;

  string line;
  bool go_on = false;
  char type;
  string symbol;
  t_float number;
  int key_count, val_count;

  while (getline(infile, line))
    {
      // first parse the instream, to get the number of atoms
      // (= length of the elements)

      istringstream instream(line);
      ostringstream key_str("");
      ostringstream value_str("");

      // Key:
      go_on = false; key_count = 0;
      while(!go_on)
	{
	  instream >> type;
	  if (type == 's')
	    {
	      key_count++;
	      instream >> symbol;
	      key_str << "s " << symbol;
	    }
	  if (type == 'f')
	    {
	      key_count++;
	      instream >> number;
	      key_str << "f " << number;
	    }
	  if (type == '-')
	    go_on = true;
	  key_str << " ";
	}

      // Value:
      go_on = false; val_count = 0;
      while(!go_on)
	{
	  instream >> type;
	  if (instream.eof())
	    {
	      go_on = true;
	      break;
	    }
	  if (type == 's')
	    {
	      val_count++;
	      instream >> symbol;
	      value_str << "s " << symbol;
	    }
	  if (type == 'f')
	    {
	      val_count++;
	      instream >> number;
	      value_str << "f " << number;
	    }
	  if (instream.eof())
	    go_on = true;
	  value_str << " ";
	}


      // now make the key and value objects, parse again the data
      // into the objects and add them to the container

      // Key:

      t_atom *key_atom = new t_atom[key_count];
      t_atom *val_atom = new t_atom[val_count];
      if(key_atom == NULL || val_atom == NULL)
	post("Fatal Error Out Of Memory (%s-readFromFile)",dataname_.c_str());

      istringstream key_istr(key_str.str());
      istringstream value_istr(value_str.str());

      for(int i = 0; i < key_count; i++)
	{
	  key_istr >> type;
	  if (type == 's')
	    {
	      key_istr >> symbol;
	      SETSYMBOL(&key_atom[i],gensym(const_cast<char*>(symbol.c_str())));
	    }
	  if (type == 'f')
	    {
	      key_istr >> number;
	      SETFLOAT(&key_atom[i],number);
	    }
	}

      for(int i = 0; i < val_count; i++)
	{
	  value_istr >> type;
	  if (type == 's')
	    {
	      value_istr >> symbol;
	      SETSYMBOL(&val_atom[i],gensym(const_cast<char*>(symbol.c_str())));
	    }
	  if (type == 'f')
	    {
	      value_istr >> number;
	      SETFLOAT(&val_atom[i],number);
	    }
	}

      key.length = key_count;
      key.atom = (t_atom*)copybytes(key_atom, key_count * sizeof(t_atom));

      el.length = val_count;
      el.atom = (t_atom*)copybytes(val_atom, val_count * sizeof(t_atom));

      // insert the data
      data_[h_namespace_].insert(std::pair<Element,Element>(key,el));

      delete[] key_atom;
      delete[] val_atom;
    }

  infile.close();

  return true;
}



#endif  // _map_base_h__
