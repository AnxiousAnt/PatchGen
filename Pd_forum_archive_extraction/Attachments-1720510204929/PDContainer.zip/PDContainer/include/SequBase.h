// *********************(c)*2004*********************>
// -holzilib--holzilib--holzilib--holzilib--holzilib->
// ++++PD-External++by+Georg+Holzmann++grh@gmx.at++++>
//
// PDContainer: 
// this is a port of the containers from the C++ STL
// (Standard Template Library)
// for usage see the documentation and PD help files
// for license see readme.txt
//
// SequBase.h

#ifndef _sequ_base_h__
#define _sequ_base_h__


#include "include/SimpleBase.h"


//---------------------------------------------------
/* this is the base class of vector and deque
 */
template <class ContainerType, class ContTypeIterator>
class SequBase : public SimpleBase<ContainerType,ContTypeIterator>
{

 private:

  /* Copy Construction is not allowed
   */
  SequBase(const SequBase<ContainerType,ContTypeIterator> &src)
    { }

  /* assignement operator is not allowed
   */
  const SequBase<ContainerType,ContTypeIterator>& operator = 
    (const SequBase<ContainerType,ContTypeIterator>&)
    { }

 public:

  /* Standard Constructor
   * no namespace
   */
  SequBase()
    { }

  /* Destructor
   */
  virtual ~SequBase() { };

  /* change the element at the index
   */
  virtual void set(int index, Element value) 
    {  data_[h_namespace_][index] = value;  }

  /* get the element from the index
   */
  virtual Element &get(int index) const 
    {  return data_[h_namespace_][index]; }

  /* resize the sequence
   */
  virtual void resize(int size)
    {  data_[h_namespace_].resize(size);  }

  /* get the size of the sequence
   */
  virtual int getSize() const
    {  return data_[h_namespace_].size();  }

  /* inserts an element at the end of 
   * the container (so then the size
   * increases by one !!!)
   */
  virtual void pushBack(Element value)
    {  data_[h_namespace_].push_back(value);  }

  /* removes the element from the end of 
   * the container (so then the size
   * decreases by one !!!)
   */
  virtual void popBack()
    {  data_[h_namespace_].pop_back();  }

  /* returns the last element
   */
  virtual Element &back() const 
    {  return data_[h_namespace_].back(); }

  /* returns the first element
   */
  virtual Element &front() const 
    {  return data_[h_namespace_].front(); }

  /* inserts an element before the element
   * with the given index
   */
  virtual void insert(int index, Element value)
    {  data_[h_namespace_].insert(data_[h_namespace_].begin()+index, value);  }

  /* removes the element with that index from the
   * container
   */
  virtual void remove(int index)
    {  data_[h_namespace_].erase(data_[h_namespace_].begin()+index);  }

  /* reads from an input file and adds the data to
   * the current namespace
   * Fileformat: see saveToFile
   * index: inserts the data starting with this index
   * returns true on success
   */
  virtual bool readFromFile2(string filename, int index);
};


//----------------------------------------------------
/* reads the data from the file into the current
 * namespace
 * Fileformat: see saveToFile
 * index: inserts the data starting with this index
 * returns true on success
 */
template<class ContainerType, class ContTypeIterator>
bool SequBase<ContainerType,ContTypeIterator>::readFromFile2(string filename, int index)
{
  ifstream infile;
  infile.open(filename.c_str());

  if(!infile)
      return false;

  Element key;

  string line;
  bool go_on = false;
  char type;
  string symbol;
  t_float number;
  int key_count;
  int max_index = data_[h_namespace_].size();

  while (getline(infile, line))
    {
      // first parse the instream, to get the number of atoms
      // (= size of the list)

      if(index < 0 || index >= max_index)
	{
	  post("%s, read: wrong index !!",dataname_.c_str());
	  return true;
	}

      istringstream instream(line);
      ostringstream key_str("");
      
      go_on = false; key_count = 0;
      while(!go_on)
	{
	  instream >> type;
	  if (instream.eof())
	    {
	      go_on = true;
	      break;
	    }
	  if (type == 's')
	    {
	      key_count++;
	      instream >> symbol;
	      key_str << "s " << symbol;
	    }
	  if (type == 'f')
	    {
	      key_count++;
	      instream >> number;
	      key_str << "f " << number;
	    }
	  if (instream.eof())
	    go_on = true;
	  key_str << " ";
	}

      // now objects, parse again the data
      // into the objects and add them to the container

      t_atom *key_atom = new t_atom[key_count];
      if(key_atom == NULL)
	post("Fatal Error Out Of Memory (%s-readFromFile)",dataname_.c_str());

      istringstream key_istr(key_str.str());
 
      for(int i = 0; i < key_count; i++)
	{
	  key_istr >> type;
	  if (type == 's')
	    {
	      key_istr >> symbol;
	      SETSYMBOL(&key_atom[i],gensym(const_cast<char*>(symbol.c_str())));
	    }
	  if (type == 'f')
	    {
	      key_istr >> number;
	      SETFLOAT(&key_atom[i],number);
	    }
	}

      key.length = key_count;
      key.atom = (t_atom*)copybytes(key_atom, key_count * sizeof(t_atom));

      // insert the data
      data_[h_namespace_][index] = key;
      index++;
      
      delete[] key_atom;
    }

  infile.close();

  return true;
}



#endif //_sequ_base_h__
