#include "m_pd.h"
#include <math.h>

t_class *fcount_class;

typedef struct _fcount
{
  t_object x_obj;
  t_float fcount, prev, remainder, step, sign, low, high, range;
  t_int f_int, init, signchange;
  t_outlet *count, *icount, *remain, *isign, *wrapped;
} t_fcount;

void fcount_float(t_fcount *y, t_floatarg f)
{
  y->init = 0;
  y->fcount = f;
}

void fcount_bang(t_fcount *y)
{
  if(y->init)
    {
      y->fcount = y->low;
      y->init = 0;
    }
  if (y->signchange == 0)
    {
      if (y->fcount < y->low)
	{
	  y->fcount = y->fcount + y->high - y->low;
	  outlet_bang(y->wrapped);
	}
      else if (y->fcount >= y->high)
	{
	  y->fcount = y->fcount - y->high + y->low;
	  outlet_bang(y->wrapped);
	}
      y->f_int = (int)y->fcount;
      y->remainder = y->high - y->fcount;
      outlet_float(y->isign, y->sign);
      outlet_float(y->remain, y->remainder);
      outlet_float(y->icount, (float)y->f_int);
      outlet_float(y->count, y->fcount);
      y->prev = y->fcount;
      y->fcount += y->step;
    }
  else if (y->signchange == 1)
    {
      y->fcount = y->prev + y->step;
      if (y->fcount < y->low)
	{
	  y->fcount = y->fcount + y->high - y->low;
	  outlet_bang(y->wrapped);
	}
      else if (y->fcount >= y->high)
	{
	  y->fcount = y->fcount - y->high + y->low;
	  outlet_bang(y->wrapped);
	}
      y->f_int = (int)y->fcount;
      y->remainder = y->high - y->fcount;
      outlet_float(y->isign, y->sign);
      outlet_float(y->remain, y->remainder);
      outlet_float(y->icount, (float)y->f_int);
      outlet_float(y->count, y->fcount);
      y->signchange = 0;
      y->prev = y->fcount;
      y->fcount += y->step;
    }
}

void fcount_setbang(t_fcount *y, t_floatarg f)
{
  y->fcount = f;
  y->f_int = (int)f;
  y->remainder = y->high - y->fcount;
  outlet_float(y->remain, y->remainder);
  outlet_float(y->icount, (float)y->f_int);
  outlet_float(y->count, y->fcount);
  y->fcount += y->step;
}

void fcount_step(t_fcount *y, t_floatarg f)
{
  y->step = f != 0 ? f : 1;
  float oldsign = y->sign;
  y->sign = y->step > 0 ? 1 : -1;
  if(y->sign != oldsign)
    {
      y->signchange = 1;
    }
  while(y->range != 0 && fabs(y->step) > y->range)
    {
      y->step = (fabs(y->step) - y->range)* y->sign;
    }
}

void fcount_high(t_fcount *y, t_floatarg f)
{
  float flow = y->low;
  float fhigh = f;
  if (flow > fhigh) {
    y->high = flow;
    y->low  = fhigh;
  }
  else {
    y->high = fhigh;
    y->low = flow;
  }
  y->range = y->high - y->low;
  while(y->range != 0 && fabs(y->step) > y->range)
    {
      y->step = (fabs(y->step) - y->range)* y->sign;
    }
}

void fcount_low(t_fcount *y, t_floatarg f)
{
  float flow = f;
  float fhigh = y->high;
  if (flow > fhigh) {
    y->high = flow;
    y->low  = fhigh;
  }
  else {
    y->high = fhigh;
    y->low = flow;
  }
  y->range = y->high - y->low;
  while(y->range != 0 && fabs(y->step) > y->range)
    {
      y->step = (fabs(y->step) - y->range)* y->sign;
    }
}

// creation arguments: stepsize, highlimit, lowlimit, startvalue
void *fcount_new(t_symbol *s, int argc, t_atom *argv)
{
  float flow, fhigh, fstep;
  t_fcount *y = (t_fcount *)pd_new(fcount_class);
  y->init = 1;
  if (argc>3)
    {
      fstep = atom_getfloat(argv);
      fhigh = atom_getfloat(argv+1);
      flow  = atom_getfloat(argv+2);
      y->step = fstep != 0 ? fstep : 1;
      y->sign = y->step > 0 ? 1 : -1;
      if (flow > fhigh) {
	y->high = flow;
	y->low  = fhigh;
      }
      else {
	y->high = fhigh;
	y->low = flow;
      }
      y->range = y->high - y->low;
      y->fcount = atom_getfloat(argv+3);
      y->init = 0;
    }
  else if (argc>2)
    {
      fstep = atom_getfloat(argv);
      fhigh = atom_getfloat(argv+1);
      flow  = atom_getfloat(argv+2);
      y->step = fstep != 0 ? fstep : 1;
      y->sign = y->step > 0 ? 1 : -1;
      if (flow > fhigh) {
	y->high = flow;
	y->low  = fhigh;
      }
      else {
	y->high = fhigh;
	y->low = flow;
      }
      y->range = y->high - y->low;
      y->fcount = y->low;
      y->init = 0;
    }
  else if (argc>1)
    {
      fstep = atom_getfloat(argv);
      fhigh = atom_getfloat(argv+1);
      y->step = fstep != 0 ? fstep : 1;
      y->sign = y->step > 0 ? 1 : -1;
      if (fhigh < 0) {
	y->high = 0;
	y->low  = fhigh;
      }
      else {
	y->high = fhigh;
	y->low = 0;
      }
      y->fcount = 0;
    }
  else if (argc)
    {
      fstep = atom_getfloat(argv);
      y->step = fstep != 0 ? fstep : 1;
      y->sign = y->step > 0 ? 1 : -1;
      y->high = 100;
      y->low  = 0;
      y->range = 100;
      y->fcount = 0;
    }
  else
    {
      y->step = 1;
      y->sign = 1;
      y->high = 100;
      y->low  = 0;
      y->range = 100;
      y->fcount = 0;
    }
  y->count = outlet_new(&y->x_obj, gensym("float"));
  y->icount = outlet_new(&y->x_obj, gensym("float"));
  y->remain = outlet_new(&y->x_obj, gensym("float"));
  y->isign = outlet_new(&y->x_obj, gensym("float"));
  y->wrapped = outlet_new(&y->x_obj, gensym("bang"));
  return(void *)y;
}

void fcount_setup(void) 
{
  fcount_class = class_new(gensym("fcount"),
  (t_newmethod)fcount_new,
  0, sizeof(t_fcount),
  0, A_GIMME, 0);
  post("fcount counts floats _.");
  class_addbang(fcount_class, fcount_bang);
  class_addfloat(fcount_class, fcount_float);
  class_addmethod(fcount_class, (t_method)fcount_setbang, gensym("setbang"), A_DEFFLOAT, 0);
  class_addmethod(fcount_class, (t_method)fcount_step, gensym("step"), A_DEFFLOAT, 0);
  class_addmethod(fcount_class, (t_method)fcount_high, gensym("high"), A_DEFFLOAT, 0);
  class_addmethod(fcount_class, (t_method)fcount_low, gensym("low"), A_DEFFLOAT, 0);
}
