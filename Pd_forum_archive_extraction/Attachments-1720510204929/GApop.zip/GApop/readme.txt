GApop - genetic algorithm for PD and MAX/MSP Vers 0.0.1

Copyright (c)Georg Holzmann <grh@gmx.at>
For information on usage and redistribution, and for a DISCLAIMER OF ALL
WARRANTIES, see the file, "license.txt," in this distribution.  


----------------------------------------------------------------------------

You will need the flext C++ layer for PD and Max/MSP externals to compile this.
see http://www.parasitaere-kapazitaeten.net/ext

----------------------------------------------------------------------------

I only compiled GApop in Windows with MSVC 6 for PD, but it should also work with
flext in Linux or macOS.

For help and documantation see the PD help file "help-GApop.pd" in this distribution.
