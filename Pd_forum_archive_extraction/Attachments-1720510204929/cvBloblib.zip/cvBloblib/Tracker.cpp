// Include files
#include <stdlib.h>
// OpenCV
#include <cv.h>
#include <cxcore.h>
#include <highgui.h>
// Blobs
#include <Blob.h>
#include <BlobResult.h>


// delcare an image
	IplImage *frame = 0;
	IplImage *bw_frame = 0;
	CvCapture* movie_capture = 0;
	
//capture image
int main(int argc, char *argv[] )
	{
	char ch = 0;
	movie_capture=cvCaptureFromFile(argv[1]);
	while(ch != 'e')
	{
	
	if(!movie_capture) {
	printf("Cannot open avi file %s\n",argv[1]);
	exit(0);
	}
	
	if(!cvGrabFrame(movie_capture)) {
	printf("Cannot grab a frame\n");
	exit(0);
	}
	
	{
//turn movie to frame and process a version to black and white.
//blobslib only likes an 8 bit 1 channel image.
	frame = cvQueryFrame(movie_capture);
	bw_frame = cvCreateImage(cvSize(frame->width,frame->height), IPL_DEPTH_8U, 1);
	cvCvtColor(frame, bw_frame, CV_BGR2GRAY);
	{

	}
	
	// FIND AND MARK THE BLOBS
	// delcare a set of blob results
	CBlobResult blobs;
	// get the blobs from the image, with no mask, using a threshold of 100
	blobs = CBlobResult( bw_frame, NULL, 100, false );
	blobs.Filter( blobs, B_INCLUDE, CBlobGetArea(), B_LESS, 5000 );// area <150
	blobs.Filter( blobs, B_INCLUDE, CBlobGetArea(), B_GREATER, 0 );// area <150
	//blobs.Filter( blobs, B_EXCLUDE, CBlobGetArea(), B_INSIDE, 2, 1 );
	// mark the blobs on the image
	int i;
	// delare a single blob
	CBlob Blob;
	// some vars
	int iMaxx, iMinx, iMaxy, iMiny, iMeanx, iMeany;
	// for each blob
	for  (i=0; i<blobs.GetNumBlobs(); i++)
	{
		// get the blob info
		Blob = blobs.GetBlob(i);
		// get max, and min co-ordinates
		iMaxx=Blob.MaxX();
		iMinx=Blob.MinX();
		iMaxy=Blob.MaxY();
		iMiny=Blob.MinY();
		// find the average of the blob (i.e. estimate its centre)
		iMeanx=(iMinx+iMaxx)/2;
		iMeany=(iMiny+iMaxy)/2;
		// print blob info
		printf("%d (%d,%d)", i, iMeanx, iMeany);

		// get blob centres
		//CBlobGetXCenter getXc;
		//CBlobGetYCenter getYc;
		//double blobCentre[2];
		//blobCentre[0] = getXc(Blob);
		//blobCentre[1] = getYc(Blob);
		//printf("\n\t\tCentre: (%.0f,%.0f)", blobCentre[0], blobCentre[1]);


	// mark centre
		cvLine( frame, cvPoint(iMeanx, iMeany), cvPoint(iMeanx, iMeany), CV_RGB(150, 150 , 150), 4, 8, 0 );
	// mark box around blob
		cvRectangle( frame, cvPoint(iMinx , iMiny ), cvPoint ( iMaxx, iMaxy ), CV_RGB(250, 0, 0), 1, 8, 0 );
		
	}
	
// display the image
	cvNamedWindow("image",CV_WINDOW_AUTOSIZE);
	cvShowImage("image",frame);
// keep image 'til keypress
	ch=cvWaitKey(20);
	//cvReleaseImage(&frame);

}}