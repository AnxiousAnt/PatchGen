#include "m_pd.h"
static t_class *allpass_tilde_class;


typedef struct _allpass_tilde 
{
  t_object  x_obj;
  t_sample f_looptime;
  t_sample f_gain;
  t_sample f;
  float *del;
  int rpointer;
  int wpointer;
  
} t_allpass_tilde;

t_int *allpass_tilde_perform(t_int *w)
{
  int i;
  float output ;
  t_allpass_tilde *x =  (t_allpass_tilde *)(w[1]);
  t_sample  *in1   =       (t_sample *)(w[2]);
  t_sample  *out   =       (t_sample *)(w[3]);
  int size		   =	          (int)(w[4]);
  int delsize=(int)x->f_looptime*44.1;
  for(i=0;i<size;i++)
  {
  x->rpointer++;	 
  while(x->rpointer<0)
	  x->rpointer+=delsize;
  while(x->rpointer>=delsize)
	  x->rpointer-=delsize;

  x->wpointer = x->rpointer-1;
  while(x->wpointer<0)
	  x->wpointer+=delsize;
  while(x->wpointer>=delsize)
	  x->wpointer-=delsize;


  output = x->del[x->rpointer]+in1[i]*-x->f_gain/100;
  x->del[x->wpointer]=(output*x->f_gain/100)+in1[i]; 
  out[i]= output;				    
      	
  }
	return (w+5);
}


void allpass_tilde_dsp(t_allpass_tilde *x, t_signal **sp)
{
  dsp_add(allpass_tilde_perform, 4, x, sp[0]->s_vec, sp[1]->s_vec, sp[0]->s_n);
}


void allpass_tilde_free(t_allpass_tilde *x)
{
	freebytes(x->del, 88200);
}

void *allpass_tilde_new(t_floatarg f)
{
  
  t_allpass_tilde *x = (t_allpass_tilde *)pd_new(allpass_tilde_class);
  x->f_looptime = f = 1;
  floatinlet_new (&x->x_obj, &x->f_looptime);
  floatinlet_new (&x->x_obj, &x->f_gain);
  outlet_new(&x->x_obj, &s_signal);
  x->del = (float *)getbytes(sizeof(float)*88200);
  x->rpointer=0;
  x->wpointer=0;
  x->f_gain=0.1;	  

  return (void *)x;
}

void allpass_setup(void)
{
	 post("\nAllpass Filter");
	 post("Rory Walsh Jan 2002");
  allpass_tilde_class = class_new(gensym("allpass~"),
  (t_newmethod)allpass_tilde_new,
   (t_method)allpass_tilde_free, sizeof(t_allpass_tilde), 
        CLASS_DEFAULT,  A_DEFFLOAT, 0);
  class_addmethod(allpass_tilde_class,
        (t_method)allpass_tilde_dsp, gensym("dsp"), 0);
  CLASS_MAINSIGNALIN(allpass_tilde_class, t_allpass_tilde, f);

}

