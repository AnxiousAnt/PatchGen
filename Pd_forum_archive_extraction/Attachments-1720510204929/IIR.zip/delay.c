#include "m_pd.h"
static t_class *delay_tilde_class;


typedef struct _delay_tilde 
{
  t_object  x_obj;
  t_sample f_delay;
  t_sample f;
//  float a;  //reminder to change the f_delay to the freebytes thing
  float *del; // if i dont free up the bytes it crashes
  int rpointer;
  int wpointer;

} t_delay_tilde;

t_int *delay_tilde_perform(t_int *w)
{
  int i;
  t_delay_tilde *x =  (t_delay_tilde *)(w[1]);
  t_sample  *in1   =       (t_sample *)(w[2]);
  t_sample  *out   =       (t_sample *)(w[3]);
  int size		   =	          (int)(w[4]);
  for(i=0;i<size;i++,x->rpointer++, x->wpointer++)
  {
	
	  x->del[(x->wpointer-1)%((int)x->f_delay*44)]=in1[i];  
	  out[i]=x->del[(x->rpointer)%((int)x->f_delay*44)];   
  }
	return (w+5);
}

void delay_tilde_dsp(t_delay_tilde *x, t_signal **sp)
{
  dsp_add(delay_tilde_perform, 4, x, sp[0]->s_vec, sp[1]->s_vec, sp[0]->s_n);
}


void delay_tilde_free(t_delay_tilde *x)
{
	freebytes(x->del, x->f_delay*44);
}

void *delay_tilde_new(t_floatarg f)
{
  
  t_delay_tilde *x = (t_delay_tilde *)pd_new(delay_tilde_class);
  x->f_delay = f;
//  floatinlet_new (&x->x_obj, &x->f_delay);
  outlet_new(&x->x_obj, &s_signal);
  x->del = (float *)getbytes(sizeof(float)*x->f_delay*44); //x->f_delay?
  return (void *)x;
}

void delay_setup(void)
{
  post("\n***************************************");
	post("* Delay~ object written and compiled  *");
	post("* by Rory Walsh. Jan 02.              *");
	post("* Simply type the length of the delay *");
	post("* in millisec's after 'delay~'        *");
	post("***************************************");
  delay_tilde_class = class_new(gensym("delay~"),
  (t_newmethod)delay_tilde_new,
   (t_method)delay_tilde_free, sizeof(t_delay_tilde), 
        CLASS_DEFAULT,  A_DEFFLOAT, 0);
  class_addmethod(delay_tilde_class,
        (t_method)delay_tilde_dsp, gensym("dsp"), 0);
  CLASS_MAINSIGNALIN(delay_tilde_class, t_delay_tilde, f);
}

