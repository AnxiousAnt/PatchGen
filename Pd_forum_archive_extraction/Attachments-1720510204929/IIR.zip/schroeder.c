#include "m_pd.h"
static t_class *schroeder_tilde_class;

#define msec  44.1  //millisecond
#define gain  (pow(0.001, delsize1/x->f_revtime/1000))
typedef struct _schroeder_tilde 
{
  t_object  x_obj;
  t_sample f_looptime;
  t_sample f_revtime;
  t_sample f;
  float *del1;
  float *del2;
  float *del3;
  float *del4;
  float *del5;
  float *del6;

  int rpointer1;
  int wpointer1;
  int rpointer2;
  int wpointer2;
  int rpointer3;
  int wpointer3;
  int rpointer4;
  int wpointer4;
  int rpointer5;
  int wpointer5;
  int rpointer6;
  int wpointer6;  
  
} t_schroeder_tilde;

t_int *schroeder_tilde_perform(t_int *w)
{
  int i;
  float output1=0, output2=0, output3=0, output4=0, output5=0, output6=0;
  t_schroeder_tilde *x =  (t_schroeder_tilde *)(w[1]);
  t_sample  *in1   =       (t_sample *)(w[2]);
  t_sample  *out   =       (t_sample *)(w[3]);
  int size		   =	          (int)(w[4]);
	int delsize1= 1309.77;//29.7*msec;
	int delsize2= 1636.11;//37.1*msec;
	int delsize3= 1944.81;//41.1*msec;
	int delsize4= 1909.69;//43.7*msec;
	int delsize5= 220.5;  //5*msec;
	int delsize6= 74.97;  //1.7*msec;
	float combine;

float gain1 = (pow(0.001, delsize1/x->f_revtime/441.0));
float gain2 = (pow(0.001, delsize2/x->f_revtime/441.0));
float gain3 = (pow(0.001, delsize3/x->f_revtime/441.0));
float gain4 = (pow(0.001, delsize4/x->f_revtime/441.0));
float gain5 = (pow(0.001, delsize5/96.83/1000));
float gain6 = (pow(0.001, delsize6/32.93/1000));


  for(i=0;i<size;i++)
  {
  x->rpointer1++; 
  while(x->rpointer1<0)
	  x->rpointer1+=delsize1;
  while(x->rpointer1>=delsize1)
	  x->rpointer1-=delsize1;

  x->wpointer1 = x->rpointer1-1;
  while(x->wpointer1<0)
	  x->wpointer1+=delsize1;
  while(x->wpointer1>=delsize1)
	  x->wpointer1-=delsize1;
/***************************************/
  x->rpointer2++; 
  while(x->rpointer2<0)	  x->rpointer2+=delsize2;
  while(x->rpointer2>=delsize2)	  x->rpointer2-=delsize2;

  x->wpointer2 = x->rpointer2-1;
  while(x->wpointer2<0)	  x->wpointer2+=delsize2;
  while(x->wpointer2>=delsize2)	  x->wpointer2-=delsize2;
/***************************************/
  x->rpointer3++; 
  while(x->rpointer3<0)	  x->rpointer3+=delsize3;
  while(x->rpointer3>=delsize3)	  x->rpointer3-=delsize3;

  x->wpointer3 = x->rpointer3-1;
  while(x->wpointer3<0)	  x->wpointer3+=delsize3;
  while(x->wpointer3>=delsize3)	  x->wpointer3-=delsize3;
/***************************************/
  x->rpointer4++; 
  while(x->rpointer4<0)	  x->rpointer4+=delsize4;
  while(x->rpointer4>=delsize4)	  x->rpointer4-=delsize4;

  x->wpointer4 = x->rpointer4-1;
  while(x->wpointer4<0)	  x->wpointer4+=delsize4;
  while(x->wpointer4>=delsize4)	  x->wpointer4-=delsize4;
/***************************************/
  x->rpointer5++; 
  while(x->rpointer5<0)	  x->rpointer5+=delsize5;
  while(x->rpointer5>=delsize5)	  x->rpointer5-=delsize5;

  x->wpointer5 = x->rpointer5-1;
  while(x->wpointer5<0)	  x->wpointer5+=delsize5;
  while(x->wpointer5>=delsize5)	  x->wpointer5-=delsize5;
/***************************************/
  x->rpointer6++; 
  while(x->rpointer6<0)	  x->rpointer6+=delsize6;
  while(x->rpointer6>=delsize6)	  x->rpointer6-=delsize6;

  x->wpointer6 = x->rpointer6-1;
  while(x->wpointer6<0)	  x->wpointer6+=delsize6;
  while(x->wpointer6>=delsize6)	  x->wpointer6-=delsize6;

  /**************Comb1*******************/
  output1 = x->del1[x->rpointer1];
  x->del1[x->wpointer1]=(output1*gain1)+in1[i];
  
  /**************Comb2*******************/
  output2 = x->del2[x->rpointer2];
  x->del2[x->wpointer2]=(output2*gain2)+in1[i];
  
  /**************Comb3*******************/
  output3 = x->del3[x->rpointer3];
  x->del3[x->wpointer3]=(output3*gain3)+in1[i]; 

  /**************Comb4*******************/
  output4 = x->del4[x->rpointer4];
  x->del4[x->wpointer4]=(output4*gain4)+in1[i];
    
  combine=output1+output2+output3+output4;
  
  /**************Allpass1****************/
  output5 = x->del5[x->rpointer5]+combine*-gain5;
  x->del5[x->wpointer5]=(output5*gain5)+combine; 
  
  /**************Allpass2****************/
  output6 = x->del6[x->rpointer6]+output5*-gain6;
  x->del6[x->wpointer6]=(output6*gain6)+output5; 

/*  output = x->del[x->rpointer]+in1[i]*-x->f_gain/100;
  x->del[x->wpointer]=(output*x->f_gain/100)+in1[i]; 
  
  output4 = x->del[x->rpointer4];
  x->del[x->wpointer4]=(output4*.7)+in1[i]; */


  /**************Outsignal***************/
  out[i]= output1;				    
    	
  }
	return (w+5);
}


void schroeder_tilde_dsp(t_schroeder_tilde *x, t_signal **sp)
{
  dsp_add(schroeder_tilde_perform, 4, x, sp[0]->s_vec, sp[1]->s_vec, sp[0]->s_n);
}


void schroeder_tilde_free(t_schroeder_tilde *x)
{
	freebytes(x->del1, 88200);
		freebytes(x->del2, 88200);
			freebytes(x->del3, 88200);
				freebytes(x->del4, 88200);
					freebytes(x->del5, 88200);
						freebytes(x->del6, 88200);
}

void *schroeder_tilde_new(t_floatarg f)
{
  
  t_schroeder_tilde *x = (t_schroeder_tilde *)pd_new(schroeder_tilde_class);
  x->f_looptime = f = 1;
//  floatinlet_new (&x->x_obj, &x->f_looptime);
  floatinlet_new (&x->x_obj, &x->f_revtime);
  outlet_new(&x->x_obj, &s_signal);
  x->del1 = (float *)getbytes(sizeof(float)*88200);
  x->del2 = (float *)getbytes(sizeof(float)*88200);
  x->del3 = (float *)getbytes(sizeof(float)*88200);
  x->del4 = (float *)getbytes(sizeof(float)*88200);
  x->del5 = (float *)getbytes(sizeof(float)*88200);
  x->del6 = (float *)getbytes(sizeof(float)*88200);

  x->rpointer1=0;
  x->wpointer1=0;
  x->rpointer2=0;
  x->wpointer2=0;
  x->rpointer3=0;
  x->wpointer3=0;
  x->rpointer4=0;
  x->wpointer4=0;
  x->rpointer5=0;
  x->wpointer5=0;
  x->rpointer6=0;
  x->wpointer6=0;
  x->f_revtime=0.1;	  

  return (void *)x;
}

void schroeder_setup(void)
{
	 post("\nReverb Unit based on the Schroeder Model");
	 post("Rory Walsh Jan 2002");
  schroeder_tilde_class = class_new(gensym("schroeder~"),
  (t_newmethod)schroeder_tilde_new,
   (t_method)schroeder_tilde_free, sizeof(t_schroeder_tilde), 
        CLASS_DEFAULT,  A_DEFFLOAT, 0);
  class_addmethod(schroeder_tilde_class,
        (t_method)schroeder_tilde_dsp, gensym("dsp"), 0);
  CLASS_MAINSIGNALIN(schroeder_tilde_class, t_schroeder_tilde, f);

}
