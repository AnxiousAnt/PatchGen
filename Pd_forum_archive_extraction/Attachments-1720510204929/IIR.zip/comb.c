#include "m_pd.h"
static t_class *comb_tilde_class;


typedef struct _comb_tilde 
{
  t_object  x_obj;
  t_sample f_looptime;
  t_sample f_revtime;
  t_sample f;
  float *del;
  int rpointer;
  int wpointer;
  
} t_comb_tilde;

t_int *comb_tilde_perform(t_int *w)
{
  int i;
  float output ;
  t_comb_tilde *x =  (t_comb_tilde *)(w[1]);
  t_sample  *in1   =       (t_sample *)(w[2]);
  t_sample  *out   =       (t_sample *)(w[3]);
  int size		   =	          (int)(w[4]);
  int delsize=(int)x->f_looptime*44.1;
  for(i=0;i<size;i++)
  {
  x->rpointer++;	 
  while(x->rpointer<0)
	  x->rpointer+=delsize;
  while(x->rpointer>=delsize)
	  x->rpointer-=delsize;

  x->wpointer = x->rpointer-1;
  while(x->wpointer<0)
	  x->wpointer+=delsize;
  while(x->wpointer>=delsize)
	  x->wpointer-=delsize;

  output = x->del[x->rpointer];
  x->del[x->wpointer]=output*(pow(0.001, x->f_looptime/x->f_revtime/1000))+in1[i]; 
  out[i]= output;				    
      	
  }
	return (w+5);
}


void comb_tilde_dsp(t_comb_tilde *x, t_signal **sp)
{
  dsp_add(comb_tilde_perform, 4, x, sp[0]->s_vec, sp[1]->s_vec, sp[0]->s_n);
}


void comb_tilde_free(t_comb_tilde *x)
{
	freebytes(x->del, 88200);
}

void *comb_tilde_new(t_floatarg f)
{
  
  t_comb_tilde *x = (t_comb_tilde *)pd_new(comb_tilde_class);
  x->f_looptime = f = 1;
  floatinlet_new (&x->x_obj, &x->f_looptime);
  floatinlet_new (&x->x_obj, &x->f_revtime);
  outlet_new(&x->x_obj, &s_signal);
  x->del = (float *)getbytes(sizeof(float)*88200);
  x->rpointer=0;
  x->wpointer=0;
  x->f_revtime=0.1;	  

  return (void *)x;
}

void comb_setup(void)
{
	 post("\nComb Filter");
	 post("Rory Walsh Jan 2002");
  comb_tilde_class = class_new(gensym("comb~"),
  (t_newmethod)comb_tilde_new,
   (t_method)comb_tilde_free, sizeof(t_comb_tilde), 
        CLASS_DEFAULT,  A_DEFFLOAT, 0);
  class_addmethod(comb_tilde_class,
        (t_method)comb_tilde_dsp, gensym("dsp"), 0);
  CLASS_MAINSIGNALIN(comb_tilde_class, t_comb_tilde, f);

}

