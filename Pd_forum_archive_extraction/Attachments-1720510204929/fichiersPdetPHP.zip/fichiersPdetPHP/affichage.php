<?php
//Jack/RYBN 2010
$nomObjet = $_GET[nomFichier];
$langage = $_GET[langage];
//$nomObjet = 'rectangle';
//$langage = 'FR';
echo '<head>
<style type="text/css">
	#container{
	width: 90%;
	height: 30px;
	background: #FF0000;
	}
	#container2{
	width: 90%;
	height: 20px;
	background: #999999;
	}
	#container3{
	width: 90%;
	height: 20px;
	background: #0000FF;
	}

</style>
</head>
';
echo '<DIV id="container">
<H2>'.$nomObjet.'</H2></DIV><br>';
$maTable = array();
$txt = implode('',file('gem/help/'.$langage.'/'.$nomObjet.'-'.$langage.'-help.pd'));
$txt = str_replace("\n",' ',$txt);
$txt = str_replace(";",' ;',$txt);
$motcanvas = '#N canvas ';
$nbcanvas = explode($motcanvas,$txt);
$motrestore = '#X restore ';
for ($i=0;$i<sizeof($nbcanvas);$i++){
	$nbrestore = explode($motrestore,$nbcanvas[$i]);
}

for ($i=0;$i<sizeof($nbrestore);$i++){
	$reste = $nbrestore[sizeof($nbcanvas)-1-$i];
	array_push($maTable, $nbcanvas[$i].$reste);
}
array_push($maTable, $nbrestore[0]);


for ($i=1;$i<sizeof($maTable);$i++){
	unset ($motsgroupe,$place,$tabPlace,$absHelpCat,$phrasesgroupe,$motsgroupe,$tabPlaceText,$absHelpText);
	$absHelpCat = array();
	$absHelpText = array();
	//echo $maTable[$i].'<br><br>';
	$motsgroupe = explode(' ', $maTable[$i]);//tous les mots dans une table $motsgroupe
	//recherche abs helpSeparator
	$recherche = 'helpSeparator';
	$place = array_search($recherche,$motsgroupe);
	//echo '$place existe = '.$place.'<br><br>';
	if ($place) {
		//isoler le nom du sous patch si c'est un sous patch
		$tabNomSousPatch = explode(' ',$maTable[$i]);
		$nomSousPatch = $tabNomSousPatch[4];
		if (!is_numeric($nomSousPatch)) {
			echo '<DIV id="container3">
			<H4>'.$nomSousPatch.'</H4></DIV>';
		}
		//position de 'helpSeparator' dans table
		$valPosY = $motsgroupe[$place-1];
		//echo '$valPosY de helpSeparator = '.$valPosY.'<br><br>';
		//recherche abs absHelpCat
		$recherche = 'absHelpCat';
		$tabPlace = array_keys($motsgroupe,$recherche);
		for ($j=0;$j<sizeof($tabPlace);$j++){
			$valCat = $motsgroupe[$tabPlace[$j]+1];
			$valCatY = $motsgroupe[$tabPlace[$j]-1];
			array_push($absHelpCat, array($valCatY, $valCat));
		}

		//recherche texte text
		$phrasesgroupe = explode(';', $maTable[$i]);//tous les lignes dans une table $phrasesgroupe
		foreach ($phrasesgroupe as $phrases){
			//echo $phrases.'<br><br>';
			$motsgroupe = explode(' ', $phrases);//tous les mots dans une table $motsgroupe
			$recherche = 'text';
			$tabPlaceText = array_keys($motsgroupe,$recherche);
			if ($tabPlaceText) {
				for ($j=0;$j<sizeof($tabPlaceText);$j++){//boucle pour retrouver tous les 'Text'
					$valText = $phrases;
					//echo $valText.'<br><br>';
					$valTextY = $motsgroupe[$tabPlaceText[$j]+2];//retourne le Y de 'Text'
					//echo $valTextY.'<br><br>';
					array_push($absHelpText, array($valTextY, $valText));
				}
			}
		}

	}
	//Affichage a chaque fois que 'helpseparator' est present
	$tabFinal = array_merge($absHelpCat,$absHelpText);
	sort($tabFinal);
	foreach ($tabFinal as $info){
		if ($info[0]>$valPosY) {
			if ($info[1][1]=='#') {
				$tabMonText = explode(' ',$info[1]);
				array_splice($tabMonText, 0, 5);
				$info[1] = implode(' ',$tabMonText);
				echo $info[1].'<br>';
			} else {
				echo '<DIV id="container2">
				<H4>'.$info[1].'</H4></DIV><br>';			
			}
		}
	}

}

?>

