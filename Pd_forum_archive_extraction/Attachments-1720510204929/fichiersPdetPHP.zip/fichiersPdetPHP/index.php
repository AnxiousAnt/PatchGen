<?php
//Jack/RYBN 2010
$dir_nom = $_GET['lien'];
$precede = $_GET['precede'];
if (!$dir_nom) {
	$dir_nom = '.';
}
$dir = opendir($dir_nom);

$dossier= array();

while($element = readdir($dir)) {
	if($element != '.' && $element != '..' && $element != 'index.php' && $element != 'affichage.php') {
		if (is_dir($dir_nom.'/'.$element)) {
			array_push($dossier,$element);
		} else {
			array_push($dossier,$element);
		}
	}
}

closedir($dir);

if(!empty($dossier)) {
	sort($dossier);
	foreach($dossier as $lien){
		//echo substr($lien, 0, -11).'<br>';
		if (substr($lien, -8)!='-help.pd') {
			echo '<a href=index.php?lien='.$dir_nom.'/'.$lien.'&precede='.$lien.'>'.$lien.'</a><br>';
		} else {
			echo '<a href=affichage.php?langage='.$precede.'&nomFichier='.substr($lien, 0, -11).'>'.$lien.'</a><br>';
		}
	}

}
?>

