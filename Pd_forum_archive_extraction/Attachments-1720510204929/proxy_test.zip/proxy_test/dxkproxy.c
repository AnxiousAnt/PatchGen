#include "m_pd.h"

t_class *proxy_class = NULL;

t_class *dxkproxy_class = NULL;

typedef struct _proxy {
	t_pd l_pd;
	double rightval;
	void *dxkproxy;
} t_proxy;

typedef struct _dxkproxy {
	t_object x_obj;
	t_float x_input;
	t_proxy pxy;
} t_dxkproxy;

static void proxy_init(t_proxy *p, t_dxkproxy *b) {
	p -> l_pd = proxy_class;
	p -> dxkproxy = (void *) b;
}


static void *proxy_new(t_symbol *s, int argc, t_atom *argv) {
	t_proxy *x = (t_proxy *)pd_new(proxy_class);
	if (x) {
		post("proxy_new");
	} else {
		post("proxy_new: could not create memory for new");
	}
	return x;
}

static void proxy_free(t_proxy *p) {
	post("proxy_free");
}

static t_int *proxy_perform(t_int *w){
	 t_proxy *x = (t_proxy *)(w[1]);
	 t_float *in = (t_float *)(w[2]);
	int n = (int)(w[3]);
	while(n--){
		x->rightval = *in++;
	};
	return (w+4);
}

static void proxy_dsp(t_proxy *x, t_signal **sp){
	   dsp_add(proxy_perform, 3, x, sp[0]->s_vec, sp[0]->s_n);
}

static void proxy_post(t_proxy *x, t_float f){
	post("this is my second float: %f", f);
};

static void proxy_setup(void) {
	post("proxy_setup");
	proxy_class =
		(t_class *)class_new(gensym("dxkproxy inlet"),
							 (t_newmethod)proxy_new,
							 (t_method)proxy_free,
							 sizeof(t_proxy),
							 0,
							 0);
	class_addmethod(proxy_class, (t_method)proxy_dsp, gensym("dsp"), A_CANT, 0);
    class_addmethod(proxy_class, nullfn, gensym("signal"), 0);
    class_addfloat(proxy_class, (t_method)proxy_post);
}

static t_int *dxkproxy_perform(t_int *w){
	 t_dxkproxy *x = (t_dxkproxy *)(w[1]);
	 t_float *in = (t_float *)(w[2]);
	 t_float *out = (t_float *)(w[3]);
	int n = (int)(w[4]);
	while(n--){
		float proxyval = x->pxy.rightval;
		float inval = *in++;
		float result = inval + proxyval;
		*out++ = result;
	};
	return (w+5);
}

static void dxkproxy_dsp(t_dxkproxy *x, t_signal **sp){
			dsp_add(dxkproxy_perform, 4, x, sp[0]->s_vec, sp[1]->s_vec, sp[0]->s_n);
}

static void *dxkproxy_new(t_symbol *s, int argc, t_atom *argv) {
	t_dxkproxy *x = (t_dxkproxy *)pd_new(dxkproxy_class);
	if (x) {
		outlet_new(&x->x_obj, gensym("signal"));
		proxy_init(&x -> pxy, x);
		post("dxkproxy: this is the 1+1 dsp  version");
		inlet_new(&x -> x_obj, &x -> pxy.l_pd, &s_signal, &s_signal);
		post("dxkproxy_new");
	}
	return x;
}

static void dxkproxy_free(t_dxkproxy *x) {
	post("dxkproxy_free");
}

static void dxkproxy_float(t_dxkproxy *x, t_float f){
	post("this is my first float: %f", f);
}

void dxkproxy_setup(void) {
	post("dxkproxy_setup");
	dxkproxy_class =
		(t_class *)class_new(gensym("dxkproxy"),
							 (t_newmethod)dxkproxy_new,
							 (t_method)dxkproxy_free,
							 sizeof(t_dxkproxy),
							 0,
							 A_GIMME,
							 0);
	class_addmethod(dxkproxy_class, (t_method)dxkproxy_dsp, gensym("dsp"), A_CANT, 0);
//  class_addmethod(dxkproxy_class, nullfn, gensym("signal"), 0); // ruins values from proxy
    class_addfloat(dxkproxy_class, (t_method)dxkproxy_float);
	proxy_setup();
}
