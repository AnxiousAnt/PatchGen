// the idea of this external is just to mix inlet 1 & 5, inlet 2 & 6, inlet 3 & 7, inlet 4 & 8.
//
// it only works correctly for me if reverse the order of the outlets in mix4_tilde_dsp
//
//////////////////////////////////////////////////////////////////////////////////////////////////


#include "m_pd.h"  
#include <math.h>

static t_class *mix4_tilde_class;  
 
typedef struct _mix4_tilde 
{  
  t_object x_obj;
  t_sample f;
  
  t_inlet *left_in[3];
  t_inlet *right_in[4]; 
  t_outlet *osc_out[4];
  
} t_mix4_tilde;  

static t_int *mix4_tilde_perform(t_int *w)
{  
  //no need for this:
  // t_mix4_tilde *x = (t_mix4_tilde *)(w[1]);
  
  t_sample *left[4];
      for (int a = 0; a < 4; a++) left[a] = (t_sample *)(w[a+2]);
  t_sample *right[4];
      for (int a = 0; a < 4; a++) right[a] = (t_sample *)(w[a+6]);
  t_sample *output[4];
      for (int a = 0; a < 4; a++) output[a] = (t_sample *)(w[a+10]);
  
  // loop through the 4 oscillators, adding the left to right:
  for (int osc = 0; osc < 4; osc++)
  {
    int n = (int)(w[14]);
    while (n--) *output[osc]++ = *left[osc]++ + *right[osc]++;
  }
  //
  return (w+15);  
}  
 
// reversed the order here for the outlets
 
static void mix4_tilde_dsp(t_mix4_tilde *x, t_signal **sp)
{ 
  dsp_add(mix4_tilde_perform, 14, x,  
    sp[0]->s_vec, sp[1]->s_vec, sp[2]->s_vec, sp[3]->s_vec,
	sp[4]->s_vec, sp[5]->s_vec, sp[6]->s_vec, sp[7]->s_vec, 
	sp[11]->s_vec, sp[10]->s_vec, sp[9]->s_vec, sp[8]->s_vec, // <--- these are reversed
	sp[0]->s_n);  
}  
 
void mix4_tilde_free(t_mix4_tilde *x)
{   
  for (int a = 0; a < 3; a++) inlet_free(x->left_in[a]);
	for (int a = 0; a < 4; a++) inlet_free(x->right_in[a]);
  for (int a = 0; a < 4; a++) outlet_free(x->osc_out[a]);
}  
 
static void *mix4_tilde_new(void)
{    
  t_mix4_tilde *x = (t_mix4_tilde *)pd_new(mix4_tilde_class);  
 
  for (int a = 0; a < 3; a++)
      x->left_in[a] = inlet_new(&x->x_obj, &x->x_obj.ob_pd, &s_signal, &s_signal);
  for (int a = 0; a < 4; a++)
      x->right_in[a] = inlet_new(&x->x_obj, &x->x_obj.ob_pd, &s_signal, &s_signal);
  for (int a = 0; a < 4; a++)
      x->osc_out[a] = outlet_new(&x->x_obj, &s_signal);
 
  return (void *)x;  
}  
 
void mix4_tilde_setup(void)
{
  mix4_tilde_class = class_new(gensym("mix4~"),
        (t_newmethod)mix4_tilde_new,  
        0, sizeof(t_mix4_tilde),  
        0, 0);  
 
  class_addmethod(mix4_tilde_class,  
        (t_method)mix4_tilde_dsp, gensym("dsp"),
        0);
    
  CLASS_MAINSIGNALIN(mix4_tilde_class, t_mix4_tilde, f);
}