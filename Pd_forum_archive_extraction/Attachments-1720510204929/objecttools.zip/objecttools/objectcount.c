#include <m_pd.h>
#include "g_canvas.h"
typedef struct {t_object o; t_canvas *c;} t_objectcount;
static t_class *objectcount_class;
t_pd *objectcount_new (void) {
	t_objectcount *self = (t_objectcount *)pd_new(objectcount_class);
	self->c=canvas_getcurrent();
	outlet_new((t_object *)self,0);
	return (t_pd *)self;
}
void objectcount_bang(t_objectcount *self) {
	int i=0; t_gobj *o = self->c->gl_list; while (o) {i++; o=o->g_next;}
	outlet_float(self->o.te_outlet,i);
}
void objectcount_setup (void) {
	objectcount_class=class_new(gensym("objectcount"),
	(t_newmethod)objectcount_new,0,sizeof(t_objectcount),0,0);
	class_addbang(objectcount_class,objectcount_bang);
}
