#include <m_pd.h>
#include "g_canvas.h"
typedef struct {t_object o; t_canvas *c;} t_objectselect;
static t_class *objectselect_class;
t_pd *objectselect_new (void) {
  t_objectselect *self = (t_objectselect *)pd_new(objectselect_class);
  self->c=canvas_getcurrent();
  return (t_pd *)self;
}
void objectselect_float(t_objectselect *self, t_float f) {
  glist_noselect(self->c);
  int i=0; t_gobj *o = self->c->gl_list;
  for (; o; i++, o=o->g_next) if (i==(int)f) break;
  if (o) glist_select(self->c,o);
}
void objectselect_setup (void) {
  objectselect_class=class_new(gensym("objectselect"),
    (t_newmethod)objectselect_new,0,sizeof(t_objectselect),0,0);
  class_addfloat(objectselect_class,objectselect_float);
} 
