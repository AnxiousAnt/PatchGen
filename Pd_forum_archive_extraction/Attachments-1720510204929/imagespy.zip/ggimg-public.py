#!/usr/bin/python
import urllib2
import random
import sys, os
import re
import md5
import Image

DICT_FILE=""
# file with words which will be searched on the google images
IMGPOOL=""
# dir where to put
SIZE=(200,200)
# max image size, larger will be resized to this, keeping the img aspect
WORDFILE=''
# word chosen from the dict will be putted here
LOCKFILE='lockfile'
# this file will exist until all images are downloaded


def getRandWord(file):
	listfile = open(file,'r')
	albumlist = listfile.readlines()
	listfile.close()
	return albumlist[random.randrange(0, len(albumlist))].strip()

def wipeDir(dir):
	for file in os.listdir(dir):
		os.remove(dir+file)



def main():
	url_regexp=unicode(r"((http|ftp)://)?(((([\d]+\.)+){3}[\d]+(/[\w./]+)?)|([a-z]\w*((\.\w+)+){2,})([/][\w.~]*)*)")
	word=getRandWord(DICT_FILE)
#        word='kokot'
	ret='<div id="rand_img"><b>'+word+'!!</b><br />'
	URL='http://images.google.com/images?ie=ISO-8859-2&q='+word+'&lr=&sa=N&tab=wi'
	opener = urllib2.build_opener()
	opener.addheaders = [('User-agent', 'Mozilla/5.0')]
	f = opener.open(URL)
	data = f.read()
	urllist=[]
	for m in re.finditer(url_regexp, data):
		if re.search('([jJ][pP][gG]|[pP][nN][gG]|[gG][iI[fF])$',m.group()):
			urllist.append(m.group())
	print 'the almighty word is: %s' % word
	fw = open(WORDFILE,'w')
	fw.write(word)
	fw.close()
	print 'wiping directory'
	wipeDir(IMGPOOL)
	lock=open(LOCKFILE, 'w')
	lock.close()
	for imgurl in urllist:
		try:
			img=opener.open(imgurl)
			imagepath=IMGPOOL+md5.new(imgurl).hexdigest() # fixit
			fw=open(imagepath, 'w')
			fw.write(img.read())
			fw.close()
			data=img.read()
			img=Image.open(imagepath)
			img.thumbnail(SIZE)
			if random.randrange(2) == 0:
				ext='.jpg'
			else:
				ext='.gif'
			try:
				img.save(imagepath+ext)
			except:
				print 'err'
			os.chmod(imagepath+ext, 0666)
			os.remove(imagepath)
			print '%s => %s' % (imgurl, imagepath+ext)
		except:
			print 'err: %s' % imgurl

	os.remove(LOCKFILE)
#                        print m.group()
#                        pass
#        ret+='<img src="http://images.google.com'+mypar.hyperlinks[GIMG_NO]+'" alt="random image from the deepest deeps of the internet"/></div>'
#        return ret
main()
