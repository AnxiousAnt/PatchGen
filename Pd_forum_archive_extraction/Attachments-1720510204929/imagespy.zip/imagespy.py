
try:
	import pyext
except:
	print "ERROR: This script must be loaded by the PD/Max pyext external"
from Tkinter import *

#!/usr/bin/python
import urllib
import urllib2
import random
import sys, os
import re
import md5
import Image
import ImageTk

IMGPOOL='img/'
# dir where to put
SIZE=(50,50)


class Application(Frame):                                           
	"""This is the TK application class"""
	def quitapp(self):                                                    
		self.extcl._outlet(1,"adios")
	# File Location
	def callback(self,file2):                                                    
		self.extcl._outlet(1,file2)
	# search images on google
	def search(self):
		arg=self.e.get()
		word=str(arg)
		url_regexp=unicode(r"((http|ftp)://)?(((([\d]+\.)+){3}[\d]+(/[\w./]+)?)|([a-z]\w*((\.\w+)+){2,})([/][\w.~]*)*)")
		ret='<div id="rand_img"><b>'+str(arg)+'!!</b><br />'
		URL='http://images.google.com/images?ie=ISO-8859-2&q='+word+'&lr=&sa=N&tab=wi'
		opener = urllib2.build_opener()
		opener.addheaders = [('User-agent', 'Mozilla/5.0')]
		f = opener.open(URL)
		data = f.read()
		urllist=[]
		for m in re.finditer(url_regexp, data):
		    if re.search('([jJ][pP][gG]|[pP][nN][gG]|[gG][iI[fF])$',m.group()):
			urllist.append(m.group())
		print 'the almighty word is: %s' % word
		print 'wiping directory'
		i=0
		for imgurl in urllist:
			img=opener.open(imgurl)
			i=i+1
			file=IMGPOOL+str(arg)+str(i)+'.jpg'
			file2=IMGPOOL+str(arg)+str(i)+'.gif'
			imagepath=urllib.urlretrieve(imgurl,file)

			img=Image.open(file)
			img.thumbnail(SIZE)
			img.save(file2)

			self.putImage(file2,file)
			self.callback(file2)
			
			# put a button with an image for each file
	def putImage(self,file2,file):                                             
		
		self.image = Image.open(file2)
		self.photo = ImageTk.PhotoImage(self.image)
		
		self.label = Button(image=self.photo, command=self.putbutton(file))
		self.label.image = self.photo # to keep a reference
		self.label.command = file
		self.label.pack()
		print self.label.cget("command")

	def putbutton(self,file):                                             
		
		self.extcl._outlet(1,file)
		
		
		
	def createWidgets(self):                                             

		m1 = PanedWindow()
		m1.pack(fill=BOTH, expand=1)
		
		self.e = Entry(m1)
		m1.add(self.e)
		
		m2 = PanedWindow(m1, orient=VERTICAL)
		m1.add(m2)
		
		b = Button(m2, text="search", width=10, command=self.search)
		m2.add(b)
		
		bottom = self.button = Button(m2, text="QUIT", fg="red", command=self.quitapp)
		m2.add(bottom)



		

                                                                    
	# Constructor
	def __init__(self,cl):
		self.extcl = cl
		Frame.__init__(self)
		self.grid()
		self.createWidgets()
		pass

# derive class from pyext._class

class myapp(pyext._class):   
	"""This class demonstrates how a TCL/TK can be openened from within a pyext external"""

	# how many inlets and outlets?
	_inlets = 1
	_outlets = 2

	# Constructor
	def __init__(self):
		# detach bang method
		self._detach(1)

	def bang_1(self):
		self._priority(-3)
		# display the tcl/tk dialog
		app = Tk()
		app.title("Google Image")
		app = Application(self)
		app.mainloop()
