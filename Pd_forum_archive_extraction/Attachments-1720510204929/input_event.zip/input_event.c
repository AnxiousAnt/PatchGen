/**
 * [input_event] Generates mouse and keyboard events on Windows
 * @author Patrice Colet <pat@mamalala.org> (source code for kbdstroke)
 * @author Jean-Yves Gratius <jyg@gumo.fr> (modified code for input_event)
 * @license GNU Public License    )c( 2008
 */
 
#include <windows.h>
#include "m_pd.h"

/** The class */
t_class *input_event_class;
 
typedef struct input_event {
  t_object x_obj; /* The instance. Contains inlets and outlets */
  t_float xsize_factor;
  t_float ysize_factor;
  
} t_input_event;



void input_event_downkey(t_input_event *x, t_float *s, int argc, t_atom *argv) {
  if (argc >= 1) {
    if (argv[0].a_type == A_FLOAT) {
      t_float str = atom_getfloat(argv);	  
//only use the first argument  <---fix this	  
      keybd_event(str, 0, 0, 0); 
    }
  	else {
      post("Error : Bad argument type. Must be a float or a symbol. ");
    }
  } else {
    post("Error : Missing argument");
  }
}

void input_event_upkey(t_input_event *x, t_float *s, int argc, t_atom *argv) {
  if (argc >= 1) {
    if (argv[0].a_type == A_FLOAT) {
      t_float str = atom_getfloat(argv);	  
//only use the first argument  <---fix this	  
      keybd_event(str, 0, 2, 0); 
    }
  	else {
      post("Error : Bad argument type. Must be a float or a symbol. ");
    }
  } else {
    post("Error : Missing argument");
  }
}
void input_event_key(t_input_event *x, t_float *s, int argc, t_atom *argv) {
  if (argc >= 1) {
    if (argv[0].a_type == A_FLOAT) {
      t_float str = atom_getfloat(argv);	  
//only use the first argument  <---fix this	  
    keybd_event(str, 0, 0, 0); 
    keybd_event(str, 0, 2, 0);
  
   

    }
  	else {
      post("Error : Bad argument type. Must be a float or a symbol. ");
    }
  } else {
    post("Error : Missing argument");
  }
}

void input_event_mouse_move(t_input_event *x, t_float *s, int argc, t_atom *argv) {
   
      if (argc >= 2) {
          if ((argv[0].a_type == A_FLOAT)&&(argv[1].a_type == A_FLOAT))  {
              
   
                  t_float str1 = atom_getfloatarg(0, argc, argv) ;	  
                  t_float str2 = atom_getfloatarg(1, argc, argv)  ;
                  mouse_event(MOUSEEVENTF_MOVE, str1, str2, 0 ,0);	
                
    }
  	else {
      post("Error : Bad argument type. Must be a float or a symbol. ");
    }
  } else {
    post("Error : Missing argument");
  }
}

void input_event_mouse_pos(t_input_event *x, t_float *s, int argc, t_atom *argv) {
  if (argc >= 2) {
    if ((argv[0].a_type == A_FLOAT)&&(argv[1].a_type == A_FLOAT))  {
      t_float str1 = atom_getfloatarg(0, argc, argv) * x->xsize_factor;	  
      t_float str2 = atom_getfloatarg(1, argc, argv) * x->ysize_factor;
      mouse_event((MOUSEEVENTF_ABSOLUTE | MOUSEEVENTF_MOVE), str1, str2, 0 ,0);
     
    }
  	else {
      post("Error : Bad argument type. Must be a float or a symbol. ");
    }
  } else {
    post("Error : Missing argument");
  }
}

void input_event_mouse_wheel(t_input_event *x, t_float *s, int argc, t_atom *argv) {
  if (argc >= 1) {
    if (argv[0].a_type == A_FLOAT) {
      t_float str = atom_getfloat(argv);	  
      mouse_event(MOUSEEVENTF_WHEEL, 0, 0, str ,0);	
    }
  	else {
      post("Error : Bad argument type. Must be a float or a symbol. ");
    }
  } else {
    post("Error : Missing argument");
  }
}

void input_event_get_screen_xsize(t_input_event *x, t_float *s, int argc, t_atom *argv) {
     
    POINT p_curseur;
    GetCursorPos(&p_curseur);
    outlet_float(x->x_obj.ob_outlet, p_curseur.x);
    
}




void input_event_float(t_input_event *x, t_floatarg f) {
  outlet_float(x->x_obj.ob_outlet, f);
    post("appel_de_la_methode_input_event_float...");
 
}

/* constructor */
void *input_event_new(t_symbol *selector, int argc, t_atom *argv) {
  t_input_event *x = (t_input_event *) pd_new(input_event_class);
  outlet_new(&x->x_obj, gensym("float"));
  x->xsize_factor = 65536 / (GetSystemMetrics(SM_CXSCREEN));
  x->ysize_factor = 65536 / (GetSystemMetrics(SM_CYSCREEN));
 
  return (void *)x;
}

/* setup */
__declspec(dllexport) void input_event_setup(void) {
  input_event_class = class_new(gensym("input_event"),
    (t_newmethod)input_event_new,
	0, sizeof(t_input_event), 0, A_GIMME, 0);
  class_addmethod(input_event_class, (t_method)input_event_downkey, gensym("downkey"), A_GIMME, 0);
  class_addmethod(input_event_class, (t_method)input_event_upkey, gensym("upkey"), A_GIMME, 0);
  class_addmethod(input_event_class, (t_method)input_event_key, gensym("key"), A_GIMME, 0);
  class_addmethod(input_event_class, (t_method)input_event_mouse_move, gensym("mouse_move"), A_GIMME, 0);
  class_addmethod(input_event_class, (t_method)input_event_mouse_pos, gensym("mouse_pos"), A_GIMME, 0);
  class_addmethod(input_event_class, (t_method)input_event_mouse_wheel, gensym("mouse_wheel"), A_GIMME, 0);
class_addmethod(input_event_class, (t_method) input_event_get_screen_xsize, gensym("xsize"), A_GIMME, 0);

 class_addfloat(input_event_class, (t_method)input_event_float);
  
  
  
}
