
/*
   please don't use any of these. for backwards compatibility only
*/


#ifndef PDP_COMPAT_H
#define PDP_COMPAT_H




void pdp_pass_if_valid(t_outlet *outlet, int *packet);
void pdp_replace_if_valid(int *dpacket, int *spacket);


#endif
