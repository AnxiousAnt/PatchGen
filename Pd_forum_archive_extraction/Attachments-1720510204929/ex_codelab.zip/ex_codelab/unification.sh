#!/bin/sh
adress="$*"

cd $adress
cat entete1.txt  var.txt foot.txt > union.html

