#!/usr/bin/perl

sub getimages {

 my @comps, $sword, $page, @comps1, @comps2, $imgcount, $count;

 $count = 0;
 $page = "";
 while ( 1 )
 {
  $sword = @_[0];
  $res=`wget -U Mozilla/3.0 -O images-list http://images.google.fr/images?q=$sword\\&start=$count\\&ie=UTF-8\\&oe=UTF-8\\&hl=fr\\&sa=N 1>/dev/null 2>\&1`;
  $pagen=`cat images-list`;
  if ( $page eq $pagen )
  {
     print "got the same page : ending ...";
     return;
  }
  else
  {
     $page = $pagen;
  }
  #print "page=$page\n";
  @comps = '';
  @comps=split('<', $page );
  $imgcount=0;
  for ($w=0; $w<=$#comps; $w++ )
  {
   if ( @comps[$w] =~ /^img/i && @comps[$w] =~ /q=/i )
   {
      #print "comp : @comps[$w]\n";
      @comps1='';
      @comps1=split( ' ', @comps[$w] );
      @comps2='';
      @comps2=split( ':', @comps1[1] );
      $url=@comps2[2];
      $count++;
      print "getting : $url ($count)\n";
      `cd images; wget -T 60 $url 2>/dev/null`;
      $imgcount+=1;
   }
  }
  if ( $imgcount == 0 ) 
  {
    return;
  }
 }
}

$word=shift;
getimages($word);

1;
