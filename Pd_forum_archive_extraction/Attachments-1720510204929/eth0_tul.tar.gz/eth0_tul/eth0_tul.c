
#include "m_pd.h"
#ifdef NT
#pragma warning( disable : 4244 )
#pragma warning( disable : 4305 )
#endif

#include <string.h>
#include <stdio.h>

#define SAMPLE_BLOCK		64
#define FRAMES_PER_SECOND	25

/* ------------------------ smpte ----------------------------- */

static t_class *smpte_class;

typedef struct _smpte {
	t_object x_obj;
     
	t_float x_fps;
	double x_starttime;
     
	t_outlet *n1;
	t_outlet *n2;
	t_outlet *n3;
	t_outlet *n4;
} t_smpte;


static void smpte_set(t_smpte *x) {
	x->x_starttime = clock_getlogicaltime();
}

static void smpte_float(t_smpte *x, t_float f) {
	x->x_fps = f;
}

static void smpte_bang(t_smpte *x) {
	
	double timenow = clock_getlogicaltime();
	double delta = timenow - x->x_starttime;
	
	int ms = (int)(delta / 64 / 44.1 / 5) % 1000;
	int s = (int)(delta / 64 / sys_getsr() / 5);
	int m = (int)(s / 60);
	int h = (int)(m / 60);
	
	int hh = h % 24;
	int mm = m % 60;
	int ss = s % 60;
	int ff = ms * x->x_fps / 1000;
	
/*	post("%le - %le = %le  >>> %d:%d:%d:%d >>> %d %d %d %d", 
		timenow, x->x_starttime, delta, 
		h,m,s,ms,
		hh,mm,ss,ff); */
	
	outlet_float(x->n1,(t_float) hh);
	outlet_float(x->n2,(t_float) mm);
	outlet_float(x->n3,(t_float) ss);
	outlet_float(x->n4,(t_float) ff);
}

static void smpte_free(t_smpte *x) {
}

static void *smpte_new(t_floatarg f)
{
	t_smpte *x = (t_smpte *)pd_new(smpte_class);
	
	smpte_set(x);
	smpte_float(x,FRAMES_PER_SECOND);

	x->n1 = outlet_new(&x->x_obj,&s_float);
	x->n2 = outlet_new(&x->x_obj,&s_float);
	x->n3 = outlet_new(&x->x_obj,&s_float);
	x->n4 = outlet_new(&x->x_obj,&s_float);

	return (x);
}

static void smpte_setup(void) {
    smpte_class = class_new(gensym("smpte"), (t_newmethod)smpte_new, 
    	(t_method)smpte_free, sizeof(t_smpte), 0, A_DEFFLOAT, 0);

    class_addbang(smpte_class,smpte_bang);
    class_addfloat(smpte_class, (t_method)smpte_float);
    class_addmethod(smpte_class, (t_method)smpte_set, gensym("reset"), 0);
}



void eth0_tul_setup(void) {

     smpte_setup();

     post("eth0_tul\n\tcontact  : <pi@attacksyour.net>");
     post("\tversion  : 0.1");
     post("\tcompiled : "__DATE__);
}

