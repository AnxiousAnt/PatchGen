Flake 0.1

This is a Pure Data patch using graph-on-parent subpatches for a somewhat clear
interface to a dual bus video-mixer. It takes Quicktime files. I use this for
preformances and it's quite stable, despite it's name.

External requirements:

- PD 0.37.4
- PDP 0.12.4  - http://zwizwa.fartit.org/pdp/
- PiDiP 0.12.8 - http://ydegoyon.free.fr/
- Yves Degoyons playlist external (in pd-unauthorized CVS or Yves site)


Use:

It's pretty self explanatory, but you might want to know that you can edit the
paths for the playlist object. You might need to trigger the metro beside the
playlist object to get started, but it won't stop the video for some reason.
The pdp_xv has a posdim message for second screen output, you probably want to edit that.
pdp_lumafilt works kind of strange. The chromakey is a bit weird. Remember to
use the tolerance slider. The yellow button beside the playlist will choose a random file 
from your selected folder at the end of every file.


TODO:

- Add more fun stuff.
- Fix problem with HRadio object moving around when opening.
- Automatic random for seek argument to playlist
- Fix QT metro so that when it's toggled off, playback stops.
- QT speed control with framerate treshold for motion-blur to kick in.
- Have some frames for transition when opening new files (buffer-stuff?).
- Add some Chromakey presets.
- Sliders for startframe and endframe in QT.
- More automation for fades/smooth transitions
- Tracker/sequencer from something like RRADICAL.
- Integrate with Memento/RRADICAL.
- Figure out why graph-on-parent is nerfed.


License: GPL

Questions, feature requests, help or bug reports? Send me a mail at thomas@bek.no

Enjoy!

Thomas Sivertsen, Bergen - 19.10.04
