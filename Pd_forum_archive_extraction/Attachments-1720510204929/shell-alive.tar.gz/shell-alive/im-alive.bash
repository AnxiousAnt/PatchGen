#!/bin/bash

raid() {
 for p in `ps -eafwww | grep "$*" | grep -v grep | grep -v raid | awk '{print $2}'`
 do
   #echo "killing $p"
   kill -9 $p
 done
}


cleanup() {
  echo "cleaning up...."
  raid pdreceive 7560
  rm ./shell.pipe
  exit
}

mkfifo ./shell.pipe

/usr/lib/pd/bin/pdreceive 7560 >./shell.pipe&

trap cleanup EXIT
#trap cleanup SIGINT

echo "waiting...."
while read $line 
do
   echo "i'm alive and well"
done < ./shell.pipe
