require 'luagl'

--
--	A plain renderer that takes messages like:
--	
--

local M = pd.Class:new():register("render.plain")

function M:initialize(name, atoms)
	self.inlets = 1
	self.outlets = 1
	self.looplen = {tri=3, quad=4}
	self.looptype = {tri=GL_TRIANGLES, quad=GL_QUADS}
	return true
end

function M:in_1(sel, atoms)
	if self.looplen[sel] then
		self:Render(atoms, self.looptype[sel], self.looplen[sel])
	end
end

function M:Render(atoms, which, len)
	width = 3
	start = 0
	glBegin(which)
	for i=0,(tonumber(len) - 1) do
		if atoms[1] == "color" then
			width = 6
			start = 1
			glColor3d(tonumber(atoms[i * width + 4 + start]), tonumber(atoms[i * width + 5 + start]), tonumber(atoms[i * width + 6 + start]))
		end
		glVertex3d(tonumber(atoms[i * width + 1 + start]), tonumber(atoms[i * width + 2 + start]), tonumber(atoms[i * width + 3 + start]))
	end
	glEnd()
end

