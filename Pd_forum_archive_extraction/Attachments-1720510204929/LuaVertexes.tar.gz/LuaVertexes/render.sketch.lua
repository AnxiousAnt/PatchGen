require 'luagl'

--
--	A sketch renderer.
--	
--

local M = pd.Class:new():register("render.sketch")

function M:initialize(name, atoms)
	self.inlets = 3
	self.outlets = 1
	self.looplen = {tri=3, quad=4}
	self.looptype = {tri=GL_TRIANGLES, quad=GL_QUADS}
	self.jitter = 0.1
	self.squiggles = 3
	return true
end

function M:in_1(sel, atoms)
	if self.looplen[sel] then
		self:Render(atoms, self.looptype[sel], self.looplen[sel])
	end
end

function M:in_2_float(sel, atoms)
	self.squiggles = sel
end

function M:in_3_float(sel, atoms)
	self.jitter = sel
end

function M:Render(atoms, which, len)
	width = 3
	start = 0
	
	if atoms[1] == "color" then
		width = 6
		start = 1
	end
	
--[[	glBegin(which)
	for i=0,(tonumber(len) - 1) do
		if atoms[1] == "color" then
			glColor3d(tonumber(atoms[i * width + 4 + start]), tonumber(atoms[i * width + 5 + start]), tonumber(atoms[i * width + 6 + start]))
		end
		glVertex3d(tonumber(atoms[i * width + 1 + start]), tonumber(atoms[i * width + 2 + start]), tonumber(atoms[i * width + 3 + start]))
	end
	glEnd() ]]--
	glColor3d(0.5, 0.5, 0.5)
	glBegin(GL_LINE_LOOP)
	for x=0,self.squiggles do
		for i=0,(tonumber(len) - 1) do
			n = i * width + start
			glVertex3d(tonumber(atoms[n + 1]) + (math.random() - 0.5) * self.jitter, tonumber(atoms[n + 2]) + (math.random() - 0.5) * self.jitter, tonumber(atoms[n + 3]) + (math.random() - 0.5) * self.jitter)
		end
	end
	glEnd(GL_LINE_LOOP)
end

