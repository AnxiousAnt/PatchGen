--
--	Load an obj file and spit it out every frame.
--	
--

local M = pd.Class:new():register("geom.obj")

function M:initialize(name, atoms)
	self.inlets = 1
	self.outlets = 1
	self.objects = {}
	self.currentObj = "" 
	
	-- read in the obj file specified
	if type(atoms[1]) == "string" then
		pd.post("Loading object file " .. atoms[1])
		io.input(atoms[1])
		
		local name = ""
		local vtx = 1
		local verticies = {}
		
		l = io.read("*line")
		while l
		do
			local wrds = {}
			for m in string.gmatch(l, "[\+\-\.%d\_%a]+") do
				table.insert(wrds, m)
			end
			
			--print (wrds[1])
			-- when we find a new object declaration, start a new batch of faces etc.
			if wrds[1] == "o"
			then
				name = wrds[2]
				pd.post("Loading object " .. wrds[2])
				self.objects[name] = {}
			elseif wrds[1] == "v" 
			then
				verticies[vtx] = {wrds[2], wrds[3], wrds[4]}
				vtx = vtx + 1
			elseif wrds[1] == "f"
			then
				local quad = {}
				
				if wrds[5] then
					table.insert(quad, "quad")
					len = 5
				else
					table.insert(quad, "tri")
					len = 4
				end
				
				for i = 2,len  do
					for j = 1, 3 do
						table.insert(quad, verticies[tonumber(wrds[i])][j])
					end
				end
				print()
				table.insert(self.objects[name], quad)
			end
			
			l = io.read("*line")
		end
		
		return true
	else
		pd.post("Please supply an object file as an argument")
		return false
	end
end

function M:in_1(sel, atoms)
	if sel == "gem_state" or sel == "bang" then
		self:Output()
	end
end

function M:Output()
	for idx, obj in pairs(self.objects)
	do
		for i, stuff in pairs(self.objects[idx])
		do
			self:outlet(1, "list", self.objects[idx][i])
		end
	end
end

