import osc 

try :
	osc.state 
except AttributeError :
	osc.init()
	osc.state = 1

osc.sendMsg('/foo','bar','localhost',9000)