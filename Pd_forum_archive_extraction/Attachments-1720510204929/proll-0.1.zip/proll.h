
#include <stdlib.h>
#include <stdio.h>
#include <sstream>
#include <vector>
#include <iostream>
#include <string>

#include <time.h>

#include <m_pd.h>
#include <m_imp.h>
#include <g_canvas.h>

#define DEFAULT_KEY_HEIGHT 10

#define x_val a_pos.a_w.w_float

#include <pthread.h>

#define NUM_THREADS     10


using namespace std;


#ifdef __WIN32
#include <windows.h>
#else
#include <unistd.h>
#endif


#ifndef PROLL_EXTERNAL_H
#define PROLL_EXTERNAL_H



#ifdef __cplusplus
extern "C" {
#endif

#ifdef _WIN32
#define PROLL_EXTERNAL __declspec(dllexport)
#else
#define PROLL_EXTERNAL
#endif


void *delay(void *t);
void cstrt(int time,int beats,char *s, void (*comp)(const void *));
#ifdef __cplusplus
}
#endif


#endif  // PROLL_EXTERNAL_H
