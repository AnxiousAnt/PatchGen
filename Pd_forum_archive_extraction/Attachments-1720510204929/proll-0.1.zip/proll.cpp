/* Copyright (c) 1997-1999 Miller Puckette.                                     */
/* For information on usage and redistribution, and for a DISCLAIMER OF ALL     */
/* WARRANTIES, see the file, "LICENSE.txt," in this distribution.               */
/*                                                                              */
/* proll : a graphical object which enables                                     */
/* to control a sequencer ( pitch and volume )                                  */
/*                                                                              */
/* Copyleft Parice Colet ( colet.patrice@free.fr )                              */
/*                                                                              */
/* This program is free software; you can redistribute it and/or                */
/* modify it under the terms of the GNU General Public License                  */
/* as published by the Free Software Foundation; either version 2               */
/* of the License, or (at your option) any later version.                       */
/*                                                                              */
/* See file LICENSE for further informations on licensing terms.                */
/*                                                                              */
/* This program is distributed in the hope that it will be useful,              */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of               */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                */
/* GNU General Public License for more details.                                 */
/*                                                                              */
/* You should have received a copy of the GNU General Public License            */
/* along with this program; if not, write to the Free Software                  */
/* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.  */
/*                                                                              */
/* Based on PureData by Miller Puckette and others.                             */
/* ---------------------------------------------------------------------------- */

#include "proll.h"

static char   *proll_version = "proll: a graphical sequencer controller, version 0.10 (colet.patrice@free.fr)"; 


// static t_symbol *proll_receive_symbol;

static t_symbol *output_symbol;
static t_symbol *destroy_symbol;

static t_class *proll_class;

typedef struct _proll {
	t_object  x_obj;
    t_symbol *receive_symbol;
	t_symbol *proll_receive_symbol;
    t_atom* atoms;			/* pointer to array of atoms */
    unsigned int arg_count; /* number of items in above arrays */
	char x_toplevel; 		/* toplevel tk name 					*/
    t_int x_ecanvas;     	/* flag that indicates if the canvas has been created */
    t_symbol *x_inst;   	/* for prepending qlist message */
    t_symbol *x_title;		/* Window Title */
    t_floatarg x_bars;		/* bar number*/
    t_glist *x_glist;	
    t_outlet *data_outlet;
} t_proll;

 /* this is an attempt to use proll as a sequencer */

int delay(int t)
{
#ifdef _WIN32
	Sleep(t/1000);
#else
	usleep(t);
#endif

}

void sstrt(int time=0,int beats=1,char *s="")
{
	if (time >= 0 || beats > 0)
	{
		string str = s;
		string buffer;
		vector<string> tokens;
		stringstream ss(str);		
		while(ss >> buffer)
		{
			tokens.push_back(buffer);
		}
		int div=tokens.size();
		int t = beats*time/(div+1);		
		for (int i=0;i < div;i++)
		{
			string strd = tokens.at(i);
			cout << strd.c_str() << endl;
			delay(t);
		}
	}
}

/* end sequencer */


static void proll_draw_new(t_proll *x)
{
// post("indrawnew:%s",*x->proll_receive_symbol);
	t_int steps = 4; t_int divs = 4; t_int bars = 4;
	sys_vgui("set w .x%x \n",x );	
	sys_vgui("::patco::proll::draw_new receive%x $w %d %d %d %d %s\n", x 
			, divs
			, steps
			, bars
			, DEFAULT_KEY_HEIGHT
			, *x->x_title);			
	x->x_ecanvas = 1;
	
}


static void proll_create(t_proll* x)
{

  if ( x->x_ecanvas )
  {
     post("proll : create : canvas already exists" );
     return;
  }

  proll_draw_new(x);

}

static void proll_inst(t_proll* x, t_symbol *s)
{

	x->x_inst = s;
}

static void proll_title(t_proll* x, t_symbol *s)
{
	x->x_title = s;
	sys_vgui("set w .x%x \n",x );
	sys_vgui("wm title $w %s \n", *x->x_title);
}

static void proll_bars(t_proll* x, t_floatarg b)
{

	sys_vgui("set w .x%x\n",x );	
	int bars = (int)b;
	sys_vgui("set settings(bars) %d\n", bars);
	sys_vgui("destroy $w\n");
	sys_vgui("::patco::proll::draw_new %s $w $settings(divs) $settings(steps) $settings(bars) $settings(keyheight) $settings(title)\n", *x->proll_receive_symbol);
	// sys_vgui("::patco::proll::set_bars .x%x %s\n", x, *x->proll_receive_symbol);
}

static void proll_show(t_proll* x, t_floatarg s)
{
	sys_vgui("set w .x%x\n",x );
	sys_vgui("wm iconify $w\n");
	
}

static void proll_qlist(t_proll* x)
{
	sys_vgui("set w .x%x\n",x );
	sys_vgui("::patco::proll::qlist .x%x receive%x %s\n", x, x, *x->x_inst);
}

static void proll_note(t_proll* x, t_symbol *s, int ac, t_atom *av)
{

	sys_vgui("set w .x%x\n",x );	
	sys_vgui("::patco::proll::cmd_note receive%x $w.tf.cg.f.proll $w.bf.cg.f.proll %d.%d.%d %d %d\n", x
		,atom_getintarg(0, ac, av)
		,atom_getintarg(1, ac, av)
		,atom_getintarg(2, ac, av)
		,atom_getintarg(3, ac, av)
		,atom_getintarg(4, ac, av));

}

static void proll_destroy(t_proll* x) 
{  		
	x->x_ecanvas = 0;
	sys_vgui("set w .x%x\n",x );
	sys_vgui("destroy $w\n");
}

static void proll_outlet(t_proll* x, t_symbol *s, int argc, t_atom *argv) 
{

    outlet_list(x->data_outlet, &s_list, argc, argv);
	
}


static t_proll *proll_new(t_symbol *s)
{

    t_proll *x;
    char buf[256];

    x = (t_proll *)pd_new(proll_class);
    // new proll created from the gui 
	
    x->x_glist = (t_glist *) canvas_getcurrent();
	x->x_inst = gensym("note");
	x->x_title = gensym("Pianoroll");

    sprintf(buf,"proll%x",x);
    x->receive_symbol = gensym(buf);
    pd_bind(&x->x_obj.ob_pd, x->receive_symbol);
	

	char unic[256];
	sprintf(unic,"receive%x",x);
    x->proll_receive_symbol = gensym(unic);	
	pd_bind(&x->x_obj.ob_pd, x->proll_receive_symbol);
	
	x->data_outlet = outlet_new(&x->x_obj, 0); 
    return (x);
	
}


static void proll_free(t_proll *x)
{
    post( "proll: freeing ressources [NULL]" );

	// sys_vgui("set w .x%x\n",x );
	// sys_vgui("destroy $w\n");
}

extern "C" PROLL_EXTERNAL void proll_setup(void)
{
	
   post( proll_version );
    proll_class = class_new(gensym("proll"),
				(t_newmethod)proll_new,
			    (t_method)proll_free,
				sizeof(t_proll), 0, A_GIMME, 0);
	
	output_symbol = gensym("output");
	destroy_symbol = gensym("destroy");

	class_addmethod(proll_class, (t_method)proll_create, gensym("create"), A_NULL);		
	class_addmethod(proll_class, (t_method)proll_qlist, gensym("qlist"), A_NULL);		
	class_addmethod(proll_class, (t_method)proll_note, gensym("note"), A_GIMME,0);	
	class_addmethod(proll_class, (t_method)proll_inst, gensym("inst"), A_SYMBOL);
	class_addmethod(proll_class, (t_method)proll_title, gensym("title"), A_SYMBOL);	
	class_addmethod(proll_class, (t_method)proll_bars, gensym("bars"), A_DEFFLOAT, 0);
	class_addmethod(proll_class, (t_method)proll_show, gensym("show"), A_DEFFLOAT, 0);	
    class_addmethod(proll_class, (t_method)proll_outlet, output_symbol, A_GIMME, A_GIMME, 0);
    class_addmethod(proll_class, (t_method)proll_destroy, destroy_symbol, A_NULL);	

    /* TODO should this use t_class->c_name? */
    sys_vgui("eval [read [open {%s/%s.tcl}]]\n",
             proll_class->c_externdir->s_name,
			 proll_class->c_name->s_name);

    sys_vgui("::patco::proll::setup\n");	
}
