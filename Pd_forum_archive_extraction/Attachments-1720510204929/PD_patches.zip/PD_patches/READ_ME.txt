TO RUN PURE DATA:

Click "start" then "run". Type "command" in the box and press return. This shall open the command prompt window. Pure Data is usually run from here. Type in the name of the path to where the "pd.exe" is located. For example on my home pc the "pd.exe" is located on the in a folder on the desktop. To run Pure Data on this machine I must type "C:\WINDOWS\desktop\pure_data\pd\bin\pd -midiindev 1 -midioutdev 2".

My college pc has a different audio and MIDI setup, plus the Pure Data executable is located in a different place. On that machine I must type "C:\pd\bin\pd -midiindev 1,2 -midioutdev 3,1,2".




TO OPEN MY FINAL YEAR PROJECT:

Once Pure Data is running, click "open" then go to the folder named "PD_patches". In this folder is a sub-folder named "main_patch". Open it. Now open "main_patch.pd"...this is the main file(as the name suggests!).

Questions / Problems? Contact me:

Marcus Flanagan 9839178
loveablemarcus@hotmail.com
15/4/2002 - 1:18pm

