#include "m_pd.h"
#include <string.h>
#include <stdio.h>

static t_class *closemsg_class;

typedef struct _closemsg {
  t_object  x_obj;
  t_symbol *x_sym; //from pd_send
} t_closemsg;

void closemsg_bang(t_closemsg *x)
{
  post("Hello world !!");
//From pd_send  
  if (x->x_sym->s_thing) pd_bang(x->x_sym->s_thing);
//END 
}


void *closemsg_new(t_symbol *s) //Added args from pd send
{
  t_closemsg *x = (t_closemsg *)pd_new(closemsg_class);

//From pd_send  

    if (!*s->s_name) symbolinlet_new(&x->x_obj, &x->x_sym);
    x->x_sym = s;

//END 

  return (void *)x; //return (x);
}


void *closemsg_free(t_closemsg *x)
{
   if (x->x_sym->s_thing) pd_bang(x->x_sym->s_thing);
	//post("Killing !!");
	return 0;
}

void closemsg_setup(void) {

  closemsg_class = class_new(gensym("closemsg"),(t_newmethod)closemsg_new,(t_method)closemsg_free, 
sizeof(t_closemsg),0, A_DEFSYM, 0);
  class_addbang(closemsg_class, closemsg_bang);
}
