/*-----------------------------------------------------------------
LOG
GEM - Graphics Environment for Multimedia

Clamp pixel values to a drawold

Copyright (c) 1997-1998 Mark Danks. mark@danks.org
Copyright (c) G�nther Geiger. geiger@epy.co.at
Copyright (c) 2001-2002 IOhannes m zmoelnig. forum::f�r::uml�ute. IEM. zmoelnig@iem.kug.ac.at
Copyright (c) 2002 James Tittle & Chris Clepper
For information on usage and redistribution, and for a DISCLAIMER OF ALL
WARRANTIES, see the file, "GEM.LICENSE.TERMS" in this distribution.

-----------------------------------------------------------------*/

#ifndef INCLUDE_pix_spectrogram_H_
#define INCLUDE_pix_spectrogram_H_

#include "Base/GemPixObj.h"

/*-----------------------------------------------------------------
-------------------------------------------------------------------
CLASS
    pix_spectrogram
    
    Clamp pixel values to a drawold

KEYWORDS
    pix
    
DESCRIPTION

    Inlet for a list - "vec_draw"
    Inlet for a float - "ft1"
    
    "vec_draw" - The drawold vector
    "ft1" - Set all drawolds to one value
   
-----------------------------------------------------------------*/
class GEM_EXTERN pix_spectrogram : public GemPixObj
{
    CPPEXTERN_HEADER(pix_spectrogram, GemPixObj)

    public:

        //////////
        // Constructor
    	pix_spectrogram();
    	
    protected:
    	
    	//////////
    	// Destructor
    	virtual ~pix_spectrogram();

    	//////////
    	// Do the processing
    	virtual void 	processRGBAImage(imageStruct &image);
    	
    	//////////
    	// Do the processing
    	virtual void 	processGrayImage(imageStruct &image);
        	
        //////////
    	// Do the processing
    	virtual void 	processYUVImage(imageStruct &image);
		
#ifdef __VEC__
	//////////
    	// Do the processing
    	virtual void 	processYUVAltivec(imageStruct &image);
#endif  
    	
    	//////////
    	// Set the new drawold value
    	void	vecdrawMess(int argc, t_atom *argv);
		void	saturationMess(float saturation);		
		void	contrastMess(float contrast);
		void	brightnessMess(float brightness);
		void	alphaMess(float alpha);
		
		float	saturation;		
		float	contrast;
		float	brightness;
		float	alpha;
		int column, index, mode;
		float value;
		float Magnitude[10000][8192];
		
		
		t_inlet *m_inSat, *m_inCon, *m_inBri, *m_inAlp;
    
    private:
    
    	//////////
    	// Static member functions
    	static void 	vecdrawMessCallback(void *data, t_symbol *, int argc, t_atom *argv);
		static void 	saturationMessCallback(void *data, t_floatarg saturation);
    	static void 	contrastMessCallback(void *data, t_floatarg contrast);
    	static void 	brightnessMessCallback(void *data, t_floatarg brightness);
    	static void 	alphaMessCallback(void *data, t_floatarg alpha);
};

#endif	// for header file
