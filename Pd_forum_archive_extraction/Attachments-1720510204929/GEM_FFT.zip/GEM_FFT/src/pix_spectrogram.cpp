////////////////////////////////////////////////////////
//
// GEM - Graphics Environment for Multimedia
//
// zmoelnig@iem.kug.ac.at
//
// Implementation file
//
//    Copyright (c) 1997-1998 Mark Danks.
//    Copyright (c) G�nther Geiger.
//    Copyright (c) 2001-2002 IOhannes m zmoelnig. forum::f�r::uml�ute. IEM
//    For information on usage and redistribution, and for a DISCLAIMER OF ALL
//    WARRANTIES, see the file, "GEM.LICENSE.TERMS" in this distribution.
//
/////////////////////////////////////////////////////////

#include "pix_spectrogram.h"

CPPEXTERN_NEW(pix_spectrogram)

// #####################################################
//
// pix_spectrogram
//
// #####################################################
// Constructor
// #####################################################
pix_spectrogram :: pix_spectrogram():
	contrast(1.0), saturation(1.0), brightness(1.0), alpha(1.0)   
{
	inlet_new(this->x_obj, &this->x_obj->ob_pd, gensym("list"), gensym("vec_draw"));
	inlet_new(this->x_obj, &this->x_obj->ob_pd, gensym("float"), gensym("auto"));
  m_inSat = inlet_new(this->x_obj, &this->x_obj->ob_pd, gensym("float"), gensym("brightness"));
  m_inCon = inlet_new(this->x_obj, &this->x_obj->ob_pd, gensym("float"), gensym("contrast"));
  m_inSat = inlet_new(this->x_obj, &this->x_obj->ob_pd, gensym("float"), gensym("saturation"));
  m_inSat = inlet_new(this->x_obj, &this->x_obj->ob_pd, gensym("float"), gensym("alpha"));
}

// #####################################################
// Destructor
// #####################################################
pix_spectrogram :: ~pix_spectrogram()
{ 
  inlet_free(m_inSat);
  inlet_free(m_inCon);
  inlet_free(m_inBri);
  inlet_free(m_inAlp);
}

// ###############################################################################################
// Utilities - Recreate the vector based type and functions that are included in the GLSL language
// ###############################################################################################

struct vec3 {
// in glsl its used for many things, but here we can just think of vec3 as an RGB color
	float r;
	float g;
	float b;
	
	vec3() { }
		
	vec3(float _r, float _g, float _b) {
		r = _r;
		g = _g;
		b = _b;
	}
};


float dot(const vec3 &v1, const vec3 &v2) {
// multiply two colors component wise, then sum the three components
	return (v1.r * v2.r) + (v1.g * v2.g) + (v1.b * v2.b);
}

vec3 mix(const vec3 &v1, const vec3 &v2, float fraction) {
// Interpolate between two colors given a fractional value
	vec3 output_color;
	output_color.r = v1.r + (v2.r - v1.r) * fraction;
	output_color.g = v1.g + (v2.g - v1.g) * fraction;
	output_color.b = v1.b + (v2.b - v1.b) * fraction;
	return output_color;
}

vec3 operator*(const vec3 &v1, float scalar) {
// Multiply each color component by a scalar value
	vec3 output_color;
	output_color.r = v1.r * scalar;
	output_color.g = v1.g * scalar;
	output_color.b = v1.b * scalar;
	return output_color;
}

inline float min(float a, float b) {
// math function that SHOULD be in c standard library
	if(a > b)
		return b;
	else
		return a;
}

inline float max(float a, float b) {
// math function that SHOULD be in c standard library
	if(a > b)
		return a;
	else
		return b;
}

// #####################################################
// processImage
// #####################################################

void pix_spectrogram :: processRGBAImage(imageStruct &image)
{	
	int xsize = image.xsize;
	int ysize = image.ysize;
	unsigned char *pixels = image.data;		
	int i, j;
	float val, val_temp;
	int xcoord, ycoord, xcount, ycount;

// We define our own color offsets so we can debug. For now they are set to defaults
	int myRed, myGreen, myBlue, myAlpha;
	myRed = chRed;
	myGreen = chGreen;
	myBlue = chBlue;
	myAlpha = chAlpha;

if (mode == 0) {
	for (ycount = 0; ycount < index; ycount++) {
		ycoord = image.csize * image.xsize * ycount;
		for (xcount = 0; xcount < column; xcount++) {
			xcoord = image.csize * xcount + ycoord; 
			
			val = Magnitude[xcount][ycount];

			if		(val <  167)				val_temp = val / 166.;
			else if (val >= 167 && val < 334)	val_temp = fabs ((val - 166.) / 166.) - 1; 
			else if (val >= 334 && val < 667)	val_temp = 0;
			else if (val >= 667 && val < 834)	val_temp = (val - 666 ) / 166;
			else								val_temp = 1;
			pixels[chRed   + xcoord] = (unsigned char) (val_temp * 255.);
			
			if		(val <  334)				val_temp = 0;
			else if (val >= 334 && val < 500)	val_temp = (val - 333) / 166.;
			else if (val >= 500 && val < 834)	val_temp = 1;
			else								val_temp = fabs((val - 833) / 166.);
			pixels[chGreen + xcoord] = (unsigned char) (val_temp * 255.);
			
			if		(val <  167)				val_temp = val / 166.; 
			else if (val >= 167 && val < 500)	val_temp = 1;
			else if (val >= 500 && val < 667)	val_temp = fabs ((val - 500) / 166.) - 1;
			else								val_temp = 0;
			pixels[chBlue  + xcoord] = (unsigned char) (val_temp * 255.);
			
		}
	}	
}
else if (mode == 1) {
	for (ycount = 0; ycount < index; ycount++) {
		ycoord = image.csize * image.xsize * ycount;
		for (xcount = 0; xcount < column; xcount++) {
			xcoord = image.csize * xcount + ycoord; 
			
			val = Magnitude[xcount][ycount];

			pixels[chRed   + xcoord] = (unsigned char) (val / 1000. * 255.);
			pixels[chGreen + xcoord] = (unsigned char) (val / 1000. * 255.);
			pixels[chBlue  + xcoord] = (unsigned char) (val / 1000. * 255.);
			
		}
	}
}
// First, we need to get the average value for each color channel. 
// -- Note: In jitter this step is performed outside of the GLSL shader, and these values are 
// passed in as a 3 value vector of floats: ('uniform vec3 avgluma')

	int pixel_count = (image.xsize) * image.ysize;

	vec3 avgluma(0, 0, 0);
	i = pixel_count;
	while(i--) {
		avgluma.r += (float) pixels[myRed];
		avgluma.g += (float) pixels[myGreen];
		avgluma.b += (float) pixels[myBlue];
		pixels+=4; 
	}
	
	avgluma.r /= pixel_count;
	avgluma.g /= pixel_count;
	avgluma.b /= pixel_count;

	
// Second, we perform the same operations described in the shader on each image pixel.
// --- Note: I found that the ordering of color channels is wierd in GEM. Don't know why.
//			[ 0=blue, 1=green, 2=red, 3=alpha] 

	static const vec3 LumCoeff(0.2125, 0.7154, 0.0721);
	
	pixels = image.data;		
	i = pixel_count;
	while(i--) {
		vec3 texColor = vec3(pixels[myRed], pixels[myGreen], pixels[myBlue]);
		float intensity_scalar = dot(texColor, LumCoeff);
		vec3 intensity = vec3(intensity_scalar, intensity_scalar, intensity_scalar);
		vec3 color = mix(intensity, texColor, saturation);
		color = mix(avgluma, color, contrast);
		color = color * brightness;

		// We need to constrain the values between 0 and 255, cast to unsigned char, then write back to image
		pixels[myRed] = (unsigned char) min(255, max(0, color.r));
		pixels[myGreen] = (unsigned char) min(255, max(0, color.g));		
		pixels[myBlue] = (unsigned char) min(255, max(0, color.b));
		//pixels[myAlpha] = (unsigned char) min(255, max(0, color.g * alpha));	// Don't know why, but that's how it was in the shader!
		
		pixels+=4; 
	}
}//CLOSE RGB method
// #####################################################
// process other images
// #####################################################
void pix_spectrogram :: processYUVImage(imageStruct &image)
{    post("no method for YUV, only RGB"); }
#ifdef __VEC__
void pix_spectrogram :: processYUVAltivec(imageStruct &image)
{    post("no method for YUV, only RGB"); }
#endif //Altivec	  
void pix_spectrogram :: processGrayImage(imageStruct &image)
{    post("no method for gray, only RGB"); }

// ###############################################################################################
// Message Handling Funcions, in both object oriented and C compatible style  (stupid to have to write both!)
// ###############################################################################################

// ------ Object Oriented

void pix_spectrogram :: contrastMess(float value)
{
	contrast = value;
	setPixModified();
}

void pix_spectrogram :: saturationMess(float value)
{
	saturation = value;
	setPixModified();
}

void pix_spectrogram :: brightnessMess(float value)
{
	brightness = value;
	setPixModified();
}
void pix_spectrogram :: alphaMess(float value)
{
	alpha = value;
	setPixModified();
	post("%f, %f, %f, %f", brightness, contrast, saturation, alpha);
}
// #####################################################
// vecdrawMess
// #####################################################
void pix_spectrogram :: vecdrawMess(int argc, t_atom *argv) {
	mode		= (int)		atom_getfloat(&argv[0]);
	column		= (int)		atom_getfloat(&argv[1]);
	index		= (int)		atom_getfloat(&argv[2]);
	value		=			atom_getfloat(&argv[3]);
	
	Magnitude[column][index] = value;
	
	setPixModified();
}
// #####################################################
// static member function
// #####################################################
void pix_spectrogram :: obj_setupCallback(t_class *classPtr)
{
    class_addmethod(classPtr, (t_method)&pix_spectrogram::vecdrawMessCallback, gensym("vec_draw"), A_GIMME, A_NULL);
	class_addmethod(classPtr, (t_method)&pix_spectrogram::contrastMessCallback, gensym("contrast"),A_FLOAT,A_NULL);
	class_addmethod(classPtr, (t_method)&pix_spectrogram::saturationMessCallback, gensym("saturation"),A_FLOAT,A_NULL);
	class_addmethod(classPtr, (t_method)&pix_spectrogram::brightnessMessCallback, gensym("brightness"),A_FLOAT,A_NULL);
	class_addmethod(classPtr, (t_method)&pix_spectrogram::alphaMessCallback, gensym("alpha"),A_FLOAT,A_NULL);
}
void pix_spectrogram :: vecdrawMessCallback(void *data, t_symbol *, int argc, t_atom *argv)
{
    GetMyClass(data)->vecdrawMess(argc, argv);
}
// ------ 'C' Compatible

void pix_spectrogram :: contrastMessCallback(void *data, t_floatarg contrast)
{
	GetMyClass(data)->contrastMess((float)contrast);
}

void pix_spectrogram :: saturationMessCallback(void *data, t_floatarg saturation)
{
	GetMyClass(data)->saturationMess((float)saturation);
}

void pix_spectrogram :: brightnessMessCallback(void *data, t_floatarg brightness)
{
	GetMyClass(data)->brightnessMess((float)brightness);
}

void pix_spectrogram :: alphaMessCallback(void *data, t_floatarg alpha)
{
	GetMyClass(data)->alphaMess((float)alpha);
}