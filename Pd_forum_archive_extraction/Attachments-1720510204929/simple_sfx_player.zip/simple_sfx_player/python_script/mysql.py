# ================================================
# py script for pure data
#
"""scripts to access a MySQL server"""
#
# (c) 2005, Georg Holzmann, <grh@mur.at>
# ================================================

# ================================================
# imports
import MySQLdb

# ================================================
# variables (only default values)
mysql_host = "localhost"
mysql_user = "root"
mysql_pwd = "gigiroot"
mysql_db = "torus"

# ================================================
# constructor
try:
	db = MySQLdb.connect(host=mysql_host, user=mysql_user, passwd=mysql_pwd, db=mysql_db)
	cursor = db.cursor()
	print "PD mysql: logged into MySQL server !"
except:
	pass

# ================================================
# methods

def connect(host_="", user_="", db_name_="", pwd_=""):
	""" connect to MySQL server """
	global db
	global cursor
	try:
		db = MySQLdb.connect(host=str(host_), user=str(user_), passwd=str(pwd_), db=str(db_name_))
		cursor = db.cursor()
		print "PD mysql: logged into MySQL server !"
		return 1
	except:
		print "PD mysql: could not log into MySQL server !"
		return 0

def execute(*args):
	""" perform MySQL commands """
	global cursor
	
	try:
		
		# get a string of all the args and execute command
		command = reduce(lambda a,b: a+str(b)+" ", args,"")
		cursor.execute("""%s""" % (command,) )
		# data = cursor.fetchone()
		# return data
		# make a proper return list
		return_val = []
		for value in cursor.fetchall():
			tmp, = value  # tuple
			return_val.append(tmp)
		return return_val
		# return_val = 0
	except:
		print "PD mysql: error in MySQL command - check syntax !"

