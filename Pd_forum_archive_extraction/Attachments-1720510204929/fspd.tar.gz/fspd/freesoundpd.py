"""This is an example script for the py/pyext object's threading functionality.
For threading support pyext exposes several function and variables

- _detach([0/1]): by enabling thread detaching, threads will run in their own threads
- _priority(prio+-): you can raise or lower the priority of the current thread
- _stop({wait time in ms}): stop all running threads (you can additionally specify a wait time in ms)
- _shouldexit: this is a flag which indicates that the running thread should terminate
"""

import freesoundpy
try:
	import pyext
except:
	print "ERROR: This script must be loaded by the PD/Max pyext external"

class fspd(pyext._class):
	"""This is a simple class with one method looping over time."""

	# number of inlets and outlets
	_inlets=1
	_outlets=1


	def __init__(self,*args):
		self.fs = freesoundpy.Freesound()
		#arguments of [pyext freesoundpd fspd username password]
		if len(args) == 2: 
			self.username = args[0]
			self.password = args[1]
			try:
				self.fs.login(self.username, self.password)
				self._outlet(1,'FreeSound - Connected')
				print("----------------------\nFreeSound - Connected\n----------------------")
			except:
				print("Wrong username or password\n")

	def connect_1(self,*a):
		if len(a) == 2:
			try:
				self.fs.login(a[0], a[1])
				self._outlet(1,'FreeSound - Connected')
				print("----------------------\nFreeSound - Connected\n----------------------")
			except:
				print("Wrong username or password\n")


	def search_1(self,a):
		print "Searching:",a
		sfresult = self.fs.search(a)
		print len(sfresult.getElementsByTagName("sample")), "results\n"
		
		for sample in sfresult.childNodes:
			if self._shouldexit:
				print "STOP"
				break
			if sample.nodeType == sample.ELEMENT_NODE:
				info = self.fs.get_sample_info(sample.attributes["id"].value)
				sfpreview = info.getElementsByTagName('preview')[0].firstChild.data
				self._outlet(1,str(info.getElementsByTagName('originalFilename')[0].firstChild.data))
				print info.getElementsByTagName('originalFilename')[0].firstChild.data
				
