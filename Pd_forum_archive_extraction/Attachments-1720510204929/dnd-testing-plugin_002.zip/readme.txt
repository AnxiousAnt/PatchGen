
========================

If you downloaded this pkg from Deken you are ready to go, if not keep reading.

To load the plugin place the "dnd-plugin" folder on Pd's search path, i.e your normal "externals" folder or the "extra" folder. You can put the folder at any other place and then add it to Pd's path.

The plugin needs a compiled version of "tkdnd" for your OS. See :

https://github.com/petasis/tkdnd

and also :

https://sourceforge.net/projects/tkdnd/

Rename your Os dnd-pkg folder to just "tkdnd" and place it inside the "dnd-plugin" folder.

Restart Pd.

You should see something like this printed to the console:

-
Drag and Drop on Window
Drag and Drop on Canvas
Usage:
See D:/pd_0.48/extra/dnd-plugin/dnd-plugin-help.pd

-

======================================================================