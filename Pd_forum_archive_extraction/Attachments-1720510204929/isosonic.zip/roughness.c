/* Roughness library
 *
 * Copyright (C) 2009 - André Pires, Alexandre Porres
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301,
 * USA.
 *
 * All the functions presented here, concerning the equal loudness curves,
 * are based on a code by Clarence Barlow.
 */
#include <string.h>
#include <math.h>
#include "m_pd.h"

static t_class *roughness_class; /*Class roughness*/

typedef struct roughness {
    t_object x_ob;
    t_outlet *x_outlet;
	//config
	float impl_choice_n; //0 = parncutt + vassilakis, 1 = sethares + vassilakis, 2 = barlow + parncutt
	//main parameters
	int argc;
    t_atom *freqs;
	float *amps;
} t_roughness;


/*
 * min() for floats
 */
static float min(float a, float b) {
  return a<b ? a : b;
}

/*
 * max() for floats
 */
static float max(float a, float b) {
  return a>b ? a : b;
}

static float sqr(float v)
{ return(v*v); }

static float throfs(float hz)
{ float khz, thr;
  khz = hz/1000;
  thr = 3.64*exp(-0.8*log(khz))+0.001*sqr(sqr(khz));
  if (khz<=15.41) thr = thr-6.5*exp(-0.6*sqr(khz-3.3));
  return(thr);
}

static float dbA(float hz, float ph)
{ float x, phx;
  float e(float a)
  { if (fabs(a) < 80) return(exp(a)); else return(0); }
  float bell(float a, float b)
  { if (b != 0) return(e(-sqr(a)/(b*16))); else return(0); }
  float hypt(float a, float b)
  { float tanh(float x)
    { float u,v;
      { u = e(x); v = e(-x);
        if ((u+v) != 0) return((u-v)/(u+v)); else return(0);
      }
  }
    if (b != 0) return(1-tanh(a/b)); else return(0);
  }
  float trait(int q)
  { float rbf = 0;
    if (q == 1)  rbf = -711+573*hypt(phx+23,-137);
    if (q == 2)  rbf =  155+115*hypt(phx+23,62) + 648*hypt(phx-144,-35);
    if (q == 3)  rbf =   64+264*hypt(phx+23,114) + 53*hypt(phx-112,-32);
    if (q == 4)  rbf =   365+43*bell(phx-15,1419);
    if (q == 5)  rbf =  272+394*bell(phx-107,26) + 1241*hypt(phx+51,36);
    if (q == 6)  rbf =    26+28*bell(phx-108,44);
    if (q == 7)  rbf =   578+10*bell(phx-109,10);
    if (q == 8)  rbf =   86+103*bell(phx-109,22) + 61*hypt(phx+15,43);
    if (q == 9)  rbf =    62-34*bell(phx-63,66) + 39*hypt(phx-113,-162);
    if (q == 10) rbf =   -20+12*bell(phx-66,263) - 64*hypt(phx-153,-24);
    if (q == 11) rbf =    72-57*bell(phx-75,449) + 48*hypt(phx-116,-17);
    return(rbf);
  }
  float dd(float h, float p)
  {
	x = 90.89*log(fabs(h))-244; phx = p*1.03;
    return(0.288*(trait(1) + trait(3)*hypt(x-20,trait(2))
                           + trait(6)*bell(x-trait(4),trait(5))
                           + trait(9)*bell(x-trait(7),trait(8))
                           + trait(11)*hypt(x-620,trait(10))));
  }
  return(dd(hz,ph) + (throfs(hz)-dd(hz,3))*(hz/250000));
} // end of function dbA

static float phon(float hz, float db) // given to 2 decimal places
/* NB: 1 dbA (the minimum workable value)
   gives -123.3 Ph @ 20 Hz, -30.0 Ph @ 20000 Hz */
{
  int cph,cphbt,cphtp,lcphbt,lcphtp,i;
  float mb,db00;
  { db00 = db*100; cphbt = -12595; cphtp = 15000; i = 0;
    do
    { lcphbt = cphbt; lcphtp = cphtp;
      cph = (cphbt+cphtp)/2; mb = 100*dbA(hz,cph/100);
      if (mb<db00) { cphbt = cph; cphtp = lcphtp; }
              else { cphbt = lcphbt; cphtp = cph; }
      i++;
    } while ((fabs(db00-mb)>=1) && (i<20));
    return(cph/100.0);
  }
}

/*
 *
 */
static float terh(float h) {
   return 13.3*atan(3*h/4000);
}

/*
 *
 */
static float traun(float h) {
   float r = ((26.81*h)/(1960 + h)) - 0.53;
   if (r > 20.1) {
        r = r + 0.22*(r - 20.1);
   }
   return r;
}
/*
 * [rmstodb]
 */
static float gain2db(float amp) {
    if (amp > 0.00001)
        return 100+20*log10f(amp);
    return 0;
}
/*
 * [dbtorms]
 */
static float db2gain(float db) {
    return pow(10, (db-100)/20);
}
/*
 * Phons to Sones Conversion
 *    0.30103 = log10(2)
 */
static float ph2sn(float ph) {
    return pow(10, (0.30103*(ph-40))/10);
}

/*
 * Sones to Phons Convertion
 */

#if 0
static float sn2ph(float sn) {
    return 40 + 33.22*log10f(sn);
    /* fdgdf */
}
#endif

/*
 *
 */
static float barks(float h) {
    if (h < 219.5) {
        return terh(h);
    } else {
        return traun(h);
    }
}

/**
 * Vassilakis function
 */
static float vassilakis(float amp1, float amp2) {
	float a1 = min(amp1, amp2);
	float a2 = max(amp1, amp2);
	float k1 = 0.1;
	float k2 = 1;
	float k3 = 3.11;
	return pow(a1*a2, k1) * k2 * pow((2*a1)/(a1+a2), k3);
}

/**
 *
 */
static float parncutt(float freq1, float freq2) {
    float r = barks(freq1) - barks(freq2);
    r = fabs(r);
    if (r > 1.2) {
        r = 0;
    } else {
        r = pow((4*exp(1)*r)/(exp(4*r)), 2);
    }
    return r;
}

/**
 *
 */
static float sethares(float freq1, float freq2) {
    float r = barks(freq1) - barks(freq2);
    r = fabs(r);
    r = 5.56309 * (exp(r * -3.51) - exp(r * -5.75));
    return r;
}

/**
 * roughness function.
 * computes the roughness for each component
 */
static void roughness(t_roughness *x) {
	int size = x->argc;
	int i, j;
	float froughness = 0;
	float r;
    float freq_i, freq_j, //frequencies
          amp_i, amp_j,   //amplitudes [0,1]
          ph_i, ph_j,     //phons after flunson
          sn_i, sn_j;     //sones after conversion
	for (i = 0; i < size; i++) {
		for (j = i + 1; j < size; j++) {
			// convert the gains to decibels
            amp_i = gain2db(x->amps[i]);
            amp_j = gain2db(x->amps[j]);
			// get the frequencies
            freq_i = atom_getfloat(x->freqs + i);
            freq_j = atom_getfloat(x->freqs + j);
			// get phon values
            ph_i = phon(freq_i, amp_i);
            ph_j = phon(freq_j, amp_j);
            // convert back to gain
			amp_i = db2gain(ph_i);
			amp_j = db2gain(ph_j);
			if (x->impl_choice_n == 0) {
				//parncutt/vassilakiss
        		r = parncutt(freq_i, freq_j) * vassilakis(amp_i, amp_j);
        		froughness += r;
        		// blah blah
			} else if (x->impl_choice_n == 1) {
				//sethares/vassilakis
				r = sethares(freq_i, freq_j) * vassilakis(amp_i, amp_j);
        		froughness += r;
			} else {
                //clarence barlow's method
                sn_i = ph2sn(ph_i);
                sn_j = ph2sn(ph_j);
                r = parncutt(freq_i, freq_j) * sqrt(sn_i*sn_j);
        		froughness += r;
            }
		}
	}
	outlet_float(x->x_outlet, froughness);
}

/**
 * Hot inlet
 * Allocate frequency values and execute roughness method.
 */
static void roughness_freqs(t_roughness *x, t_symbol *s, int argc, t_atom *argv)
{
    // LATER accelerqte x->freqs by making it a float *.
    // LATER see if resizebytes gets any faster
    if (x->freqs) freebytes(x->freqs,x->argc*sizeof(t_atom));
    x->freqs = (t_atom *)getbytes(argc * sizeof(t_atom));
    int i;
    for (i=0; i<argc; i++) x->freqs[i] = argv[i];
    x->argc = argc;
    if (x->amps) {
        roughness(x);
    }
}
/**
 * Cold inlet
 * Allocate amplitude values.
 */
static void roughness_amps(t_roughness *x, t_symbol *s, int argc, t_atom *argv)
{
    // LATER see if resizebytes gets any faster
    if (x->amps ) freebytes(x->amps,x->argc*sizeof(float));
    x->amps = (float *)getbytes(argc * sizeof(float));
	x->argc = argc;
	int i;
    for (i = 0; i < argc;i++) {
		x->amps[i] = atom_getfloat(argv+i);
	}
}
/*
 * New method
 */
static void *roughness_new(t_symbol *s1, int argcount, t_atom *argvec)
{
    t_roughness *x = (t_roughness *)pd_new(roughness_class);
    inlet_new(&x->x_ob, &x->x_ob.ob_pd, gensym("list"), gensym("amps"));
    x->x_outlet = outlet_new(&x->x_ob, gensym("float"));
	//these are the valid choices
    x->impl_choice_n = 0;
    if (argcount == 0 || (argvec[0].a_w.w_float != 0 && argvec[0].a_w.w_float != 1 && argvec[0].a_w.w_float != 2)) {
		post("Missing valid argument:  roughness [0|1|2]. Using default: '0 = parncutt/vassilakis'.");
	} else {
        x->impl_choice_n = argvec[0].a_w.w_float;
    }
    if (argcount > 1) {
        post("warning: too many arguments");
    }
    return (void *)x;
}

static void roughness_free (t_roughness *x) {
    if (x->freqs) freebytes(x->freqs,x->argc*sizeof(t_atom));
    if (x->amps ) freebytes(x->amps ,x->argc*sizeof(float));
}

t_class *flunson_class;

typedef struct flunson {
    t_object x_ob;
    t_outlet *x_outlet;
	int argc;
	float *amps;
} t_flunson;

void *flunson_new(t_symbol *s1)
{
    t_flunson *x = (t_flunson *)pd_new(flunson_class);
    inlet_new(&x->x_ob, &x->x_ob.ob_pd, gensym("list"), gensym("amps"));
    x->x_outlet = outlet_new(&x->x_ob, gensym("float"));
    return (void *)x;
}

void flunson_freqs(t_flunson *x, t_symbol *s, int argc, t_atom *argv)
{
    if (argc > x->argc) argc = x->argc; // too many args.
    t_atom outs[argc];
    int i;
//  for (i=0; i<argc; i++) SETFLOAT(outs+i,        phon(atom_getfloat(argv+i),        x->amps[i] ) );
    for (i=0; i<argc; i++) SETFLOAT(outs+i,db2gain(phon(atom_getfloat(argv+i),gain2db(x->amps[i]))));
//  for (i=0; i<argc; i++) SETFLOAT(outs+i,db2gain( dbA(atom_getfloat(argv+i),gain2db(x->amps[i]))));
    outlet_list(x->x_outlet,&s_list,argc,outs);
}
void flunson_amps(t_flunson *x, t_symbol *s, int argc, t_atom *argv)
{
    // LATER see if resizebytes gets any faster
    if (x->amps ) freebytes(x->amps,x->argc*sizeof(float));
    x->amps = (float *)getbytes(argc * sizeof(float));
	x->argc = argc;
	int i;
    for (i = 0; i < argc;i++) {
		x->amps[i] = atom_getfloat(argv+i);
	}
}

void flunson_free (t_flunson *x) {
    if (x->amps ) freebytes(x->amps ,x->argc*sizeof(float));
}

static t_class *phon_class;
static t_class *dbA_class;
static t_class *iso226_class;
typedef struct func {
    t_object x_ob;
    t_outlet *x_outlet;
	float right;
} t_func;
static void *phon_new(t_symbol *s1, t_float right)
{
    t_func *x = (t_func *)pd_new(phon_class);
    inlet_new(&x->x_ob, &x->x_ob.ob_pd, gensym("float"), gensym("right"));
    x->x_outlet = outlet_new(&x->x_ob, gensym("float"));
    x->right = right;
    return (void *)x;
}
static void *dbA_new(t_symbol *s1, t_float right)
{
    t_func *x = (t_func *)pd_new(dbA_class);
    inlet_new(&x->x_ob, &x->x_ob.ob_pd, gensym("float"), gensym("right"));
    x->x_outlet = outlet_new(&x->x_ob, gensym("float"));
    x->right = right;
    return (void *)x;
}
static void function_right (t_func *x, float right) {x->right = right;}
static void   phon_left (t_func *x, float left) {outlet_float(x->x_outlet,  phon(left,x->right));}
static void    dbA_left (t_func *x, float left) {outlet_float(x->x_outlet,   dbA(left,x->right));}

typedef struct iso226 {
        t_object x_ob;
        t_outlet *x_outlet;
} t_iso226;
static void *iso226_new(t_symbol *s1)
{
    t_func *x = (t_func *)pd_new(iso226_class);
    x->x_outlet = outlet_new(&x->x_ob, gensym("list"));
    return (void *)x;
}
//float foo(float i) {return 20*pow(2,i/3);}
//float unf(float f) {return log(f/20)/log(2)*3;}
static void iso226_float(t_iso226 *x, t_float ph) {
    t_atom spl[29];
    int i;
    //f = [20 25 31.5 40 50 63 80 100 125 160 200 250 315 400 500 630 800 1000 1250 1600 2000 2500 3150 4000 5000 6300 8000 10000 12500];
    float af[] = {0.532, 0.506, 0.480, 0.455, 0.432, 0.409, 0.387, 0.367, 0.349, 0.330, 0.315,
                  0.301, 0.288, 0.276, 0.267, 0.259, 0.253, 0.250, 0.246, 0.244, 0.243, 0.243,
                  0.243, 0.242, 0.242, 0.245, 0.254, 0.271, 0.301};
    float Lu[] = {-31.6, -27.2, -23.0, -19.1, -15.9, -13.0, -10.3, -8.1, -6.2, -4.5, -3.1,
                   -2.0,  -1.1,  -0.4,   0.0,   0.3,   0.5,   0.0, -2.7, -4.1, -1.0,  1.7,
                    2.5,   1.2,  -2.1,  -7.1, -11.2, -10.7,  -3.1};
    float Tf[] = { 78.5,  68.7,  59.5,  51.1,  44.0,  37.5,  31.5,  26.5,  22.1,  17.9,  14.4,
                   11.4,   8.6,   6.2,   4.4,   3.0,   2.2,   2.4,   3.5,   1.7,  -1.3,  -4.2,
                   -6.0,  -5.4,  -1.5,   6.0,  12.6,  13.9,  12.3};

    if ((ph < 0) || (ph > 90)) {pd_error(x,"Phon value out of bounds!"); return;}
    //Deriving sound pressure level from loudness level (iso226 sect 4.1)
    float Af[29];
    for (i=0; i<29; i++) Af[i] = 4.47E-3 * (pow(10,0.025*ph) - 1.15) + pow(0.4*pow(10,((Tf[i]+Lu[i])/10)-9 ),af[i]);
    for (i=0; i<29; i++) SETFLOAT(&spl[i], ((10/af[i]) * log10(Af[i])) - Lu[i] + 94);

    outlet_list(x->x_outlet,&s_list,29,spl);
}


/*
 * Setup method
 */
void roughness_setup(void)
{
    roughness_class = class_new(gensym("roughness"), (t_newmethod)roughness_new, (t_method)roughness_free, sizeof(t_roughness), 0, A_GIMME, 0);
	class_addlist(roughness_class, roughness_freqs);
	class_addanything(roughness_class, roughness_amps); // use class_addmethod with gensym("amps")
    flunson_class = class_new(gensym("flunson"), (t_newmethod)flunson_new, (t_method)flunson_free, sizeof(t_flunson), 0, 0);
	class_addlist(flunson_class, flunson_freqs);
	class_addanything(flunson_class, flunson_amps); // use class_addmethod with gensym("amps")
    phon_class = class_new(gensym("phon"),(t_newmethod)phon_new,0,sizeof(t_func),0,A_DEFFLOAT,0);
    class_addmethod(phon_class,(t_method)function_right,gensym("right"),A_FLOAT,0);
    class_addfloat(phon_class,(t_method)phon_left);
    dbA_class = class_new(gensym("dbA"),(t_newmethod)dbA_new,0,sizeof(t_func),0,A_DEFFLOAT,0);
    class_addmethod(dbA_class,(t_method)function_right,gensym("right"),A_FLOAT,0);
    class_addfloat(dbA_class,(t_method)dbA_left);
    iso226_class = class_new(gensym("iso226"),(t_newmethod)iso226_new,0,sizeof(t_func),0,A_DEFFLOAT,0);
    class_addfloat(iso226_class,(t_method)iso226_float);
    post("roughness version 2.12f We Have a Library now! yeeeeahh!");
}
