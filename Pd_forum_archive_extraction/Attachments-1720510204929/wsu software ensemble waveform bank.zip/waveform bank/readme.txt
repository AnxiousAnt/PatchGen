WSU Software Ensemble
Waveform Bank
Last updated November 16, 2016

https://wsusoftwareensemble.blogspot.com/

This project is an effort to provide a set of useable oscillators that can be combined easily for implementation in software music tat requires multiple “instruments.” The names of the waveforms refer to the original recordings from which each array was derived, but in most cases they do not sonically resemble the acoustic instruments. For example the [flute~] abstraction has a waveform with relatively few overtones and an added noise element that was inspired by a musician’s breath, despite not sounding much like an actual flute. The [voice~] patch happened to sound more similar to a real flute by coincidence.

Each instrument can be implemented in a patch saved in the same folder by creating an object with the abstraction name. For instance creating an object called [mallets~] will create an instance of the mallets~ waveform, along with its GUI sliders and labels without having to separately open the file named mallets~.pd. Every patch has one inlet for pitch (in frequency) which also triggers the envelope. There are two signal outlets for stereo sound. The inlets and outlets may appear hidden due to the canvases, but this is only aesthetic.

The WSU Software Ensemble is an open group with an indefinite number of contributors. Please edit and modify these patches and share your results with the group. When doing so, please fork your edits in order to retain the first iteration, and please use the naming convention “$0-instrumentnamel” and “$0-instrumentnamer” within patches for consistency.