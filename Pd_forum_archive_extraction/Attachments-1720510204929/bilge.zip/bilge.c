/* bilge -- play CD tracks on Gates machines */

/*  Copyright 1999 Miller Puckette.
Permission is granted to use this software for any purpose provided you
keep this copyright notice intact.

THE AUTHOR AND HIS EMPLOYERS MAKE NO WARRANTY, EXPRESS OR IMPLIED,
IN CONNECTION WITH THIS SOFTWARE.

This file is downloadable from http://www.crca.ucsd.edu/~msp .
*/

#include "m_pd.h"
#include <windows.h>
#include "mmsystem.h"
#include <stdio.h>

static t_class *bilge_class;
typedef struct _bilge
{
    t_object x_obj;
    t_int x_open;
} t_bilge;

static void *bilge_new(t_float fnonrepeat)
{
    t_bilge *x = (t_bilge *)pd_new(bilge_class);
    x->x_open = 0;
    return (x);
}

static void bilge_open(t_bilge *x)
{
    char errstring[1000];
    int r;
    if (!x->x_open)
    {
    	r = mciSendString("open cdaudio alias fred", errstring, 1000, 0);
    	fprintf(stderr, "open returns: %d '%s'\n", r, errstring);
    	if (!r) x->x_open = 1;
    }
}

static void bilge_play(t_bilge *x, t_symbol *start, t_symbol *stop)
{
    char errstring[1000], cmdstring[1000];
    int r;
    if (!x->x_open) bilge_open(x);
    if (!x->x_open) return;

    sprintf(cmdstring, "play fred from %s to %s", start->s_name, stop->s_name);
    fprintf(stderr, "send: %s\n", cmdstring);
    r = mciSendString(cmdstring, errstring, 1000, 0);
    fprintf(stderr, "command returns: %d '%s'\n", r, errstring);
    if (r)
    {
    	mciGetErrorString(r, errstring, 999);
    	fprintf(stderr, "error string: %s\n", errstring);
    }
}

static void bilge_close(t_bilge *x)
{
    char errstring[1000];
    int r;
    if (x->x_open)
    {
    	r = mciSendString("close fred", errstring, 1000, 0);
    	fprintf(stderr, "close returns: %s\n", errstring);
	if (r)
	{
    	    mciGetErrorString(r, errstring, 999);
    	    fprintf(stderr, "error string: %s\n", errstring);
	}
    	x->x_open = 0;
    }
}

static void bilge_stop(t_bilge *x)
{
    char errstring[1000];
    if (x->x_open)
    {
    	mciSendString("stop fred", errstring, 1000, 0);
    	fprintf(stderr, "close returns: %s\n", errstring);
    }
}

void bilge_setup(void)
{
    bilge_class = class_new(gensym("bilge"), (t_newmethod)bilge_new,
    	(t_method)bilge_close, sizeof(t_bilge), 0, A_DEFFLOAT, 0);
    class_addmethod(bilge_class, (t_method)bilge_open, gensym("open"), 0);
    class_addmethod(bilge_class, (t_method)bilge_play, gensym("play"), 
    	A_SYMBOL, A_SYMBOL, 0);
    class_addmethod(bilge_class, (t_method)bilge_close, gensym("close"), 0);
    class_addmethod(bilge_class, (t_method)bilge_stop, gensym("stop"), 0);
}
