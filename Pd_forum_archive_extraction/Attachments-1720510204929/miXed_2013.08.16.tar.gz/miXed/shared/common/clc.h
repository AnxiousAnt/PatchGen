/* Copyright (c) 2004 krzYszcz and others.
 * For information on usage and redistribution, and for a DISCLAIMER OF ALL
 * WARRANTIES, see the file, "LICENSE.txt," in this distribution.  */

#ifndef __CLC_H__
#define __CLC_H__

void clccurve_coefs(int nhops, double crv, double *bbp, double *mmp);

#endif
