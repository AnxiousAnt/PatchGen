/*

William Brent 2009
listScramble - Scramble a list.

*/

#include "m_pd.h"
#include <math.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static t_class *listScramble_class;

typedef struct _listScramble
{
    t_object x_obj;
    unsigned int x_state;
    t_outlet *scramble;
    
} t_listScramble;



/* ------------------------ listScramble -------------------------------- */
void listScramble_scramble(t_listScramble *x, t_symbol *s, int argc, t_atom *argv)
{
    int i, length, rand_length, range, nval, indices[argc], rand_indices[argc*100];
    float temp, listIn[argc];
	t_atom listOut[argc];
    unsigned int randval;
    
    for(i=0; i<argc; i++)
    	indices[i] = i;

	for(i=0; i<argc; i++)
		listIn[i] = atom_getfloat(argv+i);
	
    length = argc;
    rand_length = argc*100;
    range = (length < 1 ? 1 : length);
    
    for(i=0; i<rand_length; i++)
    {    
		randval = x->x_state;
		x->x_state = randval = randval * 472940017 + 832416023; // from random in x_misc.c
		nval = ((double)range) * ((double)randval)
			* (1./4294967296.);
			
		if (nval >= range) nval = range-1;
		
		rand_indices[i]=nval;
	}
	
	
	for(i=0; i<rand_length; i+=2)
	{
		temp = listIn[rand_indices[i]];
		listIn[rand_indices[i]] = listIn[rand_indices[i+1]];
		listIn[rand_indices[i+1]] = temp;
	}
	
	for(i=0; i<argc; i++)
		SETFLOAT(listOut+i, listIn[i]);

	outlet_list(x->scramble, 0, argc, listOut);
	
}


void *listScramble_new(t_symbol *s)
{
	int i;
	
    t_listScramble *x = (t_listScramble *)pd_new(listScramble_class);
    x->scramble = outlet_new(&x->x_obj, &s_float);
	
	x->x_state = (int)clock_getlogicaltime(); // seed with (int) logical time

    return (x);
}


void listScramble_setup(void)
{
    listScramble_class = 
    class_new(
    	gensym("listScramble"),
    	(t_newmethod)listScramble_new,
    	0,
        sizeof(t_listScramble),
        CLASS_DEFAULT, 
		0
    );

	class_addlist(
		listScramble_class,
		(t_method)listScramble_scramble
	);
    
    class_sethelpsymbol(listScramble_class, gensym("help-listScramble"));

}